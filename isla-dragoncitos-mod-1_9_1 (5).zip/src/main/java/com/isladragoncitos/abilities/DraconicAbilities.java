package com.isladragoncitos.abilities;

import com.isladragoncitos.system.DraconicData;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Las 50 habilidades draconianas. Se aprenden con un Manuscrito Draconiano (y puntos draconianos) y las usa el jinete
 * con la tecla de habilidad. Nunca danan al propio jugador, a su dragon ni a sus mascotas.
 */
public final class DraconicAbilities {
    public enum Kind { NOVA, PULSE, BEAM, BUFF, HEAL, CLEANSE, TELEPORT, LEAP, DASH, PULL, FREEZE, LIGHTNING, METEOR, PILLAR, DRAIN }

    public static final class Ability {
        public final String id;
        public final String nameEs;
        public final String descEs;
        /** Coste en puntos draconianos para aprenderla. */
        public final int costPoints;
        public final int cooldownSec;
        public final Kind kind;
        double radius = 8.0D;
        float damage = 0.0F;
        double knock = 0.0D;
        int count = 1;
        boolean fire;
        ParticleOptions particle = ParticleTypes.CRIT;
        MobEffect foeEffect;
        int foeAmp;
        int foeTicks;
        final List<MobEffectInstance> selfEffects = new ArrayList<>();
        boolean allies;

        Ability(String id, String nameEs, String descEs, int costPoints, int cooldownSec, Kind kind) {
            this.id = id;
            this.nameEs = nameEs;
            this.descEs = descEs;
            this.costPoints = costPoints;
            this.cooldownSec = cooldownSec;
            this.kind = kind;
        }

        Ability r(double radius) { this.radius = radius; return this; }
        Ability d(float damage) { this.damage = damage; return this; }
        Ability kb(double knock) { this.knock = knock; return this; }
        Ability n(int count) { this.count = count; return this; }
        Ability fire() { this.fire = true; return this; }
        Ability p(ParticleOptions particle) { this.particle = particle; return this; }
        Ability foe(MobEffect effect, int amp, int ticks) { this.foeEffect = effect; this.foeAmp = amp; this.foeTicks = ticks; return this; }
        Ability self(MobEffect effect, int amp, int ticks) { this.selfEffects.add(new MobEffectInstance(effect, ticks, amp)); return this; }
        Ability allies() { this.allies = true; return this; }
    }

    private static final Map<String, Ability> ALL = new LinkedHashMap<>();

    private static Ability reg(Ability ability) {
        ALL.put(ability.id, ability);
        return ability;
    }

    private static Ability a(String id, String name, String desc, int cost, int cd, Kind kind) {
        return reg(new Ability(id, name, desc, cost, cd, kind));
    }

    static {
        // --- explosiones (NOVA)
        a("dragon_nova", "Dragon Nova", "Explosi\u00f3n atómica de 30 bloques: 200 de da\u00f1o. No te hace da\u00f1o ni a tu drag\u00f3n ni a tus mascotas.", 100, 120, Kind.NOVA)
                .r(30).d(200).kb(2.5D).p(ParticleTypes.EXPLOSION_EMITTER);
        a("supernova", "Supernova", "Una estrella estalla a tu alrededor y prende a todos.", 120, 150, Kind.NOVA)
                .r(22).d(120).kb(2.0D).fire().p(ParticleTypes.FLAME);
        a("world_eraser", "Borrador de Mundos", "La explosión más grande: 40 bloques de pura destrucción de criaturas.", 150, 300, Kind.NOVA)
                .r(40).d(300).kb(3.0D).p(ParticleTypes.END_ROD);
        // --- pulsos (PULSE)
        a("frost_nova", "Nova de Escarcha", "Congela a los enemigos cercanos.", 30, 30, Kind.PULSE)
                .r(10).d(8).p(ParticleTypes.SNOWFLAKE).foe(MobEffects.MOVEMENT_SLOWDOWN, 3, 120);
        a("tidal_wave", "Marea", "Una ola empuja a todos lejos de ti.", 30, 25, Kind.PULSE)
                .r(12).d(6).kb(2.0D).p(ParticleTypes.SPLASH);
        a("earthquake", "Terremoto", "El suelo tiembla y lanza al aire a los enemigos.", 40, 35, Kind.PULSE)
                .r(14).d(18).kb(0.4D).p(ParticleTypes.CAMPFIRE_COSY_SMOKE).foe(MobEffects.MOVEMENT_SLOWDOWN, 1, 80);
        a("gale_burst", "R\u00e1faga", "Un vendaval aparta a los enemigos.", 25, 20, Kind.PULSE)
                .r(10).kb(2.4D).p(ParticleTypes.CLOUD);
        a("venom_cloud", "Nube Venenosa", "Envenena a todos los enemigos cercanos.", 30, 30, Kind.PULSE)
                .r(10).d(4).p(ParticleTypes.HAPPY_VILLAGER).foe(MobEffects.POISON, 2, 200);
        a("magma_burst", "Erupci\u00f3n", "Magma a tu alrededor: da\u00f1o y fuego.", 40, 40, Kind.PULSE)
                .r(10).d(22).fire().p(ParticleTypes.FLAME);
        a("dragon_roar", "Rugido del Drag\u00f3n", "Un rugido que debilita y aparta a los enemigos.", 35, 40, Kind.PULSE)
                .r(16).d(6).kb(1.4D).p(ParticleTypes.CLOUD).foe(MobEffects.WEAKNESS, 1, 200);
        a("nightfall", "Anochecer", "Ciega a los enemigos del entorno.", 30, 40, Kind.PULSE)
                .r(16).p(ParticleTypes.LARGE_SMOKE).foe(MobEffects.BLINDNESS, 0, 160);
        a("lunar_eclipse", "Eclipse Lunar", "Oscurece la zona: enemigos ciegos y tú, invisible y m\u00e1s fuerte.", 60, 60, Kind.PULSE)
                .r(20).p(ParticleTypes.LARGE_SMOKE).foe(MobEffects.BLINDNESS, 0, 200)
                .self(MobEffects.INVISIBILITY, 0, 200).self(MobEffects.DAMAGE_BOOST, 1, 200);
        a("mind_blast", "Choque Mental", "Confunde y debilita las mentes enemigas.", 40, 40, Kind.PULSE)
                .r(14).d(8).p(ParticleTypes.ENCHANT).foe(MobEffects.CONFUSION, 0, 200);
        a("chaos_burst", "Estallido Ca\u00f3tico", "Efectos al azar: confusión y levitación.", 45, 40, Kind.PULSE)
                .r(12).d(10).p(ParticleTypes.WITCH).foe(MobEffects.LEVITATION, 1, 100);
        a("crystal_spikes", "P\u00faas de Cristal", "Esquirlas que hieren y frenan.", 40, 30, Kind.PULSE)
                .r(9).d(20).p(ParticleTypes.CRIT).foe(MobEffects.MOVEMENT_SLOWDOWN, 2, 80);
        a("sandstorm", "Tormenta de Arena", "Ciega y frena a los enemigos.", 35, 40, Kind.PULSE)
                .r(14).d(5).p(ParticleTypes.CAMPFIRE_COSY_SMOKE).foe(MobEffects.BLINDNESS, 0, 120);
        a("steam_vent", "Chorro de Vapor", "Vapor ardiente que marea.", 30, 30, Kind.PULSE)
                .r(8).d(14).p(ParticleTypes.CLOUD).foe(MobEffects.CONFUSION, 0, 100);
        a("solar_aura", "Aura Solar", "Quema a todos los que se acercan.", 50, 50, Kind.PULSE)
                .r(12).d(10).fire().p(ParticleTypes.END_ROD);
        // --- rayos (BEAM)
        a("ether_breath", "Aliento Et\u00e9reo", "Un aliento etéreo de gran alcance.", 40, 25, Kind.BEAM)
                .r(30).d(30).p(ParticleTypes.PORTAL);
        a("fire_breath", "Aliento de Fuego", "Un chorro de fuego.", 25, 15, Kind.BEAM)
                .r(18).d(18).fire().p(ParticleTypes.FLAME);
        a("order_judgment", "Sentencia", "Un rayo de luz que juzga a los enemigos.", 60, 45, Kind.BEAM)
                .r(40).d(45).p(ParticleTypes.END_ROD);
        a("plasma_beam", "Rayo de Plasma", "Plasma que perfora y quema.", 70, 45, Kind.BEAM)
                .r(36).d(50).fire().p(ParticleTypes.ELECTRIC_SPARK);
        a("moon_beam", "Rayo de Luna", "Un haz lunar que deja brillando a sus víctimas.", 45, 30, Kind.BEAM)
                .r(28).d(28).p(ParticleTypes.END_ROD).foe(MobEffects.GLOWING, 0, 200);
        a("omni_blast", "Omni-explosi\u00f3n", "El rayo definitivo.", 150, 240, Kind.BEAM)
                .r(60).d(150).p(ParticleTypes.EXPLOSION);
        // --- apoyo (BUFF / HEAL / CLEANSE)
        a("scale_shield", "Escudo de Escamas", "Un escudo de absorción y resistencia para ti y tus aliados.", 30, 60, Kind.BUFF)
                .r(10).allies().p(ParticleTypes.CRIT).self(MobEffects.ABSORPTION, 4, 600).self(MobEffects.DAMAGE_RESISTANCE, 1, 400);
        a("iron_skin", "Piel de Hierro", "Resistencia muy alta unos segundos.", 30, 60, Kind.BUFF)
                .p(ParticleTypes.CRIT).self(MobEffects.DAMAGE_RESISTANCE, 3, 300);
        a("haste_surge", "Oleada de Prisa", "Prisa y velocidad.", 25, 45, Kind.BUFF)
                .p(ParticleTypes.CLOUD).self(MobEffects.DIG_SPEED, 2, 400).self(MobEffects.MOVEMENT_SPEED, 1, 400);
        a("titan_strength", "Fuerza Tit\u00e1nica", "Fuerza enorme durante un rato.", 40, 90, Kind.BUFF)
                .p(ParticleTypes.CRIT).self(MobEffects.DAMAGE_BOOST, 3, 400);
        a("shadow_veil", "Velo de Sombras", "Invisible y veloz.", 35, 60, Kind.BUFF)
                .p(ParticleTypes.LARGE_SMOKE).self(MobEffects.INVISIBILITY, 0, 400).self(MobEffects.MOVEMENT_SPEED, 1, 400);
        a("luck_charm", "Amuleto de la Suerte", "Suerte enorme.", 20, 120, Kind.BUFF)
                .p(ParticleTypes.TOTEM_OF_UNDYING).self(MobEffects.LUCK, 4, 2400);
        a("mirror_image", "Imagen Espejo", "Brillo y absorción: los golpes se reparten.", 40, 60, Kind.BUFF)
                .p(ParticleTypes.ENCHANT).self(MobEffects.ABSORPTION, 2, 600).self(MobEffects.GLOWING, 0, 100);
        a("cloud_walk", "Paso de Nube", "Caes como una pluma y saltas muy alto.", 20, 30, Kind.BUFF)
                .p(ParticleTypes.CLOUD).self(MobEffects.SLOW_FALLING, 0, 600).self(MobEffects.JUMP, 3, 600);
        a("time_haste", "Prisa Temporal", "El tiempo corre más deprisa para ti.", 60, 90, Kind.BUFF)
                .p(ParticleTypes.ENCHANT).self(MobEffects.DIG_SPEED, 3, 400).self(MobEffects.MOVEMENT_SPEED, 2, 400);
        a("holy_light", "Luz Sagrada", "Curas a tus aliados cercanos y a ti.", 35, 40, Kind.HEAL)
                .r(16).d(10).allies().p(ParticleTypes.END_ROD).self(MobEffects.REGENERATION, 1, 160);
        a("healing_aura", "Aura Curativa", "Una cura enorme para ti y los tuyos.", 60, 90, Kind.HEAL)
                .r(20).d(40).allies().p(ParticleTypes.HAPPY_VILLAGER).self(MobEffects.REGENERATION, 2, 200);
        a("time_rewind", "Rebobinar el Tiempo", "Te curas del todo y limpias los efectos malos.", 80, 120, Kind.CLEANSE)
                .d(1000).p(ParticleTypes.ENCHANT);
        // --- movimiento (TELEPORT / LEAP / DASH)
        a("blink", "Parpadeo", "Te teletransportas 16 bloques adelante.", 25, 10, Kind.TELEPORT)
                .r(16).p(ParticleTypes.PORTAL);
        a("phase_step", "Paso de Fase", "Teletransporte de 32 bloques.", 45, 20, Kind.TELEPORT)
                .r(32).p(ParticleTypes.PORTAL);
        a("dimension_rift", "Grieta Dimensional", "Teletransporte de 64 bloques.", 80, 40, Kind.TELEPORT)
                .r(64).p(ParticleTypes.PORTAL);
        a("sonic_flight", "Vuelo S\u00f3nico", "Sales disparado hacia delante.", 35, 20, Kind.DASH)
                .r(3.2D).d(10).p(ParticleTypes.CLOUD);
        a("photon_dash", "Carrera de Fotones", "Una carrera a la velocidad de la luz.", 60, 25, Kind.DASH)
                .r(5.0D).d(25).p(ParticleTypes.END_ROD);
        // --- control (PULL / FREEZE)
        a("void_implosion", "Implosi\u00f3n del Vac\u00edo", "Atrae a todos hacia ti y les hace gran da\u00f1o.", 100, 90, Kind.PULL)
                .r(18).d(60).p(ParticleTypes.PORTAL).foe(MobEffects.WITHER, 1, 100);
        a("gravity_well", "Pozo de Gravedad", "Una gravedad enorme aplasta a los enemigos.", 55, 50, Kind.PULL)
                .r(14).d(10).p(ParticleTypes.PORTAL).foe(MobEffects.MOVEMENT_SLOWDOWN, 3, 160);
        a("time_stasis", "Estasis Temporal", "El tiempo se detiene para tus enemigos durante unos segundos.", 70, 70, Kind.FREEZE)
                .r(12).p(ParticleTypes.ENCHANT).foe(MobEffects.MOVEMENT_SLOWDOWN, 6, 120);
        a("absolute_zero", "Cero Absoluto", "Congela por completo a todos a tu alrededor.", 100, 120, Kind.FREEZE)
                .r(16).p(ParticleTypes.SNOWFLAKE).foe(MobEffects.MOVEMENT_SLOWDOWN, 6, 200);
        // --- cielo (LIGHTNING / METEOR / PILLAR)
        a("thunder_strike", "Rayos Celestes", "Cinco rayos caen sobre tus enemigos.", 50, 40, Kind.LIGHTNING)
                .r(24).d(30).n(5);
        a("starfall", "Lluvia de Estrellas", "Estrellas cayendo del cielo.", 80, 70, Kind.METEOR)
                .r(18).d(25).n(10).p(ParticleTypes.END_ROD);
        a("solar_flare", "Llamarada Solar", "Una columna de fuego cae del cielo donde miras.", 60, 50, Kind.PILLAR)
                .r(6).d(60).fire().p(ParticleTypes.FLAME);
        // --- vida (DRAIN)
        a("soul_drain", "Drenar Almas", "Robas vida a los enemigos cercanos.", 50, 45, Kind.DRAIN)
                .r(10).d(14).p(ParticleTypes.SOUL_FIRE_FLAME);
        a("blood_pact", "Pacto de Sangre", "Un drenaje m\u00e1s fuerte.", 70, 60, Kind.DRAIN)
                .r(12).d(26).p(ParticleTypes.SOUL_FIRE_FLAME);
    }

    private DraconicAbilities() {}

    public static Ability get(String id) {
        return ALL.get(id);
    }

    public static boolean exists(String id) {
        return ALL.containsKey(id);
    }

    public static List<Ability> all() {
        return new ArrayList<>(ALL.values());
    }

    public static List<String> ids() {
        return new ArrayList<>(ALL.keySet());
    }

    // ---------------------------------------------------------------- aprender y lanzar

    /** Aprende una habilidad gastando puntos draconianos. Hace falta la Marca del Jinete. */
    public static boolean learn(ServerPlayer player, String id) {
        Ability ability = ALL.get(id);
        if (ability == null) {
            return false;
        }
        if (!DraconicData.hasMark(player)) {
            player.displayClientMessage(Component.literal("\u00a7cSolo los jinetes de drag\u00f3n (con la Marca del Jinete) pueden leer este manuscrito."), true);
            return false;
        }
        if (DraconicData.hasAbility(player, id)) {
            player.displayClientMessage(Component.literal("\u00a7eYa conoces " + ability.nameEs + "."), true);
            return false;
        }
        int half = ability.costPoints * 2;
        if (DraconicData.getHalfPoints(player) < half) {
            player.displayClientMessage(Component.literal("\u00a7cNecesitas " + ability.costPoints + " puntos draconianos para aprender " + ability.nameEs + "."), true);
            return false;
        }
        DraconicData.addHalfPoints(player, -half);
        DraconicData.unlockAbility(player, id);
        player.displayClientMessage(Component.literal("\u00a76\u00a1Has aprendido " + ability.nameEs + "! \u00a77(tecla de habilidad para usarla)"), false);
        return true;
    }

    /** Usa la habilidad seleccionada. */
    public static boolean castSelected(ServerPlayer player) {
        String id = DraconicData.getSelectedAbility(player);
        if (id.isEmpty()) {
            player.displayClientMessage(Component.literal("\u00a7cAún no conoces ninguna habilidad draconiana."), true);
            return false;
        }
        return cast(player, id);
    }

    public static boolean cast(ServerPlayer player, String id) {
        Ability ability = ALL.get(id);
        if (ability == null || !DraconicData.hasAbility(player, id)) {
            return false;
        }
        ServerLevel level = player.serverLevel();
        long now = level.getGameTime();
        long until = DraconicData.getCooldownUntil(player, id);
        if (until > now) {
            long seconds = (until - now + 19) / 20;
            player.displayClientMessage(Component.literal("\u00a7c" + ability.nameEs + " se recarga: " + seconds + " s"), true);
            return false;
        }
        run(player, level, ability);
        DraconicData.setCooldownUntil(player, id, now + ability.cooldownSec * 20L);
        player.displayClientMessage(Component.literal("\u00a76" + ability.nameEs + "!"), true);
        return true;
    }

    // ---------------------------------------------------------------- ejecucion

    private static boolean isProtected(ServerPlayer owner, LivingEntity entity) {
        if (entity == owner) {
            return true;
        }
        if (entity instanceof OwnableEntity pet && pet.getOwnerUUID() != null && pet.getOwnerUUID().equals(owner.getUUID())) {
            return true;
        }
        return entity instanceof Player && !owner.server.isPvpAllowed();
    }

    private static List<LivingEntity> enemies(ServerPlayer player, ServerLevel level, Vec3 center, double radius) {
        AABB box = new AABB(center, center).inflate(radius);
        List<LivingEntity> found = new ArrayList<>();
        for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, box, LivingEntity::isAlive)) {
            if (!isProtected(player, entity) && entity.position().distanceTo(center) <= radius + entity.getBbWidth()) {
                found.add(entity);
            }
        }
        return found;
    }

    private static void hit(ServerPlayer player, ServerLevel level, LivingEntity victim, Ability ability, float damage) {
        if (damage > 0.0F) {
            victim.hurt(level.damageSources().indirectMagic(player, player), damage);
        }
        if (ability.fire) {
            victim.setSecondsOnFire(6);
        }
        if (ability.foeEffect != null) {
            victim.addEffect(new MobEffectInstance(ability.foeEffect, ability.foeTicks, ability.foeAmp));
        }
    }

    private static void knock(Vec3 from, LivingEntity victim, double power, double lift) {
        Vec3 away = victim.position().subtract(from);
        Vec3 flat = new Vec3(away.x, 0.0D, away.z);
        flat = flat.lengthSqr() < 1.0E-4D ? new Vec3(0.0D, 0.0D, 1.0D) : flat.normalize();
        victim.push(flat.x * power, 0.25D + lift, flat.z * power);
        victim.hurtMarked = true;
    }

    private static void ring(ServerLevel level, ParticleOptions particle, Vec3 center, double radius, int points) {
        for (int i = 0; i < points; i++) {
            double angle = i * (Math.PI * 2.0D / points);
            level.sendParticles(particle, center.x + Math.cos(angle) * radius, center.y + 0.3D,
                    center.z + Math.sin(angle) * radius, 1, 0.0D, 0.1D, 0.0D, 0.02D);
        }
    }

    private static void sound(ServerLevel level, Vec3 at, SoundEvent event, float volume, float pitch) {
        level.playSound(null, at.x, at.y, at.z, event, SoundSource.PLAYERS, volume, pitch);
    }

    private static void applySelf(ServerPlayer player, ServerLevel level, Ability ability) {
        for (MobEffectInstance effect : ability.selfEffects) {
            player.addEffect(new MobEffectInstance(effect));
        }
        if (ability.allies) {
            for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(ability.radius))) {
                if (entity != player && entity instanceof OwnableEntity pet && player.getUUID().equals(pet.getOwnerUUID())) {
                    for (MobEffectInstance effect : ability.selfEffects) {
                        entity.addEffect(new MobEffectInstance(effect));
                    }
                }
            }
        }
    }

    private static void run(ServerPlayer player, ServerLevel level, Ability ability) {
        Vec3 pos = player.position();
        Vec3 chest = pos.add(0.0D, player.getBbHeight() * 0.5D, 0.0D);
        Vec3 look = player.getLookAngle();
        switch (ability.kind) {
            case NOVA -> {
                level.sendParticles(ability.particle, pos.x, pos.y + 1.0D, pos.z, 6, 2.0D, 1.0D, 2.0D, 0.0D);
                for (double r = 4.0D; r <= ability.radius; r += 4.0D) {
                    ring(level, ParticleTypes.EXPLOSION, pos, r, (int) (r * 3));
                    ring(level, ParticleTypes.FLAME, pos, r, (int) (r * 2));
                }
                sound(level, pos, SoundEvents.GENERIC_EXPLODE, 6.0F, 0.6F);
                sound(level, pos, SoundEvents.DRAGON_FIREBALL_EXPLODE, 6.0F, 0.5F);
                for (LivingEntity victim : enemies(player, level, pos, ability.radius)) {
                    hit(player, level, victim, ability, ability.damage);
                    knock(pos, victim, ability.knock, 0.5D);
                }
            }
            case PULSE -> {
                ring(level, ability.particle, pos, ability.radius * 0.5D, 24);
                ring(level, ability.particle, pos, ability.radius, 48);
                level.sendParticles(ability.particle, pos.x, pos.y + 1.0D, pos.z, 40, ability.radius * 0.3D, 0.6D, ability.radius * 0.3D, 0.05D);
                sound(level, pos, SoundEvents.ENDER_DRAGON_GROWL, 1.0F, 1.4F);
                for (LivingEntity victim : enemies(player, level, pos, ability.radius)) {
                    hit(player, level, victim, ability, ability.damage);
                    if (ability.knock > 0.0D) {
                        knock(pos, victim, ability.knock, ability.kind == Kind.PULSE && ability.id.equals("earthquake") ? 0.9D : 0.2D);
                    }
                }
                applySelf(player, level, ability);
            }
            case BEAM -> {
                Vec3 eye = player.getEyePosition();
                HitResult clip = level.clip(new ClipContext(eye, eye.add(look.scale(ability.radius)),
                        ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
                double len = clip.getType() == HitResult.Type.MISS ? ability.radius : clip.getLocation().distanceTo(eye);
                for (double t = 1.0D; t < len; t += 0.6D) {
                    Vec3 p = eye.add(look.scale(t));
                    level.sendParticles(ability.particle, p.x, p.y, p.z, 2, 0.1D, 0.1D, 0.1D, 0.0D);
                }
                Vec3 end = eye.add(look.scale(len));
                level.sendParticles(ParticleTypes.EXPLOSION, end.x, end.y, end.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
                sound(level, pos, SoundEvents.ENDER_DRAGON_SHOOT, 1.2F, 1.0F);
                for (LivingEntity victim : enemies(player, level, eye.add(look.scale(len * 0.5D)), len * 0.5D + 3.0D)) {
                    Vec3 to = victim.getBoundingBox().getCenter().subtract(eye);
                    double proj = to.dot(look);
                    if (proj < 0.0D || proj > len + 1.0D) {
                        continue;
                    }
                    if (to.subtract(look.scale(proj)).length() <= 1.6D + victim.getBbWidth() * 0.5D) {
                        hit(player, level, victim, ability, ability.damage);
                    }
                }
            }
            case BUFF -> {
                level.sendParticles(ability.particle, pos.x, pos.y + 1.0D, pos.z, 40, 0.6D, 1.0D, 0.6D, 0.1D);
                sound(level, pos, SoundEvents.BEACON_POWER_SELECT, 1.0F, 1.2F);
                applySelf(player, level, ability);
            }
            case HEAL -> {
                level.sendParticles(ability.particle, pos.x, pos.y + 1.0D, pos.z, 50, ability.radius * 0.2D, 1.0D, ability.radius * 0.2D, 0.05D);
                ring(level, ability.particle, pos, ability.radius, 40);
                sound(level, pos, SoundEvents.BEACON_ACTIVATE, 1.0F, 1.4F);
                player.heal(ability.damage);
                for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(ability.radius))) {
                    if (entity != player && entity instanceof OwnableEntity pet && player.getUUID().equals(pet.getOwnerUUID())) {
                        entity.heal(ability.damage);
                    }
                }
                applySelf(player, level, ability);
            }
            case CLEANSE -> {
                level.sendParticles(ability.particle, pos.x, pos.y + 1.0D, pos.z, 80, 0.6D, 1.0D, 0.6D, 0.3D);
                sound(level, pos, SoundEvents.TOTEM_USE, 0.8F, 1.3F);
                List<MobEffect> bad = new ArrayList<>();
                for (MobEffectInstance effect : player.getActiveEffects()) {
                    if (!effect.getEffect().isBeneficial()) {
                        bad.add(effect.getEffect());
                    }
                }
                for (MobEffect effect : bad) {
                    player.removeEffect(effect);
                }
                player.heal(player.getMaxHealth());
                player.getFoodData().setFoodLevel(20);
            }
            case TELEPORT -> {
                Vec3 eye = player.getEyePosition();
                HitResult clip = level.clip(new ClipContext(eye, eye.add(look.scale(ability.radius)),
                        ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
                Vec3 end = clip.getType() == HitResult.Type.MISS ? eye.add(look.scale(ability.radius)) : clip.getLocation().subtract(look.scale(0.8D));
                level.sendParticles(ability.particle, pos.x, pos.y + 1.0D, pos.z, 60, 0.4D, 0.8D, 0.4D, 0.3D);
                player.teleportTo(end.x, end.y - player.getEyeHeight(), end.z);
                player.fallDistance = 0.0F;
                level.sendParticles(ability.particle, end.x, end.y, end.z, 60, 0.4D, 0.8D, 0.4D, 0.3D);
                sound(level, end, SoundEvents.ENDERMAN_TELEPORT, 1.0F, 1.0F);
            }
            case LEAP -> {
                Vec3 flat = new Vec3(look.x, 0.0D, look.z).normalize().scale(ability.radius);
                player.setDeltaMovement(flat.x, 0.9D, flat.z);
                player.hurtMarked = true;
                player.fallDistance = 0.0F;
            }
            case DASH -> {
                level.sendParticles(ability.particle, pos.x, pos.y + 1.0D, pos.z, 40, 0.4D, 0.4D, 0.4D, 0.1D);
                for (LivingEntity victim : enemies(player, level, chest.add(look.scale(2.5D)), 3.5D)) {
                    hit(player, level, victim, ability, ability.damage);
                    knock(pos, victim, 0.8D, 0.3D);
                }
                player.setDeltaMovement(look.scale(ability.radius));
                player.hurtMarked = true;
                player.fallDistance = 0.0F;
                sound(level, pos, SoundEvents.FIREWORK_ROCKET_LAUNCH, 1.0F, 1.0F);
            }
            case PULL -> {
                level.sendParticles(ability.particle, pos.x, pos.y + 1.0D, pos.z, 120, ability.radius * 0.3D, 1.0D, ability.radius * 0.3D, 0.4D);
                ring(level, ability.particle, pos, ability.radius, 60);
                sound(level, pos, SoundEvents.ENDER_DRAGON_GROWL, 1.0F, 0.5F);
                for (LivingEntity victim : enemies(player, level, pos, ability.radius)) {
                    Vec3 toward = chest.subtract(victim.position()).normalize();
                    victim.setDeltaMovement(toward.scale(1.3D));
                    victim.hurtMarked = true;
                    hit(player, level, victim, ability, ability.damage);
                }
            }
            case FREEZE -> {
                ring(level, ability.particle, pos, ability.radius, 60);
                level.sendParticles(ability.particle, pos.x, pos.y + 1.0D, pos.z, 120, ability.radius * 0.3D, 1.0D, ability.radius * 0.3D, 0.1D);
                sound(level, pos, SoundEvents.BEACON_DEACTIVATE, 1.5F, 0.6F);
                for (LivingEntity victim : enemies(player, level, pos, ability.radius)) {
                    hit(player, level, victim, ability, 0.0F);
                    victim.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, ability.foeTicks, 4));
                    victim.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, ability.foeTicks, 2));
                    victim.addEffect(new MobEffectInstance(MobEffects.GLOWING, ability.foeTicks, 0));
                }
            }
            case LIGHTNING -> {
                List<LivingEntity> targets = enemies(player, level, pos, ability.radius);
                targets.sort(Comparator.comparingDouble(e -> e.distanceToSqr(player)));
                int strikes = 0;
                for (LivingEntity victim : targets) {
                    if (strikes++ >= ability.count) {
                        break;
                    }
                    LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
                    if (bolt != null) {
                        bolt.moveTo(victim.getX(), victim.getY(), victim.getZ());
                        bolt.setVisualOnly(true);
                        level.addFreshEntity(bolt);
                    }
                    hit(player, level, victim, ability, ability.damage);
                }
                if (targets.isEmpty()) {
                    player.displayClientMessage(Component.literal("\u00a77No hay enemigos a tiro."), true);
                }
            }
            case METEOR -> {
                for (int i = 0; i < ability.count; i++) {
                    double ox = (level.random.nextDouble() - 0.5D) * 2.0D * ability.radius;
                    double oz = (level.random.nextDouble() - 0.5D) * 2.0D * ability.radius;
                    impact(player, level, new Vec3(pos.x + ox, pos.y, pos.z + oz), ability, 3.5D);
                }
            }
            case PILLAR -> {
                Vec3 eye = player.getEyePosition();
                HitResult clip = level.clip(new ClipContext(eye, eye.add(look.scale(40.0D)),
                        ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
                Vec3 target = clip.getType() == HitResult.Type.MISS ? eye.add(look.scale(25.0D)) : clip.getLocation();
                for (int y = 0; y < 24; y += 2) {
                    level.sendParticles(ability.particle, target.x, target.y + y, target.z, 30, ability.radius * 0.25D, 0.5D, ability.radius * 0.25D, 0.02D);
                }
                impact(player, level, target, ability, ability.radius);
            }
            case DRAIN -> {
                ring(level, ability.particle, pos, ability.radius, 40);
                sound(level, pos, SoundEvents.WITHER_AMBIENT, 0.8F, 1.4F);
                float healed = 0.0F;
                for (LivingEntity victim : enemies(player, level, pos, ability.radius)) {
                    hit(player, level, victim, ability, ability.damage);
                    healed += ability.damage * 0.3F;
                    level.sendParticles(ability.particle, victim.getX(), victim.getY() + 1.0D, victim.getZ(), 8, 0.2D, 0.4D, 0.2D, 0.05D);
                }
                player.heal(Math.min(healed, player.getMaxHealth() * 0.6F));
            }
        }
    }

    private static void impact(ServerPlayer player, ServerLevel level, Vec3 at, Ability ability, double radius) {
        level.sendParticles(ParticleTypes.EXPLOSION, at.x, at.y + 1.0D, at.z, 2, 0.5D, 0.5D, 0.5D, 0.0D);
        level.sendParticles(ability.particle, at.x, at.y + 1.0D, at.z, 30, radius * 0.3D, 0.6D, radius * 0.3D, 0.1D);
        sound(level, at, SoundEvents.GENERIC_EXPLODE, 1.0F, 1.0F);
        for (LivingEntity victim : enemies(player, level, at, radius)) {
            hit(player, level, victim, ability, ability.damage);
            knock(at, victim, 0.6D, 0.3D);
        }
    }
}
