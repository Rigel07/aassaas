package com.isladragoncitos.network;

import com.isladragoncitos.abilities.DraconicAbilities;
import com.isladragoncitos.system.DraconicData;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** Cliente -> servidor: lanzar (0) o cambiar (1) la habilidad draconiana seleccionada. */
public record AbilityPacket(int action) {
    public static final int CAST = 0;
    public static final int CYCLE = 1;

    public static void encode(AbilityPacket packet, FriendlyByteBuf buf) {
        buf.writeVarInt(packet.action());
    }

    public static AbilityPacket decode(FriendlyByteBuf buf) {
        return new AbilityPacket(buf.readVarInt());
    }

    public static void handle(AbilityPacket packet, Supplier<NetworkEvent.Context> context) {
        NetworkEvent.Context ctx = context.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player == null) {
                return;
            }
            if (packet.action() == CAST) {
                DraconicAbilities.castSelected(player);
            } else {
                String next = DraconicData.cycleAbility(player);
                var ability = DraconicAbilities.get(next);
                player.displayClientMessage(Component.literal(ability == null
                        ? "\u00a7cAún no conoces ninguna habilidad."
                        : "\u00a76Habilidad: \u00a7f" + ability.nameEs), true);
            }
        });
        ctx.setPacketHandled(true);
    }
}
