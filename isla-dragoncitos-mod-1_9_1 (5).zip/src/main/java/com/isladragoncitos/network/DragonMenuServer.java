package com.isladragoncitos.network;

import com.isladragoncitos.entity.AncientDragonEntity;
import com.isladragoncitos.island.Island;
import com.isladragoncitos.island.IslandRegistry;
import com.isladragoncitos.system.DraconicData;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;

/**
 * Logica del menu del dragon en el servidor. Las acciones se validan aqui (nunca se ejecuta texto del cliente)
 * y reutilizan los comandos /dragon, asi el menu y los comandos siempre hacen exactamente lo mismo.
 */
public final class DragonMenuServer {
    private static final Set<String> ORDERS = Set.of("seguir", "quedarse", "deambular", "explorar", "parar", "buscar");
    private static final Set<String> STATS = Set.of("fuerza", "velocidad", "vida", "escamas", "vida_compartida");

    private DragonMenuServer() {}

    public static void handle(ServerPlayer player, DragonRequestPacket request) {
        String message = request.kind() == DragonRequestPacket.OPEN ? "" : run(player, request);
        ModNetwork.sendTo(player, new DragonMenuPacket(build(player, message)));
    }

    private static String run(ServerPlayer player, DragonRequestPacket request) {
        String command = null;
        switch (request.kind()) {
            case DragonRequestPacket.ORDER -> {
                if (ORDERS.contains(request.arg())) {
                    command = "dragon " + request.arg();
                }
            }
            case DragonRequestPacket.UPGRADE -> {
                if (STATS.contains(request.arg())) {
                    command = "dragon mejorar " + request.arg() + " " + Mth.clamp(request.amount(), 1, 1000);
                }
            }
            case DragonRequestPacket.GOTO -> {
                for (String name : islandNames(player)) {
                    if (name.equals(request.arg())) {
                        command = "dragon ir " + name;
                    }
                }
            }
            case DragonRequestPacket.SELECT -> {
                List<AncientDragonEntity> all = DraconicData.findDragons(player);
                if (!all.isEmpty()) {
                    DraconicData.selectDragon(player, all.get(Mth.clamp(request.amount(), 0, all.size() - 1)));
                }
                return "";
            }
            default -> {
            }
        }
        if (command == null) {
            return "";
        }
        Capture capture = new Capture();
        CommandSourceStack stack = new CommandSourceStack(capture, player.position(), player.getRotationVector(),
                player.serverLevel(), 0, player.getName().getString(), player.getDisplayName(), player.server, player);
        player.server.getCommands().performPrefixedCommand(stack, command);
        return capture.last;
    }

    private static List<String> islandNames(ServerPlayer player) {
        List<String> names = new ArrayList<>();
        for (Island island : IslandRegistry.get(player.server).all()) {
            if (island.canAccess(player.getUUID()) && !names.contains(island.name)) {
                names.add(island.name);
            }
        }
        return names;
    }

    private static DragonMenuInfo build(ServerPlayer player, String message) {
        AncientDragonEntity dragon = DraconicData.findDragon(player);
        if (dragon == null) {
            return DragonMenuInfo.none("No encuentro a tu dragon: esta lejos, dentro del baculo o aun no tienes uno.");
        }
        List<AncientDragonEntity> all = DraconicData.findDragons(player);
        List<Integer> types = new ArrayList<>();
        for (AncientDragonEntity owned : all) {
            types.add(owned.getDragonType());
        }
        return new DragonMenuInfo(true, dragon.getDragonType(), dragon.getVisualScale(), dragon.getFood(),
                (int) Math.ceil(dragon.getHealth()), (int) Math.ceil(dragon.getMaxHealth()),
                DraconicData.getHalfPoints(player), DraconicData.islandsFound(player), DraconicData.hasMark(player),
                dragon.getStrengthLvl(), dragon.getSpeedLvl(), dragon.getHealthLvl(), dragon.getScales(),
                dragon.hasSharedLife(), dragon.getMode(), islandNames(player), message, Math.max(0, all.indexOf(dragon)), types);
    }

    /** Recoge el ultimo mensaje que el comando le habria enviado al chat para mostrarlo dentro del menu. */
    private static final class Capture implements CommandSource {
        String last = "";

        @Override
        public void sendSystemMessage(Component component) {
            this.last = component.getString().replaceAll("\u00a7.", "");
        }

        @Override
        public boolean acceptsSuccess() {
            return true;
        }

        @Override
        public boolean acceptsFailure() {
            return true;
        }

        @Override
        public boolean shouldInformAdmins() {
            return false;
        }
    }
}
