package com.isladragoncitos.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** Cliente -> servidor: abrir el menu, dar una orden, mejorar una habilidad, ir a una isla o cambiar de dragon. */
public record DragonRequestPacket(int kind, String arg, int amount) {
    public static final int OPEN = 0;
    public static final int ORDER = 1;
    public static final int UPGRADE = 2;
    public static final int GOTO = 3;
    /** Elegir otro dragon del jugador: {@code amount} es su posicion (0, 1, 2...). */
    public static final int SELECT = 4;

    public static void encode(DragonRequestPacket packet, FriendlyByteBuf buf) {
        buf.writeVarInt(packet.kind);
        buf.writeUtf(packet.arg, 64);
        buf.writeVarInt(packet.amount);
    }

    public static DragonRequestPacket decode(FriendlyByteBuf buf) {
        return new DragonRequestPacket(buf.readVarInt(), buf.readUtf(64), buf.readVarInt());
    }

    public static void handle(DragonRequestPacket packet, Supplier<NetworkEvent.Context> context) {
        ServerPlayer sender = context.get().getSender();
        if (sender != null) {
            context.get().enqueueWork(() -> DragonMenuServer.handle(sender, packet));
        }
        context.get().setPacketHandled(true);
    }
}
