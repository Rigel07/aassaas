package com.isladragoncitos.entity;

import com.isladragoncitos.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.MoveTowardsRestrictionGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;

/**
 * Elfo de Alfheim: la raza que vive en las ciudades del Gran Arbol del Mundo y en los castillos elficos.
 * Son pacificos, pero defienden su hogar. Si les das una manzana dorada, te corresponden con un regalo.
 */
public class ElfEntity extends PathfinderMob {
    public static final int VARIANTS = 3; // 0 guardian, 1 sabio, 2 jardinero
    private static final EntityDataAccessor<Integer> VARIANT = SynchedEntityData.defineId(ElfEntity.class, EntityDataSerializers.INT);

    public ElfEntity(EntityType<? extends ElfEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 26.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.ATTACK_DAMAGE, 4.0D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.15D, true));
        this.goalSelector.addGoal(4, new MoveTowardsRestrictionGoal(this, 1.0D));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Monster.class, true));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(VARIANT, 0);
    }

    public int getVariant() {
        return this.entityData.get(VARIANT);
    }

    public void setVariant(int variant) {
        this.entityData.set(VARIANT, Math.floorMod(variant, VARIANTS));
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Variant", this.getVariant());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setVariant(tag.getInt("Variant"));
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        SpawnGroupData data, CompoundTag tag) {
        if (reason != MobSpawnType.STRUCTURE) {
            this.setVariant(this.random.nextInt(VARIANTS));
        }
        if (this.getVariant() == 0) {
            this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.GOLDEN_SWORD));
        } else if (this.getVariant() == 1) {
            this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.BOOK));
        } else {
            this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.GOLDEN_CARROT));
        }
        this.restrictTo(this.blockPosition(), 26);
        return super.finalizeSpawn(level, difficulty, reason, data, tag);
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        boolean apple = stack.is(Items.GOLDEN_APPLE) || stack.is(Items.ENCHANTED_GOLDEN_APPLE);
        if (apple) {
            if (!this.level().isClientSide) {
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
                this.giveGift(player);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        if (!this.level().isClientSide && hand == InteractionHand.MAIN_HAND) {
            player.displayClientMessage(Component.translatable("message.isladragoncitos.elf_line_" + this.random.nextInt(7)), true);
        }
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }

    private void giveGift(Player player) {
        ItemStack gift;
        switch (this.random.nextInt(8)) {
            case 0 -> gift = new ItemStack(Items.ARROW, 16);
            case 1 -> gift = new ItemStack(Items.GOLDEN_CARROT, 6);
            case 2 -> gift = new ItemStack(Items.EMERALD, 3);
            case 3 -> gift = new ItemStack(Items.EXPERIENCE_BOTTLE, 4);
            case 4 -> gift = new ItemStack(Items.GLOW_BERRIES, 10);
            case 5 -> gift = new ItemStack(this.random.nextBoolean() ? ModItems.PINK_DRAGON_SCALE.get() : ModItems.BLUE_DRAGON_SCALE.get(), 2);
            case 6 -> gift = new ItemStack(this.random.nextBoolean() ? ModItems.GREEN_DRAGON_SCALE.get() : ModItems.RED_DRAGON_SCALE.get(), 2);
            default -> gift = new ItemStack(Items.AMETHYST_SHARD, 6);
        }
        if (!player.addItem(gift)) {
            player.drop(gift, false);
        }
        player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1));
        if (this.level() instanceof ServerLevel server) {
            server.sendParticles(net.minecraft.core.particles.ParticleTypes.HAPPY_VILLAGER, this.getX(), this.getY() + 1.6D, this.getZ(),
                    10, 0.4D, 0.4D, 0.4D, 0.05D);
        }
        this.playSound(SoundEvents.VILLAGER_YES, 1.0F, 1.25F);
        player.displayClientMessage(Component.translatable("message.isladragoncitos.elf_gift"), true);
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    /** Viven en plataformas altisimas: no se hacen dano al caer. */
    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.VILLAGER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.VILLAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.VILLAGER_DEATH;
    }
}
