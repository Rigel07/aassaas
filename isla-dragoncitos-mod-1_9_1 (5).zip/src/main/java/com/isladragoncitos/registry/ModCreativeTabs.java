package com.isladragoncitos.registry;

import com.isladragoncitos.IslaDragoncitosMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, IslaDragoncitosMod.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("isla_dragoncitos",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.isladragoncitos"))
                    .icon(() -> new ItemStack(ModItems.PINK_DRAGON_SCALE.get()))
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.DRAGONCITO_SPAWN_EGG.get());
                        output.accept(ModItems.PINK_DRAGON_SCALE.get());
                        output.accept(ModItems.GREEN_DRAGON_SCALE.get());
                        output.accept(ModItems.BLUE_DRAGON_SCALE.get());
                        output.accept(ModItems.RED_DRAGON_SCALE.get());
                        output.accept(ModItems.PINK_AMULET.get());
                        output.accept(ModItems.GREEN_AMULET.get());
                        output.accept(ModItems.BLUE_AMULET.get());
                        output.accept(ModItems.RED_AMULET.get());
                        output.accept(ModItems.DRAGON_COMPASS.get());
                        output.accept(ModItems.DRAGON_RIDER.get());
                        output.accept(ModItems.DRAGON_STAFF.get());
                        output.accept(ModItems.EDULNARI.get());
                        output.accept(ModItems.FIRE_EGG.get());
                        output.accept(ModItems.ICE_EGG.get());
                        output.accept(ModItems.STORM_EGG.get());
                        output.accept(ModItems.WATER_EGG.get());
                        output.accept(ModItems.ANCIENT_DRAGON_SPAWN_EGG.get());
                        output.accept(ModItems.WORSHIPPER_SPAWN_EGG.get());
                        output.accept(ModItems.LIFE_TREE_HEART.get());
                        output.accept(ModItems.DRAGON_CODEX.get());
                        output.accept(ModItems.DRAGON_ESSENCE.get());
                        output.accept(ModItems.TIME_SHARD.get());
                        output.accept(ModItems.COSMIC_DUST.get());
                        output.accept(ModItems.VOID_CORE.get());
                        output.accept(ModItems.SOLAR_FLAKE.get());
                        output.accept(ModItems.LUNAR_TEAR.get());
                        output.accept(ModItems.CHRONOS_SICKLE.get());
                        output.accept(ModItems.OMEGA_PLATE.get());
                        output.accept(ModItems.PSYCHE_CROWN.get());
                        output.accept(ModItems.FORTUNA_COIN.get());
                        output.accept(ModItems.DRACONIC_MANUSCRIPT.get());
                        for (String abilityId : com.isladragoncitos.abilities.DraconicAbilities.ids()) {
                            output.accept(com.isladragoncitos.item.DraconicManuscriptItem.of(abilityId));
                        }
                        output.accept(ModItems.PINK_SCALE_BLOCK.get());
                        output.accept(ModItems.GREEN_SCALE_BLOCK.get());
                        output.accept(ModItems.BLUE_SCALE_BLOCK.get());
                        output.accept(ModItems.RED_SCALE_BLOCK.get());
                        output.accept(ModItems.WORLD_TREE_LEAVES.get());
                        output.accept(ModItems.ELF_SPAWN_EGG.get());
                    })
                    .build());

    private ModCreativeTabs() {}
}
