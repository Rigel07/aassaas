package com.isladragoncitos.registry;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.entity.AncientDragonEntity;
import com.isladragoncitos.entity.DragonWorshipperEntity;
import com.isladragoncitos.entity.DragoncitoEntity;
import com.isladragoncitos.entity.ElfEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, IslaDragoncitosMod.MODID);

    public static final RegistryObject<EntityType<DragoncitoEntity>> DRAGONCITO = ENTITY_TYPES.register("dragoncito",
            () -> EntityType.Builder.<DragoncitoEntity>of(DragoncitoEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 0.7F)
                    .clientTrackingRange(8)
                    .build(IslaDragoncitosMod.MODID + ":dragoncito"));

    public static final RegistryObject<EntityType<AncientDragonEntity>> ANCIENT_DRAGON = ENTITY_TYPES.register("ancient_dragon",
            () -> EntityType.Builder.<AncientDragonEntity>of(AncientDragonEntity::new, MobCategory.CREATURE)
                    .sized(1.6F, 1.5F)
                    .fireImmune()
                    .clientTrackingRange(16)
                    .updateInterval(2)
                    .build(IslaDragoncitosMod.MODID + ":ancient_dragon"));

    public static final RegistryObject<EntityType<DragonWorshipperEntity>> WORSHIPPER = ENTITY_TYPES.register("worshipper",
            () -> EntityType.Builder.<DragonWorshipperEntity>of(DragonWorshipperEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.95F)
                    .clientTrackingRange(10)
                    .build(IslaDragoncitosMod.MODID + ":worshipper"));

    public static final RegistryObject<EntityType<ElfEntity>> ELF = ENTITY_TYPES.register("elf",
            () -> EntityType.Builder.<ElfEntity>of(ElfEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.95F)
                    .clientTrackingRange(10)
                    .build(IslaDragoncitosMod.MODID + ":elf"));

    private ModEntities() {}
}
