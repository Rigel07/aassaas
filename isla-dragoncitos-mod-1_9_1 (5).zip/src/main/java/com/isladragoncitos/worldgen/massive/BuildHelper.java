package com.isladragoncitos.worldgen.massive;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.BoundingBox;

/** Utilidades de construccion en coordenadas de mundo, siempre recortadas a la caja del trozo que se esta generando. */
final class BuildHelper {
    static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private final WorldGenLevel level;
    private final BoundingBox box;

    BuildHelper(WorldGenLevel level, BoundingBox box) {
        this.level = level;
        this.box = box;
    }

    boolean inside(int x, int y, int z) {
        return this.box.isInside(new BlockPos(x, y, z));
    }

    void set(int x, int y, int z, BlockState state) {
        if (y > this.level.getMinBuildHeight() && y < this.level.getMaxBuildHeight() - 1 && this.inside(x, y, z)) {
            this.level.setBlock(new BlockPos(x, y, z), state, 2);
        }
    }

    BlockState get(int x, int y, int z) {
        return this.inside(x, y, z) ? this.level.getBlockState(new BlockPos(x, y, z)) : AIR;
    }

    void fill(int x1, int y1, int z1, int x2, int y2, int z2, BlockState state) {
        for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++) {
            for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++) {
                for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++) {
                    this.set(x, y, z, state);
                }
            }
        }
    }

    /** Caja hueca: paredes, suelo y techo del mismo bloque, interior de aire. */
    void hollow(int x1, int y1, int z1, int x2, int y2, int z2, BlockState shell) {
        this.fill(x1, y1, z1, x2, y2, z2, shell);
        this.fill(x1 + 1, y1 + 1, z1 + 1, x2 - 1, y2 - 1, z2 - 1, AIR);
    }

    /** Altura de la superficie en una columna dentro de la caja (si no, -1). */
    int surface(int x, int z) {
        if (!this.inside(x, this.level.getMinBuildHeight() + 1, z) && !this.columnInside(x, z)) {
            return -1;
        }
        return this.level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z) - 1;
    }

    private boolean columnInside(int x, int z) {
        return x >= this.box.minX() && x <= this.box.maxX() && z >= this.box.minZ() && z <= this.box.maxZ();
    }

    /** Aplana una columna: quita lo que sobresale por encima de y0 y rellena hacia abajo hasta el terreno. */
    void foundation(int x, int z, int y0, int maxDepth, BlockState fillState) {
        if (!this.columnInside(x, z)) {
            return;
        }
        int ground = this.level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z) - 1;
        for (int y = y0; y <= Math.min(ground, y0 + 14); y++) {
            this.set(x, y, z, AIR);
        }
        for (int y = y0 - 1; y >= y0 - maxDepth; y--) {
            BlockState current = this.get(x, y, z);
            if (!current.isAir() && current.getFluidState().isEmpty() && !current.canBeReplaced()) {
                break;
            }
            this.set(x, y, z, fillState);
        }
    }

    void lootChest(int x, int y, int z, ResourceLocation table, RandomSource random) {
        if (!this.inside(x, y, z)) {
            return;
        }
        BlockPos pos = new BlockPos(x, y, z);
        this.level.setBlock(pos, Blocks.CHEST.defaultBlockState(), 2);
        RandomizableContainerBlockEntity.setLootTable(this.level, random, pos, table);
    }
}
