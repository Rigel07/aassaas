package com.isladragoncitos.worldgen.lifetree;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.registry.ModBlocks;
import com.isladragoncitos.registry.ModStructures;
import java.util.Random;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;

/** Pieza del Arbol de la Vida (se regenera siempre igual a partir de la semilla, asi encaja entre chunks). */
public class LifeTreePiece extends StructurePiece {
    private static final ResourceLocation LOOT = new ResourceLocation(IslaDragoncitosMod.MODID, "chests/life_tree");
    private static final int HEIGHT = 58;
    private static final BlockState LOG = Blocks.DARK_OAK_WOOD.defaultBlockState();
    private static final BlockState LEAVES = Blocks.OAK_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT, true);
    private static final BlockState BLOOM = Blocks.FLOWERING_AZALEA_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT, true);
    private static final BlockState AIR = Blocks.AIR.defaultBlockState();

    private int cx;
    private int y0;
    private int cz;
    private long seed;

    public LifeTreePiece(int cx, int y0, int cz, long seed) {
        super(ModStructures.LIFE_TREE_PIECE.get(), 0, new BoundingBox(cx - 36, y0 - 14, cz - 36, cx + 36, y0 + HEIGHT + 18, cz + 36));
        this.cx = cx;
        this.y0 = y0;
        this.cz = cz;
        this.seed = seed;
    }

    public LifeTreePiece(CompoundTag tag) {
        super(ModStructures.LIFE_TREE_PIECE.get(), tag);
        this.cx = tag.getInt("Cx");
        this.y0 = tag.getInt("Y0");
        this.cz = tag.getInt("Cz");
        this.seed = tag.getLong("Seed");
    }

    @Override
    protected void addAdditionalSaveData(StructurePieceSerializationContext context, CompoundTag tag) {
        tag.putInt("Cx", this.cx);
        tag.putInt("Y0", this.y0);
        tag.putInt("Cz", this.cz);
        tag.putLong("Seed", this.seed);
    }

    private void set(WorldGenLevel level, BoundingBox box, int x, int y, int z, BlockState state) {
        BlockPos pos = new BlockPos(x, y, z);
        if (y > level.getMinBuildHeight() && y < level.getMaxBuildHeight() - 1 && box.isInside(pos)) {
            level.setBlock(pos, state, 2);
        }
    }

    private BlockState axis(BlockState log, net.minecraft.core.Direction.Axis axis) {
        return log.setValue(RotatedPillarBlock.AXIS, axis);
    }

    @Override
    public void postProcess(WorldGenLevel level, StructureManager manager, ChunkGenerator generator, RandomSource random,
                            BoundingBox box, ChunkPos chunkPos, BlockPos pivot) {
        Random rnd = new Random(this.seed);
        int cx = this.cx;
        int cz = this.cz;
        int y0 = this.y0;

        // terreno bajo el arbol: musgo, tierra y raices
        for (int dx = -9; dx <= 9; dx++) {
            for (int dz = -9; dz <= 9; dz++) {
                if (dx * dx + dz * dz > 81 || !(cx + dx >= box.minX() && cx + dx <= box.maxX() && cz + dz >= box.minZ() && cz + dz <= box.maxZ())) {
                    continue;
                }
                int ground = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, cx + dx, cz + dz) - 1;
                for (int y = y0; y <= Math.min(ground, y0 + 12); y++) {
                    this.set(level, box, cx + dx, y, cz + dz, AIR);
                }
                for (int y = y0 - 1; y >= y0 - 10; y--) {
                    BlockPos p = new BlockPos(cx + dx, y, cz + dz);
                    if (!level.getBlockState(p).isAir() && level.getBlockState(p).getFluidState().isEmpty() && !level.getBlockState(p).canBeReplaced()) {
                        break;
                    }
                    this.set(level, box, cx + dx, y, cz + dz, y == y0 - 1 ? Blocks.MOSS_BLOCK.defaultBlockState() : Blocks.DIRT.defaultBlockState());
                }
            }
        }

        // tronco con una ligera curva
        int topSx = 0;
        int topSz = 0;
        for (int y = 0; y <= HEIGHT; y++) {
            double radius = 5.4D - 2.8D * ((double) y / HEIGHT);
            int sx = (int) Math.round(Math.sin(y * 0.07D) * 2.0D);
            int sz = (int) Math.round(Math.cos(y * 0.05D) * 2.0D - 2.0D);
            if (y == HEIGHT) {
                topSx = sx;
                topSz = sz + 2;
            }
            // la base no se desplaza para que la camara quede centrada
            double bend = Math.min(1.0D, y / 10.0D);
            int ox = (int) Math.round(sx * bend);
            int oz = (int) Math.round((sz + 2) * bend);
            int r = (int) Math.ceil(radius);
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (dx * dx + dz * dz <= radius * radius) {
                        this.set(level, box, cx + ox + dx, y0 + y, cz + oz + dz, LOG);
                    }
                }
            }
        }

        // camara del corazon
        for (int y = 1; y <= 5; y++) {
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    this.set(level, box, cx + dx, y0 + y, cz + dz, AIR);
                }
            }
        }
        for (int dz = 2; dz <= 6; dz++) {
            for (int dx = -1; dx <= 1; dx++) {
                for (int y = 1; y <= 3; y++) {
                    this.set(level, box, cx + dx, y0 + y, cz + dz, AIR);
                }
            }
        }
        this.set(level, box, cx, y0, cz, Blocks.GILDED_BLACKSTONE.defaultBlockState());
        this.set(level, box, cx, y0 + 1, cz, ModBlocks.LIFE_TREE_HEART.get().defaultBlockState());
        for (int[] corner : new int[][]{{-2, -2}, {2, -2}, {-2, 2}, {2, 2}}) {
            this.set(level, box, cx + corner[0], y0 + 4, cz + corner[1], Blocks.SHROOMLIGHT.defaultBlockState());
            this.set(level, box, cx + corner[0], y0, cz + corner[1], Blocks.MOSS_BLOCK.defaultBlockState());
        }
        BlockPos chest = new BlockPos(cx - 2, y0 + 1, cz - 1);
        if (box.isInside(chest)) {
            level.setBlock(chest, Blocks.CHEST.defaultBlockState(), 2);
            RandomizableContainerBlockEntity.setLootTable(level, random, chest, LOOT);
        }

        // raices
        for (int i = 0; i < 8; i++) {
            double angle = i * Math.PI / 4.0D + rnd.nextDouble() * 0.3D;
            for (int t = 3; t <= 16; t++) {
                int x = cx + (int) Math.round(Math.cos(angle) * (t + 2));
                int z = cz + (int) Math.round(Math.sin(angle) * (t + 2));
                int y = y0 + Math.max(-3, 3 - t / 2);
                this.set(level, box, x, y, z, LOG);
                this.set(level, box, x, y + 1, z, LOG);
            }
        }

        // ramas grandes + copas
        int canopyY = y0 + HEIGHT;
        for (int i = 0; i < 7; i++) {
            double angle = i * (Math.PI * 2.0D / 7.0D) + rnd.nextDouble() * 0.5D;
            int startY = y0 + 34 + rnd.nextInt(16);
            int length = 14 + rnd.nextInt(7);
            double rise = 0.35D + rnd.nextDouble() * 0.3D;
            int bx = cx;
            int bz = cz;
            int by = startY;
            for (int t = 0; t <= length; t++) {
                bx = cx + (int) Math.round(Math.cos(angle) * (3 + t));
                bz = cz + (int) Math.round(Math.sin(angle) * (3 + t));
                by = startY + (int) Math.round(t * rise);
                this.set(level, box, bx, by, bz, LOG);
                this.set(level, box, bx, by + 1, bz, LOG);
                if (t < length / 2) {
                    this.set(level, box, bx + 1, by, bz, LOG);
                    this.set(level, box, bx, by, bz + 1, LOG);
                }
            }
            this.blob(level, box, rnd, bx, by + 2, bz, 8 + rnd.nextInt(3), 6);
        }
        this.blob(level, box, rnd, cx + topSx, canopyY + 3, cz + topSz, 16, 10);
    }

    /** Copa de hojas: elipsoide con huecos, flores y frutos luminosos. */
    private void blob(WorldGenLevel level, BoundingBox box, Random rnd, int x, int y, int z, int radius, int ry) {
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -ry; dy <= ry; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    double d = (double) (dx * dx) / (radius * radius) + (double) (dy * dy) / (ry * ry) + (double) (dz * dz) / (radius * radius);
                    float roll = rnd.nextFloat();
                    if (d > 1.0D || (d > 0.78D && roll < 0.25F)) {
                        continue;
                    }
                    BlockPos pos = new BlockPos(x + dx, y + dy, z + dz);
                    if (!box.isInside(pos) || !level.getBlockState(pos).isAir() && !level.getBlockState(pos).canBeReplaced()) {
                        continue;
                    }
                    BlockState state = roll < 0.03F ? Blocks.SHROOMLIGHT.defaultBlockState() : (roll > 0.82F ? BLOOM : LEAVES);
                    this.set(level, box, pos.getX(), pos.getY(), pos.getZ(), state);
                }
            }
        }
    }
}
