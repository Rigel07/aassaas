package com.isladragoncitos.worldgen;

import com.isladragoncitos.registry.ModStructures;
import com.mojang.serialization.Codec;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;

/** El Gran Arbol del Mundo (Yggdrasil): aparece una sola vez por mundo. */
public class WorldTreeStructure extends Structure {
    public static final Codec<WorldTreeStructure> CODEC = simpleCodec(WorldTreeStructure::new);

    public WorldTreeStructure(Structure.StructureSettings settings) {
        super(settings);
    }

    @Override
    public StructureType<?> type() {
        return ModStructures.WORLD_TREE_TYPE.get();
    }

    @Override
    protected Optional<Structure.GenerationStub> findGenerationPoint(Structure.GenerationContext context) {
        ChunkPos chunk = context.chunkPos();
        int x = chunk.getMiddleBlockX();
        int z = chunk.getMiddleBlockZ();
        int ground = context.chunkGenerator().getFirstOccupiedHeight(x, z, Heightmap.Types.OCEAN_FLOOR_WG,
                context.heightAccessor(), context.randomState());
        // la base nunca queda por debajo del nivel del mar ni tan alta que el arbol se salga del mundo
        int baseY = Math.max(62, Math.min(ground, 66));
        long seed = context.random().nextLong();
        return Optional.of(new Structure.GenerationStub(new BlockPos(x, baseY, z),
                builder -> builder.addPiece(new WorldTreePiece(x, baseY, z, seed))));
    }
}
