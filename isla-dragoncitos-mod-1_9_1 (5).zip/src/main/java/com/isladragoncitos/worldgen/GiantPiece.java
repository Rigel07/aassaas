package com.isladragoncitos.worldgen;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.block.WorldTreeLeavesBlock;
import com.isladragoncitos.registry.ModBlocks;
import com.isladragoncitos.registry.ModEntities;
import com.isladragoncitos.registry.ModStructures;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;

/** Castillos y cuevas colosales del mundo de los dragoncitos. */
public class GiantPiece extends StructurePiece {
    public static final int CASTLE = 0;
    public static final int ELF_CASTLE = 1;
    public static final int HOARD = 2;
    public static final int CRYSTAL = 3;

    private static final ResourceLocation[] LOOT = {
            new ResourceLocation(IslaDragoncitosMod.MODID, "chests/castle_dragon"),
            new ResourceLocation(IslaDragoncitosMod.MODID, "chests/castle_elf"),
            new ResourceLocation(IslaDragoncitosMod.MODID, "chests/cave_hoard"),
            new ResourceLocation(IslaDragoncitosMod.MODID, "chests/cave_crystal")};
    private static final BlockState AIR = Blocks.AIR.defaultBlockState();

    private int kind;
    private int cx;
    private int y0;
    private int cz;
    private int rot;
    private long seed;
    private int cy;

    public GiantPiece(int kind, int cx, int surface, int cz, long seed, int rot) {
        super(ModStructures.GIANT_PIECE.get(), 0, boxFor(kind, cx, surface, cz));
        this.kind = kind;
        this.cx = cx;
        this.y0 = surface;
        this.cz = cz;
        this.seed = seed;
        this.rot = rot;
        this.cy = Math.max(surface - 34, 14);
    }

    public GiantPiece(CompoundTag tag) {
        super(ModStructures.GIANT_PIECE.get(), tag);
        this.kind = tag.getInt("Kind");
        this.cx = tag.getInt("Cx");
        this.y0 = tag.getInt("Y0");
        this.cz = tag.getInt("Cz");
        this.seed = tag.getLong("Seed");
        this.rot = tag.getInt("Rot");
        this.cy = Math.max(this.y0 - 34, 14);
    }

    private static BoundingBox boxFor(int kind, int cx, int surface, int cz) {
        if (kind >= HOARD) {
            int cy = Math.max(surface - 34, 14);
            return new BoundingBox(cx - 100, cy - 22, cz - 100, cx + 100, surface + 6, cz + 100);
        }
        return new BoundingBox(cx - 52, surface - 14, cz - 52, cx + 52, surface + 78, cz + 52);
    }

    @Override
    protected void addAdditionalSaveData(StructurePieceSerializationContext context, CompoundTag tag) {
        tag.putInt("Kind", this.kind);
        tag.putInt("Cx", this.cx);
        tag.putInt("Y0", this.y0);
        tag.putInt("Cz", this.cz);
        tag.putLong("Seed", this.seed);
        tag.putInt("Rot", this.rot);
    }

    // ------------------------------------------------------------------ utilidades

    private int wx(int u, int v) {
        switch (this.rot & 3) {
            case 0:
                return this.cx + u;
            case 1:
                return this.cx - v;
            case 2:
                return this.cx - u;
            default:
                return this.cx + v;
        }
    }

    private int wz(int u, int v) {
        switch (this.rot & 3) {
            case 0:
                return this.cz + v;
            case 1:
                return this.cz + u;
            case 2:
                return this.cz - v;
            default:
                return this.cz - u;
        }
    }

    private Direction fwd() {
        return new Direction[]{Direction.EAST, Direction.SOUTH, Direction.WEST, Direction.NORTH}[this.rot & 3];
    }

    private Direction toward(int du, int dv) {
        // direccion del mundo que corresponde a un vector local
        int x = this.wx(du, dv) - this.wx(0, 0);
        int z = this.wz(du, dv) - this.wz(0, 0);
        if (Math.abs(x) >= Math.abs(z)) {
            return x >= 0 ? Direction.EAST : Direction.WEST;
        }
        return z >= 0 ? Direction.SOUTH : Direction.NORTH;
    }

    private double rnd(int a, int b, int c) {
        long h = this.seed ^ ((long) a * 0x9E3779B97F4A7C15L) ^ ((long) b * 0xC2B2AE3D27D4EB4FL) ^ ((long) c * 0x165667B19E3779F9L);
        h ^= (h >>> 33);
        h *= 0xFF51AFD7ED558CCDL;
        h ^= (h >>> 33);
        h *= 0xC4CEB9FE1A85EC53L;
        h ^= (h >>> 33);
        return (h >>> 11) * (1.0D / (double) (1L << 53));
    }

    private void put(WorldGenLevel level, BoundingBox box, int x, int y, int z, BlockState state) {
        BlockPos pos = new BlockPos(x, y, z);
        if (box.isInside(pos)) {
            level.setBlock(pos, state, 2);
        }
    }

    private void set(WorldGenLevel level, BoundingBox box, int u, int y, int v, BlockState state) {
        this.put(level, box, this.wx(u, v), y, this.wz(u, v), state);
    }

    private void setDown(WorldGenLevel level, BoundingBox box, int u, int y, int v, BlockState state, int depth) {
        int x = this.wx(u, v);
        int z = this.wz(u, v);
        for (int i = 0; i <= depth; i++) {
            BlockPos pos = new BlockPos(x, y - i, z);
            if (!box.isInside(pos)) {
                continue;
            }
            BlockState current = level.getBlockState(pos);
            if (i > 0 && !(current.isAir() || current.canBeReplaced() || !current.getFluidState().isEmpty())) {
                break;
            }
            level.setBlock(pos, state, 2);
        }
    }

    private boolean inColumn(BoundingBox box, int u, int v) {
        int x = this.wx(u, v);
        int z = this.wz(u, v);
        return x >= box.minX() && x <= box.maxX() && z >= box.minZ() && z <= box.maxZ();
    }

    private void chest(WorldGenLevel level, BoundingBox box, RandomSource random, int u, int y, int v, Direction facing) {
        BlockPos pos = new BlockPos(this.wx(u, v), y, this.wz(u, v));
        this.createChest(level, box, random, pos, LOOT[this.kind & 3], Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, facing));
    }

    private void lectern(WorldGenLevel level, BoundingBox box, int u, int y, int v) {
        RiderLore.placeLectern(level, box, new BlockPos(this.wx(u, v), y, this.wz(u, v)), this.fwd(),
                (int) (this.rnd(u, y, v) * RiderLore.chapters()));
    }

    private void spawn(WorldGenLevel level, BoundingBox box, Mob mob, int u, int y, int v) {
        BlockPos pos = new BlockPos(this.wx(u, v), y, this.wz(u, v));
        if (mob == null || !box.isInside(pos)) {
            return;
        }
        mob.moveTo(pos.getX() + 0.5D, y, pos.getZ() + 0.5D, (float) (this.rnd(u, y, v) * 360.0D), 0.0F);
        mob.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), MobSpawnType.STRUCTURE, null, null);
        level.addFreshEntityWithPassengers(mob);
    }

    private BlockState scale(int i) {
        switch (Math.floorMod(i, 4)) {
            case 0:
                return ModBlocks.PINK_SCALE_BLOCK.get().defaultBlockState();
            case 1:
                return ModBlocks.GREEN_SCALE_BLOCK.get().defaultBlockState();
            case 2:
                return ModBlocks.BLUE_SCALE_BLOCK.get().defaultBlockState();
            default:
                return ModBlocks.RED_SCALE_BLOCK.get().defaultBlockState();
        }
    }

    private BlockState brick(int a, int b, int c) {
        double r = this.rnd(a, b, c);
        if (r < 0.55D) {
            return Blocks.STONE_BRICKS.defaultBlockState();
        }
        return r < 0.82D ? Blocks.MOSSY_STONE_BRICKS.defaultBlockState() : Blocks.CRACKED_STONE_BRICKS.defaultBlockState();
    }

    // ------------------------------------------------------------------ generacion

    @Override
    public void postProcess(WorldGenLevel level, StructureManager manager, ChunkGenerator generator, RandomSource random,
                            BoundingBox box, ChunkPos chunkPos, BlockPos pivot) {
        switch (this.kind) {
            case CASTLE -> this.buildCastle(level, box, random, false);
            case ELF_CASTLE -> this.buildCastle(level, box, random, true);
            case HOARD -> this.buildCave(level, box, random, false);
            default -> this.buildCave(level, box, random, true);
        }
    }

    // ---- torres cilindricas (coordenadas locales)

    private void tower(WorldGenLevel level, BoundingBox box, RandomSource random, int tu, int tv, int r, int height,
                       BlockState wall, BlockState band, BlockState roofA, BlockState roofB, boolean treasure) {
        int minX = Math.min(this.wx(tu - r - 1, tv - r - 1), this.wx(tu + r + 1, tv + r + 1));
        int maxX = Math.max(this.wx(tu - r - 1, tv - r - 1), this.wx(tu + r + 1, tv + r + 1));
        int minZ = Math.min(this.wz(tu - r - 1, tv - r - 1), this.wz(tu + r + 1, tv + r + 1));
        int maxZ = Math.max(this.wz(tu - r - 1, tv - r - 1), this.wz(tu + r + 1, tv + r + 1));
        if (maxX < box.minX() || minX > box.maxX() || maxZ < box.minZ() || minZ > box.maxZ()) {
            return;
        }
        BlockState ladder = Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, this.toward(-1, 0));
        for (int du = -r - 1; du <= r + 1; du++) {
            for (int dv = -r - 1; dv <= r + 1; dv++) {
                double dd = Math.sqrt((double) (du * du + dv * dv));
                if (dd > r + 0.5D || !this.inColumn(box, tu + du, tv + dv)) {
                    continue;
                }
                this.setDown(level, box, tu + du, this.y0 - 1, tv + dv, Blocks.STONE_BRICKS.defaultBlockState(), 10);
                for (int y = 0; y <= height; y++) {
                    BlockState s;
                    if (dd > r - 1.0D) {
                        if (dv == 0 && du < 0 && y >= 1 && y <= 3) {
                            s = AIR;
                        } else if (y % 7 == 0 && y > 0) {
                            s = band;
                        } else if (y % 7 >= 3 && y % 7 <= 4 && (du == 0 || dv == 0) && y > 2) {
                            s = Blocks.GLASS.defaultBlockState();
                        } else {
                            s = wall;
                        }
                    } else if (y == 0 || (y % 7 == 0 && !(du == r - 1 && dv == 0))) {
                        s = Blocks.SPRUCE_PLANKS.defaultBlockState();
                    } else if (du == r - 1 && dv == 0 && y < height) {
                        s = ladder;
                    } else {
                        s = AIR;
                    }
                    this.set(level, box, tu + du, this.y0 + y, tv + dv, s);
                }
            }
        }
        for (int j = 0; j <= r + 5; j++) {
            double rr = (r + 1.0D) * (1.0D - j / (r + 6.0D));
            for (int du = -r - 1; du <= r + 1; du++) {
                for (int dv = -r - 1; dv <= r + 1; dv++) {
                    if (Math.sqrt((double) (du * du + dv * dv)) <= rr + 0.3D) {
                        this.set(level, box, tu + du, this.y0 + height + 1 + j, tv + dv, (j & 1) == 0 ? roofA : roofB);
                    }
                }
            }
        }
        this.set(level, box, tu, this.y0 + height + r + 7, tv, Blocks.SEA_LANTERN.defaultBlockState());
        this.set(level, box, tu, this.y0 + 1, tv, Blocks.LANTERN.defaultBlockState());
        if (treasure) {
            this.chest(level, box, random, tu, this.y0 + 1, tv + 1, this.toward(0, -1));
        }
    }

    // ---- castillos

    private void buildCastle(WorldGenLevel level, BoundingBox box, RandomSource random, boolean elf) {
        int r = elf ? 37 : 45;
        BlockState wallBlock = elf ? Blocks.QUARTZ_BRICKS.defaultBlockState() : null;
        BlockState gold = Blocks.GOLD_BLOCK.defaultBlockState();
        for (int u = -r - 1; u <= r + 1; u++) {
            for (int v = -r - 1; v <= r + 1; v++) {
                if (!this.inColumn(box, u, v)) {
                    continue;
                }
                int m = Math.max(Math.abs(u), Math.abs(v));
                if (m <= r) {
                    BlockState floor;
                    if (Math.abs(u) <= 2 && v < 0 && v >= -r) {
                        floor = Blocks.POLISHED_ANDESITE.defaultBlockState();
                    } else if (elf) {
                        floor = ((u + v) & 1) == 0 ? Blocks.QUARTZ_BLOCK.defaultBlockState() : Blocks.SMOOTH_QUARTZ.defaultBlockState();
                        if (m > 5 && (u % 9 == 0 || v % 9 == 0) && this.rnd(u, 3, v) < 0.5D) {
                            floor = Blocks.GRASS_BLOCK.defaultBlockState();
                        }
                    } else {
                        floor = this.rnd(u, 1, v) < 0.45D ? Blocks.COBBLESTONE.defaultBlockState() : Blocks.MOSSY_COBBLESTONE.defaultBlockState();
                    }
                    this.setDown(level, box, u, this.y0 - 1, v, floor, 12);
                }
                if (m >= r - 2 && m <= r) {
                    int wallH = elf ? 6 : 11;
                    boolean gate = Math.abs(u) <= 3 && v < 0 && Math.abs(v) == m;
                    for (int h = 0; h <= wallH; h++) {
                        BlockState s;
                        boolean opening = gate && h >= 1 && h <= (elf ? 5 : 8);
                        if (elf && !gate && h >= 1 && h <= 3 && ((u + v + 1000) % 9) >= 3 && ((u + v + 1000) % 9) <= 5) {
                            opening = true;
                        }
                        if (opening) {
                            s = AIR;
                        } else if (elf) {
                            s = h == wallH ? gold : wallBlock;
                        } else {
                            s = this.brick(u, h, v);
                        }
                        this.set(level, box, u, this.y0 + h, v, s);
                    }
                    if (((u + v) & 1) == 0 && !gate) {
                        this.set(level, box, u, this.y0 + wallH + 1, v, elf ? wallBlock : this.brick(u, 40, v));
                        if (this.rnd(u, 7, v) < 0.08D) {
                            this.set(level, box, u, this.y0 + wallH + 2, v, Blocks.LANTERN.defaultBlockState());
                        }
                    }
                }
            }
        }
        if (elf) {
            this.buildElfCastle(level, box, random);
        } else {
            this.buildDragonCastle(level, box, random);
        }
    }

    private void buildDragonCastle(WorldGenLevel level, BoundingBox box, RandomSource random) {
        BlockState wall = Blocks.STONE_BRICKS.defaultBlockState();
        BlockState band = Blocks.DEEPSLATE_BRICKS.defaultBlockState();
        int[][] corners = {{-45, -45}, {45, -45}, {-45, 45}, {45, 45}};
        for (int i = 0; i < 4; i++) {
            this.tower(level, box, random, corners[i][0], corners[i][1], 7, 28, wall, band, this.scale(i), this.scale(i), true);
        }
        this.tower(level, box, random, 0, 45, 5, 20, wall, band, Blocks.DEEPSLATE_TILES.defaultBlockState(), Blocks.DEEPSLATE_BRICKS.defaultBlockState(), false);
        this.tower(level, box, random, 45, 0, 5, 20, wall, band, Blocks.DEEPSLATE_TILES.defaultBlockState(), Blocks.DEEPSLATE_BRICKS.defaultBlockState(), false);
        this.tower(level, box, random, -45, 0, 5, 20, wall, band, Blocks.DEEPSLATE_TILES.defaultBlockState(), Blocks.DEEPSLATE_BRICKS.defaultBlockState(), false);
        // torre del homenaje
        BlockState ladder = Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, this.toward(-1, 0));
        for (int u = -15; u <= 15; u++) {
            for (int v = -15; v <= 15; v++) {
                if (!this.inColumn(box, u, v)) {
                    continue;
                }
                int m = Math.max(Math.abs(u), Math.abs(v));
                if (m > 14) {
                    continue;
                }
                this.setDown(level, box, u, this.y0 - 1, v, Blocks.STONE_BRICKS.defaultBlockState(), 12);
                for (int h = 0; h <= 40; h++) {
                    BlockState s;
                    if (m >= 12) {
                        boolean door = v == -14 && Math.abs(u) <= 2 && h >= 1 && h <= 5;
                        boolean window = h % 10 >= 5 && h % 10 <= 7 && ((Math.abs(u) % 6 == 3 && Math.abs(v) >= 12) || (Math.abs(v) % 6 == 3 && Math.abs(u) >= 12)) && h > 3;
                        s = door ? AIR : (window ? Blocks.GLASS.defaultBlockState() : (h % 10 == 0 ? band : this.brick(u, h, v)));
                    } else if (h % 10 == 0 && !(u == 11 && v == 11)) {
                        s = h == 0 ? Blocks.POLISHED_ANDESITE.defaultBlockState() : Blocks.SPRUCE_PLANKS.defaultBlockState();
                    } else if (u == 11 && v == 11 && h < 40) {
                        s = ladder;
                    } else {
                        s = AIR;
                    }
                    this.set(level, box, u, this.y0 + h, v, s);
                }
                for (int j = 0; j <= 14; j++) {
                    if (m <= 14 - j) {
                        this.set(level, box, u, this.y0 + 41 + j, v, this.scale(j / 2 + (u + v) / 8));
                    }
                }
            }
        }
        this.chest(level, box, random, 8, this.y0 + 1, 8, this.toward(-1, 0));
        this.chest(level, box, random, -8, this.y0 + 1, 8, this.toward(1, 0));
        this.chest(level, box, random, 0, this.y0 + 31, 8, this.toward(0, -1));
        this.lectern(level, box, -6, this.y0 + 1, -9);
        this.lectern(level, box, 0, this.y0 + 11, 9);
        for (int i = 0; i < 6; i++) {
            this.spawn(level, box, ModEntities.DRAGONCITO.get().create(level.getLevel()), -12 + i * 5, this.y0, -24 + (i % 2) * 6);
        }
        // fosa de lava decorativa del patio: brasero del dragon
        for (int du = -2; du <= 2; du++) {
            for (int dv = -2; dv <= 2; dv++) {
                this.set(level, box, 25 + du, this.y0, 25 + dv, Blocks.RED_NETHER_BRICKS.defaultBlockState());
            }
        }
        this.set(level, box, 25, this.y0 + 1, 25, Blocks.CAMPFIRE.defaultBlockState());
        this.set(level, box, 25, this.y0 + 2, 25, AIR);
    }

    private void buildElfCastle(WorldGenLevel level, BoundingBox box, RandomSource random) {
        BlockState wall = Blocks.QUARTZ_BRICKS.defaultBlockState();
        BlockState band = Blocks.GOLD_BLOCK.defaultBlockState();
        BlockState roofA = Blocks.RAW_GOLD_BLOCK.defaultBlockState();
        BlockState roofB = Blocks.YELLOW_TERRACOTTA.defaultBlockState();
        this.tower(level, box, random, 0, 0, 8, 52, wall, band, roofA, roofB, true);
        for (int i = 0; i < 6; i++) {
            double a = i * Math.PI / 3.0D + 0.3D;
            this.tower(level, box, random, (int) Math.round(Math.cos(a) * 24.0D), (int) Math.round(Math.sin(a) * 24.0D), 4, 30,
                    wall, band, roofA, roofB, i == 2);
        }
        int[][] corners = {{-37, -37}, {37, -37}, {-37, 37}, {37, 37}};
        for (int[] c : corners) {
            this.tower(level, box, random, c[0], c[1], 3, 22, wall, band, roofA, roofB, false);
        }
        // jardin: arboles dorados
        for (int i = 0; i < 14; i++) {
            double a = this.rnd(i, 80, 0) * Math.PI * 2.0D;
            double rr = 14.0D + this.rnd(i, 81, 0) * 18.0D;
            int u = (int) Math.round(Math.cos(a) * rr);
            int v = (int) Math.round(Math.sin(a) * rr);
            int height = 5 + (int) (this.rnd(i, 82, 0) * 3.0D);
            if (!this.inColumn(box, u, v) || Math.hypot(u, v) < 12.0D) {
                continue;
            }
            this.setDown(level, box, u, this.y0 - 1, v, Blocks.GRASS_BLOCK.defaultBlockState(), 3);
            for (int h = 0; h < height; h++) {
                this.set(level, box, u, this.y0 + h, v, Blocks.BIRCH_LOG.defaultBlockState());
            }
            for (int du = -2; du <= 2; du++) {
                for (int dv = -2; dv <= 2; dv++) {
                    for (int dy = -1; dy <= 2; dy++) {
                        if (du * du + dv * dv + dy * dy * 1.6D <= 5.2D && !(du == 0 && dv == 0 && dy <= 0)) {
                            this.set(level, box, u + du, this.y0 + height - 1 + dy, v + dv,
                                    ModBlocks.WORLD_TREE_LEAVES.get().defaultBlockState()
                                            .setValue(WorldTreeLeavesBlock.FRUIT, this.rnd(u + du, dy, v + dv) < 0.12D));
                        }
                    }
                }
            }
        }
        for (int i = 0; i < 14; i++) {
            this.spawn(level, box, ModEntities.ELF.get().create(level.getLevel()), -20 + (i % 7) * 7, this.y0, -26 + (i / 7) * 52 / 2);
        }
    }

    // ---- cuevas

    private boolean inCavern(double u, double y, double v) {
        double main = (u * u) / (34.0D * 34.0D) + (y * y) / (17.0D * 17.0D) + (v * v) / (34.0D * 34.0D);
        if (main <= 1.0D) {
            return true;
        }
        for (int i = 0; i < 6; i++) {
            double a = i * Math.PI / 3.0D + this.rnd(i, 90, 0) * 0.8D;
            double lu = Math.cos(a) * 28.0D;
            double lv = Math.sin(a) * 28.0D;
            double ly = (this.rnd(i, 91, 0) - 0.5D) * 6.0D;
            double rr = 12.0D + this.rnd(i, 92, 0) * 5.0D;
            double du = u - lu;
            double dy = y - ly;
            double dv = v - lv;
            if ((du * du + dv * dv) / (rr * rr) + (dy * dy) / (rr * rr * 0.55D) <= 1.0D) {
                return true;
            }
        }
        return false;
    }

    private int floorAt(WorldGenLevel level, int u, int v, int from) {
        int x = this.wx(u, v);
        int z = this.wz(u, v);
        for (int y = from; y > this.cy - 22; y--) {
            BlockState s = level.getBlockState(new BlockPos(x, y, z));
            if (!s.isAir() && s.getFluidState().isEmpty()) {
                return y;
            }
        }
        return this.cy - 22;
    }

    private void buildCave(WorldGenLevel level, BoundingBox box, RandomSource random, boolean crystal) {
        int cy = this.cy;
        // 1) vaciar la caverna
        for (int u = -46; u <= 46; u++) {
            for (int v = -46; v <= 46; v++) {
                if (!this.inColumn(box, u, v)) {
                    continue;
                }
                for (int y = -19; y <= 19; y++) {
                    if (this.inCavern(u, y, v)) {
                        this.set(level, box, u, cy + y, v, AIR);
                    }
                }
            }
        }
        // 2) tunel de entrada con escalones hacia la superficie
        int length = this.y0 - (cy - 8) + 3;
        BlockState step = Blocks.STONE_BRICK_STAIRS.defaultBlockState().setValue(StairBlock.FACING, this.fwd());
        for (int i = 0; i <= length; i++) {
            int u = 26 + i;
            int fy = cy - 8 + i;
            for (int v = -3; v <= 3; v++) {
                if (!this.inColumn(box, u, v)) {
                    continue;
                }
                for (int h = 1; h <= 6; h++) {
                    this.set(level, box, u, fy + h, v, AIR);
                }
                this.set(level, box, u, fy, v, Math.abs(v) <= 2 ? step : Blocks.STONE_BRICKS.defaultBlockState());
                this.set(level, box, u, fy - 1, v, Blocks.STONE_BRICKS.defaultBlockState());
                if (Math.abs(v) == 3 && i % 5 == 2) {
                    this.set(level, box, u, fy + 3, v, Blocks.SEA_LANTERN.defaultBlockState());
                }
            }
        }
        // boca de la cueva: dos columnas de escamas
        for (int h = 0; h <= 5; h++) {
            this.set(level, box, 26 + length, this.y0 + h, -4, this.scale(this.kind));
            this.set(level, box, 26 + length, this.y0 + h, 4, this.scale(this.kind + 1));
        }
        if (crystal) {
            this.crystalCave(level, box, random);
        } else {
            this.hoardCave(level, box, random);
        }
    }

    private void hoardCave(WorldGenLevel level, BoundingBox box, RandomSource random) {
        int cy = this.cy;
        // monton de oro
        for (int du = -14; du <= 14; du++) {
            for (int dv = -14; dv <= 14; dv++) {
                double d = Math.sqrt((double) (du * du + dv * dv));
                if (d > 14.0D || !this.inColumn(box, -10 + du, dv)) {
                    continue;
                }
                int u = -10 + du;
                int floor = this.floorAt(level, u, dv, cy + 4);
                int height = (int) Math.round(10.0D * (1.0D - d / 14.0D) + this.rnd(u, 1, dv) * 2.0D);
                for (int h = 1; h <= height; h++) {
                    double r = this.rnd(u, h, dv);
                    BlockState s = r < 0.60D ? Blocks.GOLD_BLOCK.defaultBlockState()
                            : (r < 0.82D ? Blocks.RAW_GOLD_BLOCK.defaultBlockState()
                            : (r < 0.90D ? Blocks.EMERALD_BLOCK.defaultBlockState()
                            : (r < 0.94D ? Blocks.DIAMOND_BLOCK.defaultBlockState() : this.scale((int) (r * 100.0D)))));
                    this.set(level, box, u, floor + h, dv, s);
                }
                if (d < 1.5D) {
                    this.set(level, box, u, floor + height + 1, dv, ModBlocks.egg((int) (this.rnd(1, 2, 3) * 4.0D)).defaultBlockState());
                }
            }
        }
        int topFloor = this.floorAt(level, -10, 0, cy + 4);
        this.chest(level, box, random, -7, topFloor + 1, 2, this.toward(-1, 0));
        this.chest(level, box, random, -13, topFloor + 1, -2, this.toward(1, 0));
        // charcos de lava rodeados de piedra, huesos de dragon y estalactitas
        for (int i = 0; i < 4; i++) {
            double a = Math.PI / 4.0D + i * Math.PI / 2.0D;
            int u = (int) Math.round(Math.cos(a) * 20.0D) + 4;
            int v = (int) Math.round(Math.sin(a) * 20.0D);
            int floor = this.floorAt(level, u, v, cy + 4);
            for (int du = -2; du <= 2; du++) {
                for (int dv = -2; dv <= 2; dv++) {
                    if (du * du + dv * dv <= 5) {
                        this.set(level, box, u + du, floor, v + dv, Blocks.LAVA.defaultBlockState());
                        this.set(level, box, u + du, floor - 1, v + dv, Blocks.MAGMA_BLOCK.defaultBlockState());
                    }
                }
            }
        }
        for (int i = 0; i < 70; i++) {
            int u = (int) Math.round((this.rnd(i, 100, 0) - 0.5D) * 60.0D);
            int v = (int) Math.round((this.rnd(i, 101, 0) - 0.5D) * 60.0D);
            if (!this.inColumn(box, u, v) || !this.inCavern(u, 0, v)) {
                continue;
            }
            if (i % 3 == 0) {
                int floor = this.floorAt(level, u, v, cy + 4);
                int len = 2 + (int) (this.rnd(i, 102, 0) * 5.0D);
                for (int h = 1; h <= len; h++) {
                    this.set(level, box, u, floor + h, v, Blocks.BONE_BLOCK.defaultBlockState());
                }
            } else {
                int ceil = cy + 16;
                while (ceil > cy - 2 && level.getBlockState(new BlockPos(this.wx(u, v), ceil, this.wz(u, v))).isAir()) {
                    ceil--;
                }
                int len = 1 + (int) (this.rnd(i, 103, 0) * 3.0D);
                for (int h = 1; h <= len; h++) {
                    this.set(level, box, u, ceil - h, v, Blocks.DRIPSTONE_BLOCK.defaultBlockState());
                }
            }
        }
        this.lectern(level, box, -10, topFloor + 1, -12);
        this.set(level, box, 0, cy - 1, 0, Blocks.LANTERN.defaultBlockState());
    }

    private void crystalCave(WorldGenLevel level, BoundingBox box, RandomSource random) {
        int cy = this.cy;
        int water = cy - 10;
        // lago y revestimiento de amatista
        for (int u = -46; u <= 46; u++) {
            for (int v = -46; v <= 46; v++) {
                if (!this.inColumn(box, u, v)) {
                    continue;
                }
                for (int y = -19; y <= 19; y++) {
                    if (!this.inCavern(u, y, v)) {
                        continue;
                    }
                    if (cy + y <= water && Math.hypot(u, v) < 17.0D) {
                        this.set(level, box, u, cy + y, v, Blocks.WATER.defaultBlockState());
                    }
                }
            }
        }
        // isla central con el tesoro
        for (int du = -3; du <= 3; du++) {
            for (int dv = -3; dv <= 3; dv++) {
                if (du * du + dv * dv <= 9) {
                    int floor = this.floorAt(level, du, dv, cy - 4);
                    for (int y = floor; y <= water; y++) {
                        this.set(level, box, du, y, dv, y == water ? Blocks.GRASS_BLOCK.defaultBlockState() : Blocks.CALCITE.defaultBlockState());
                    }
                }
            }
        }
        this.chest(level, box, random, 0, water + 1, 0, this.toward(0, -1));
        this.set(level, box, 2, water + 1, 2, Blocks.AZALEA.defaultBlockState());
        this.lectern(level, box, -2, water + 1, 1);
        // pilares de cristal
        for (int i = 0; i < 40; i++) {
            int u = (int) Math.round((this.rnd(i, 110, 0) - 0.5D) * 62.0D);
            int v = (int) Math.round((this.rnd(i, 111, 0) - 0.5D) * 62.0D);
            if (!this.inColumn(box, u, v) || !this.inCavern(u, 0, v) || Math.hypot(u, v) < 18.0D) {
                continue;
            }
            int floor = this.floorAt(level, u, v, cy + 4);
            int height = 4 + (int) (this.rnd(i, 112, 0) * 8.0D);
            for (int h = 1; h <= height; h++) {
                this.set(level, box, u, floor + h, v, h % 4 == 0 ? this.scale(i) : Blocks.AMETHYST_BLOCK.defaultBlockState());
            }
            this.set(level, box, u, floor + height + 1, v, Blocks.AMETHYST_CLUSTER.defaultBlockState());
        }
    }
}
