package com.isladragoncitos.worldgen;

import com.isladragoncitos.registry.ModBlocks;
import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Un huevo de dragon antiguo escondido en el suelo, en un pequeno hueco cubierto de maleza. */
public class AncientEggFeature extends Feature<NoneFeatureConfiguration> {
    public AncientEggFeature(Codec<NoneFeatureConfiguration> codec) {
        super(codec);
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
        WorldGenLevel level = context.level();
        BlockPos origin = context.origin();
        BlockPos ground = origin.below();
        BlockState below = level.getBlockState(ground);
        if (!level.getBlockState(origin).isAir() || !below.isSolidRender(level, ground) || level.getFluidState(origin).isSource()) {
            return false;
        }
        float temperature = level.getBiome(origin).value().getBaseTemperature();
        int type;
        if (temperature <= 0.15F) {
            type = 1;
        } else if (temperature >= 1.5F) {
            type = 0;
        } else {
            type = context.random().nextInt(3);
        }
        // hueco: el huevo queda medio enterrado, rodeado de piedra y cubierto de plantas
        BlockPos egg = origin.below();
        level.setBlock(egg, ModBlocks.egg(type).defaultBlockState(), 2);
        BlockState rim = context.random().nextBoolean() ? Blocks.MOSSY_COBBLESTONE.defaultBlockState() : Blocks.COBBLESTONE.defaultBlockState();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) {
                    continue;
                }
                BlockPos side = egg.offset(dx, 0, dz);
                if (!level.getBlockState(side).isAir() && context.random().nextInt(3) != 0) {
                    level.setBlock(side, rim, 2);
                }
                BlockPos cover = origin.offset(dx, 0, dz);
                if (level.getBlockState(cover).isAir() && context.random().nextInt(2) == 0
                        && level.getBlockState(cover.below()).isSolidRender(level, cover.below())) {
                    level.setBlock(cover, Blocks.FERN.defaultBlockState(), 2);
                }
            }
        }
        level.setBlock(origin, Blocks.MOSS_CARPET.defaultBlockState(), 2);
        return true;
    }
}
