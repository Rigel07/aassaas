package com.isladragoncitos.client;

import com.isladragoncitos.entity.species.DragonSpecies;
import com.isladragoncitos.entity.species.DragonSpecies.SpeciesData;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;

/** Codice Draconico: enciclopedia de las especies. Las que aun no has criado salen como "???". */
public class DragonCodexScreen extends Screen {
    private static final String[] BASES = {"Fuego", "Hielo", "Tormenta", "Agua", "Celeste"};
    private static final int PER_PAGE = 11;
    private static final int W = 340;
    private static final int H = 210;

    private final List<SpeciesData> entries = new ArrayList<>();
    private final Set<String> discovered;
    private final boolean all;
    private int page;
    private int selected;
    private int left;
    private int top;

    public DragonCodexScreen(List<String> discovered, boolean all) {
        super(Component.translatable("item.isladragoncitos.dragon_codex"));
        this.discovered = new HashSet<>(discovered);
        this.all = all;
        this.entries.addAll(DragonSpecies.ALL_SPECIES.values());
        this.entries.sort(Comparator.comparingInt((SpeciesData d) -> d.rarity.ordinal()).thenComparing(d -> d.name));
    }

    private boolean known(SpeciesData data) {
        return this.all || this.discovered.contains(data.id);
    }

    private int pages() {
        return Math.max(1, (this.entries.size() + PER_PAGE - 1) / PER_PAGE);
    }

    @Override
    protected void init() {
        this.left = (this.width - W) / 2;
        this.top = (this.height - H) / 2;
        this.rebuild();
    }

    private void rebuild() {
        this.clearWidgets();
        int start = this.page * PER_PAGE;
        for (int i = 0; i < PER_PAGE && start + i < this.entries.size(); i++) {
            SpeciesData data = this.entries.get(start + i);
            int index = start + i;
            Component label = this.known(data)
                    ? Component.literal(data.name).withStyle(Style.EMPTY.withColor(data.rarity.color))
                    : Component.literal("???").withStyle(Style.EMPTY.withColor(0x777777));
            this.addRenderableWidget(Button.builder(label, b -> this.selected = index)
                    .bounds(this.left + 8, this.top + 24 + i * 15, 138, 14).build());
        }
        this.addRenderableWidget(Button.builder(Component.literal("<"), b -> {
            this.page = Math.max(0, this.page - 1);
            this.rebuild();
        }).bounds(this.left + 8, this.top + H - 22, 24, 14).build());
        this.addRenderableWidget(Button.builder(Component.literal(">"), b -> {
            this.page = Math.min(this.pages() - 1, this.page + 1);
            this.rebuild();
        }).bounds(this.left + 122, this.top + H - 22, 24, 14).build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        this.renderBackground(g);
        g.fill(this.left, this.top, this.left + W, this.top + H, 0xE0201A2E);
        g.fill(this.left + 2, this.top + 2, this.left + W - 2, this.top + H - 2, 0xE02F2644);
        g.fill(this.left + 152, this.top + 22, this.left + 153, this.top + H - 8, 0xFF6B5A9A);
        g.drawString(this.font, Component.translatable("item.isladragoncitos.dragon_codex"), this.left + 8, this.top + 8, 0xFFD36B, false);
        long found = this.entries.stream().filter(this::known).count();
        g.drawString(this.font, found + "/" + this.entries.size(), this.left + W - 40, this.top + 8, 0xAAAAAA, false);
        g.drawString(this.font, (this.page + 1) + "/" + this.pages(), this.left + 66, this.top + H - 19, 0xCCCCCC, false);
        super.render(g, mouseX, mouseY, partial);
        this.drawDetail(g);
    }

    private void drawDetail(GuiGraphics g) {
        if (this.selected < 0 || this.selected >= this.entries.size()) {
            return;
        }
        SpeciesData data = this.entries.get(this.selected);
        int x = this.left + 162;
        int y = this.top + 26;
        if (!this.known(data)) {
            g.drawString(this.font, "???", x, y, 0x888888, false);
            g.drawString(this.font, Component.translatable("codex.isladragoncitos.unknown"), x, y + 16, 0x777777, false);
            return;
        }
        g.drawString(this.font, data.name, x, y, data.rarity.color, false);
        g.fill(x + 150, y - 2, x + 166, y + 10, 0xFF000000 | data.element.tint);
        int line = y + 18;
        line = row(g, x, line, "Elemento", data.element.nameEs);
        line = row(g, x, line, "Rareza", data.rarity.nameEs);
        line = row(g, x, line, "Modelo base", BASES[Math.max(0, Math.min(4, data.element.baseType))]);
        line = row(g, x, line, "Tama\u00f1o", "x" + data.sizeMultiplier);
        line = row(g, x, line, "Vida extra", "+" + (int) data.healthBonus);
        line = row(g, x, line, "Da\u00f1o", "x" + data.damageMultiplier);
        line += 6;
        g.drawString(this.font, "Pasiva", x, line, 0xFFD36B, false);
        g.drawString(this.font, data.passiveAbility, x + 4, line + 11, 0xDDDDDD, false);
        line += 28;
        g.drawString(this.font, "Ataque especial", x, line, 0xFF7A5C, false);
        g.drawString(this.font, data.specialAttack, x + 4, line + 11, 0xDDDDDD, false);
        line += 28;
        String how = data.rarity.weight > 0 ? "Sale de huevos de " + BASES[Math.max(0, Math.min(4, data.element.baseType))].toLowerCase()
                : "No sale de huevos normales (comando u ofrenda)";
        g.drawString(this.font, how, x, line, 0x9A9AB5, false);
    }

    private int row(GuiGraphics g, int x, int y, String label, String value) {
        g.drawString(this.font, label + ":", x, y, 0x9A9AB5, false);
        g.drawString(this.font, value, x + 80, y, 0xFFFFFF, false);
        return y + 12;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
