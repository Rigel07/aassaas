package com.isladragoncitos.client;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.player.Player;

/** Lectura del teclado del jinete (solo se carga en el cliente). */
public final class ClientRiderInput {
    private ClientRiderInput() {}

    public static boolean isJumping(Player player) {
        return player instanceof LocalPlayer local && local.input != null && local.input.jumping;
    }
}
