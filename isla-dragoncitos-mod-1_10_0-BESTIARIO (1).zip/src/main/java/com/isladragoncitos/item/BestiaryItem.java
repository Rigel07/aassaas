package com.isladragoncitos.item;

import com.isladragoncitos.network.BestiaryPacket;
import com.isladragoncitos.network.ModNetwork;
import com.isladragoncitos.system.DraconicData;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** Bestiario Draconiano: te lo dan al pisar el mundo por primera vez. Guia completa de dragones, habilidades y mas. */
public class BestiaryItem extends Item {
    public BestiaryItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer server) {
            ModNetwork.sendTo(server, new BestiaryPacket(new ArrayList<>(DraconicData.getDiscoveredSpecies(server)),
                    DraconicData.getUnlockedAbilities(server), player.getAbilities().instabuild,
                    DraconicData.getMarkLevel(server), DraconicData.getHalfPoints(server)));
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.isladragoncitos.bestiary").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.isladragoncitos.bestiary.use").withStyle(ChatFormatting.DARK_GRAY));
    }
}
