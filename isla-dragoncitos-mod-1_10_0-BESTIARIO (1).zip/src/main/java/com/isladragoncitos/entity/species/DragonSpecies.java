package com.isladragoncitos.entity.species;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;

/**
 * Catalogo de especies de dragon antiguo (103). Cada especie tiene elemento, rareza, tamano, vida y dano extra,
 * una pasiva y un ataque especial. El modelo 3D se toma del tipo base del elemento (fuego, hielo, tormenta o agua)
 * y se tine con el color del elemento. Generado y revisado a mano: sin ids repetidos ni rutas rotas.
 */
public final class DragonSpecies {
    public enum Element {
        FIRE("Fuego", 0, 0xFFFFFF),
        ICE("Hielo", 1, 0xFFFFFF),
        STORM("Tormenta", 2, 0xFFFFFF),
        WATER("Agua", 3, 0xFFFFFF),
        SHADOW("Sombra", 2, 0x6A5A8A),
        LIGHT("Luz", 0, 0xFFF3A0),
        EARTH("Tierra", 0, 0xA9824F),
        WIND("Viento", 1, 0xCFF5EA),
        POISON("Veneno", 2, 0x7FD24A),
        COSMIC("Cósmico", 2, 0x8A7CFF),
        METAL("Metal", 1, 0xB8BEC8),
        MAGMA("Magma", 0, 0xFF6A1F),
        HOLY("Sagrado", 0, 0xFFE9B0),
        VOID("Vacío", 2, 0x4B2A6B),
        NATURE("Naturaleza", 3, 0x6FCF6A),
        TIME("Tiempo", 2, 0xE0C070),
        LUCK("Suerte", 0, 0xFFD83A),
        PSYCHE("Psique", 2, 0xE070D8),
        LEGEND("Leyenda", 0, 0xFFB347),
        SUN("Sol", 0, 0xFFC83D),
        MOON("Luna", 1, 0xD8E4FF),
        GRAVITY("Gravedad", 2, 0x5C4B9A),
        DIMENSION("Dimensión", 2, 0x7A5CFF),
        CHAOS("Caos", 0, 0xC2185B),
        ORDER("Orden", 1, 0xBFD7FF),
        ETHER("Éter", 2, 0xB0A0FF),
        PLASMA("Plasma", 0, 0xFF4FA8),
        CRYSTAL("Cristal", 1, 0xB5F0FF),
        BLOOD("Sangre", 0, 0xB0102A),
        SOUL("Alma", 3, 0x66F0D8),
        SAND("Arena", 0, 0xE8D08A),
        STEAM("Vapor", 1, 0xE6EEF2),
        RUBY("Rubí", 0, 0xE0115F),
        SAPPHIRE("Zafiro", 3, 0x2E5CE6),
        OBSIDIAN("Obsidiana", 2, 0x2B2340),
        CLOUD("Nube", 1, 0xF4F8FF),
        JUNGLE("Jungla", 3, 0x3FA34D),
        TUNDRA("Tundra", 1, 0xA8C8D8),
        DESERT("Desierto", 0, 0xD9A441),
        FOREST("Bosque", 3, 0x3E8E41),
        GHOST("Fantasma", 1, 0xC8D6E8),
        NEON("Neón", 2, 0x39FF9C),
        STEAM_PUNK("Vaporpunk", 0, 0xB87333),
        PAPER("Papel", 1, 0xF5ECD7),
        MIRROR("Espejo", 1, 0xE8F0F8),
        MAGNITUDE("Magnitud", 2, 0x9A6CFF),
        ECHO("Eco", 3, 0x7FD8E8),
        ZENITH("Cénit", 0, 0xFFEFA0),
        NADIR("Nadir", 2, 0x3A2A5A),
        PRISM("Prisma", 1, 0xF0A8FF),
        SULFUR("Azufre", 0, 0xE8E030),
        MERCURY("Mercurio", 1, 0xC0C8D0),
        COBALT("Cobalto", 3, 0x2F4FBF),
        QUARTZ("Cuarzo", 1, 0xF2E8E0),
        AMBER("Ámbar", 0, 0xFFA726),
        EMERALD("Esmeralda", 3, 0x1FBF6A),
        ONYX("Ónix", 2, 0x1E1E26),
        TITANIUM("Titanio", 1, 0xA8B4C4),
        GRAPHENE("Grafeno", 2, 0x4A4F5C),
        PHOTON("Fotón", 0, 0xFFFFFF),
        SKY("Aurora", 4, 0xFFFFFF);
        public final String nameEs;
        /** Modelo base: 0 fuego, 1 hielo, 2 tormenta, 3 agua. */
        public final int baseType;
        public final int tint;

        Element(String nameEs, int baseType, int tint) {
            this.nameEs = nameEs;
            this.baseType = baseType;
            this.tint = tint;
        }
    }

    public enum Rarity {
        COMMON("Común", 0xAAAAAA, 60),
        RARE("Raro", 0x55AAFF, 25),
        EPIC("Épico", 0xB36BFF, 10),
        LEGENDARY("Legendario", 0xFFAA00, 4),
        MYTHIC("Mítico", 0xFF5577, 1),
        ANCIENT("Ancestral", 0x55FFAA, 0),
        DIVINE("Divino", 0xFFFFFF, 0);
        public final String nameEs;
        public final int color;
        /** Peso al sortear la especie de un huevo (0 = no sale de huevos normales). */
        public final int weight;

        Rarity(String nameEs, int color, int weight) {
            this.nameEs = nameEs;
            this.color = color;
            this.weight = weight;
        }
    }

    public static final class SpeciesData {
        public final String id;
        public final String name;
        public final Element element;
        public final Rarity rarity;
        public final float sizeMultiplier;
        public final float healthBonus;
        public final float damageMultiplier;
        public final String modelId;
        public final String passiveAbility;
        public final String specialAttack;

        SpeciesData(String id, String name, Element element, Rarity rarity, float size, float hp, float dmg,
                    String model, String passive, String special) {
            this.id = id;
            this.name = name;
            this.element = element;
            this.rarity = rarity;
            this.sizeMultiplier = size;
            this.healthBonus = hp;
            this.damageMultiplier = dmg;
            this.modelId = model;
            this.passiveAbility = passive;
            this.specialAttack = special;
        }

        /** Los 4 dragones originales conservan su aspecto sin tinte. */
        public int tint() {
            return this.id.startsWith("original_") ? 0xFFFFFF : this.element.tint;
        }
    }

    private static final Map<String, SpeciesData> MAP = new LinkedHashMap<>();
    /** Vista de solo lectura de todas las especies, por id. */
    public static final Map<String, SpeciesData> ALL_SPECIES = Collections.unmodifiableMap(MAP);

    private DragonSpecies() {}

    private static void add(String id, String name, Element element, Rarity rarity, float size, float hp, float dmg,
                            String model, String passive, String special) {
        MAP.put(id, new SpeciesData(id, name, element, rarity, size, hp, dmg, model, passive, special));
    }

    static {
        add("original_fire", "Ancient Fire", Element.FIRE, Rarity.RARE, 1.2F, 50F, 1.3F, "geo/dragon/orig_fire", "Calidez ígnea", "Bola de fuego");
        add("original_ice", "Ancient Ice", Element.ICE, Rarity.RARE, 1.2F, 50F, 1.3F, "geo/dragon/orig_ice", "Aura gélida", "Pinchos de hielo");
        add("original_storm", "Ancient Storm", Element.STORM, Rarity.RARE, 1.2F, 50F, 1.3F, "geo/dragon/orig_storm", "Carga estática", "Rayo");
        add("original_water", "Ancient Water", Element.WATER, Rarity.RARE, 1.2F, 50F, 1.3F, "geo/dragon/orig_water", "Aliento acuático", "Marea");
        add("ember_wing", "Ember Wing", Element.FIRE, Rarity.COMMON, 0.8F, 20F, 1.1F, "geo/dragon/fire_wing", "Calidez ígnea", "Bola de fuego");
        add("snow_scale", "Snow Scale", Element.ICE, Rarity.COMMON, 0.7F, 15F, 1.0F, "geo/dragon/ice_scale", "Aura gélida", "Pinchos de hielo");
        add("mist_glider", "Mist Glider", Element.WATER, Rarity.COMMON, 0.8F, 25F, 1.1F, "geo/dragon/water_mist", "Aliento acuático", "Marea");
        add("sylvan_leaf", "Sylvan Leaf", Element.NATURE, Rarity.COMMON, 1.0F, 50F, 1.1F, "geo/dragon/nature_sylvan", "Regeneración verde", "Raíces atrapantes");
        add("dust_drifter", "Dust Drifter", Element.SAND, Rarity.COMMON, 0.9F, 30F, 1.2F, "geo/dragon/sand_dust", "Piel de arena", "Tormenta de arena");
        add("cloud_puff", "Cloud Puff", Element.CLOUD, Rarity.COMMON, 0.7F, 20F, 1.0F, "geo/dragon/cloud_puff", "Paso de nube", "Aguacero");
        add("river_fin", "River Fin", Element.WATER, Rarity.COMMON, 0.8F, 35F, 1.1F, "geo/dragon/water_fin", "Aliento acuático", "Marea");
        add("leaf_hopper", "Leaf Hopper", Element.FOREST, Rarity.COMMON, 0.7F, 30F, 1.1F, "geo/dragon/forest_hopper", "Susurro del bosque", "Enredadera");
        add("pebble_skin", "Pebble Skin", Element.EARTH, Rarity.COMMON, 1.1F, 60F, 1.0F, "geo/dragon/earth_pebble", "Piel de roca", "Temblor");
        add("steam_puff", "Steam Puff", Element.STEAM, Rarity.COMMON, 0.9F, 40F, 1.2F, "geo/dragon/steam_puff", "Niebla caliente", "Chorro de vapor");
        add("spark_flyer", "Spark Flyer", Element.STORM, Rarity.RARE, 0.9F, 30F, 1.3F, "geo/dragon/storm_spark", "Carga estática", "Rayo");
        add("night_shade", "Night Shade", Element.SHADOW, Rarity.RARE, 0.9F, 40F, 1.4F, "geo/dragon/shadow_shade", "Velo de sombras", "Zarpazo umbrío");
        add("aero_zephyr", "Aero Zephyr", Element.WIND, Rarity.RARE, 0.8F, 30F, 1.2F, "geo/dragon/wind_zephyr", "Brisa veloz", "Ráfaga cortante");
        add("iron_clad", "Iron Clad", Element.METAL, Rarity.RARE, 1.3F, 110F, 1.5F, "geo/dragon/metal_iron", "Escamas de hierro", "Lanza metálica");
        add("crystal_core", "Crystal Core", Element.CRYSTAL, Rarity.RARE, 1.2F, 150F, 1.3F, "geo/dragon/crystal_core", "Resonancia de cristal", "Esquirlas cristalinas");
        add("ruby_fang", "Ruby Fang", Element.RUBY, Rarity.RARE, 1.1F, 80F, 1.6F, "geo/dragon/ruby_fang", "Fulgor de rubí", "Rayo rubí");
        add("sapphire_wing", "Sapphire Wing", Element.SAPPHIRE, Rarity.RARE, 1.0F, 70F, 1.5F, "geo/dragon/sapphire_wing", "Fulgor de zafiro", "Rayo zafiro");
        add("tundra_prowler", "Tundra Prowler", Element.TUNDRA, Rarity.RARE, 1.2F, 90F, 1.4F, "geo/dragon/tundra_prowler", "Frío de tundra", "Ventisca");
        add("desert_stalker", "Desert Stalker", Element.DESERT, Rarity.RARE, 1.1F, 70F, 1.5F, "geo/dragon/desert_stalker", "Sol del desierto", "Espejismo");
        add("jungle_viper", "Jungle Viper", Element.JUNGLE, Rarity.RARE, 1.0F, 60F, 1.6F, "geo/dragon/jungle_viper", "Sigilo de jungla", "Zarpa venenosa");
        add("glacia_frost", "Glacia Frost", Element.ICE, Rarity.EPIC, 1.2F, 60F, 1.5F, "geo/dragon/ice_frost", "Aura gélida", "Pinchos de hielo");
        add("aqualis", "Aqualis", Element.WATER, Rarity.EPIC, 1.3F, 80F, 1.4F, "geo/dragon/water_aqua", "Aliento acuático", "Marea");
        add("venoma_tox", "Venoma Tox", Element.POISON, Rarity.EPIC, 1.1F, 60F, 1.6F, "geo/dragon/poison_venom", "Nube tóxica", "Escupitajo venenoso");
        add("terra_titan", "Terra Titan", Element.EARTH, Rarity.EPIC, 2.0F, 200F, 1.7F, "geo/dragon/earth_titan", "Piel de roca", "Temblor");
        add("angel_wing", "Angel Wing", Element.HOLY, Rarity.EPIC, 1.0F, 70F, 1.3F, "geo/dragon/holy_angel", "Bendición", "Juicio sagrado");
        add("sanguine_fang", "Sanguine Fang", Element.BLOOD, Rarity.EPIC, 1.1F, 120F, 1.7F, "geo/dragon/blood_fang", "Sed de sangre", "Mordisco sangriento");
        add("ether_wing", "Ether Wing", Element.ETHER, Rarity.EPIC, 1.1F, 100F, 1.8F, "geo/dragon/ether_wing", "Aliento etéreo", "Pulso etéreo");
        add("storm_herald", "Storm Herald", Element.STORM, Rarity.EPIC, 1.3F, 110F, 1.7F, "geo/dragon/storm_herald", "Carga estática", "Rayo");
        add("obsidian_scale", "Obsidian Scale", Element.OBSIDIAN, Rarity.EPIC, 1.5F, 180F, 1.6F, "geo/dragon/obsidian_scale", "Coraza de obsidiana", "Lluvia de obsidiana");
        add("plasma_drift", "Plasma Drift", Element.PLASMA, Rarity.EPIC, 1.1F, 90F, 1.8F, "geo/dragon/plasma_drift", "Calor de plasma", "Descarga de plasma");
        add("ignis_rex", "Ignis Rex", Element.FIRE, Rarity.LEGENDARY, 1.5F, 100F, 2.0F, "geo/dragon/fire_rex", "Calidez ígnea", "Bola de fuego");
        add("voltros", "Voltros", Element.STORM, Rarity.LEGENDARY, 1.1F, 40F, 2.5F, "geo/dragon/storm_volt", "Carga estática", "Rayo");
        add("lumina_sol", "Lumina Sol", Element.LIGHT, Rarity.LEGENDARY, 1.6F, 150F, 1.6F, "geo/dragon/light_lumina", "Brillo vital", "Rayo de luz");
        add("magma_core", "Magma Core", Element.MAGMA, Rarity.LEGENDARY, 1.8F, 130F, 1.9F, "geo/dragon/magma_core", "Piel de lava", "Erupción");
        add("fortuna_luck", "Fortuna (La Suerte)", Element.LUCK, Rarity.LEGENDARY, 1.1F, 200F, 1.5F, "geo/dragon/luck_fortuna", "Fortuna", "Moneda del destino");
        add("aurora_wyrm", "Aurora Wyrm", Element.SKY, Rarity.LEGENDARY, 1.4F, 150F, 2.2F, "geo/dragon/sky_aurora", "Polvo estelar", "Lluvia de estrellas");
        add("star_weaver", "Star Weaver", Element.COSMIC, Rarity.LEGENDARY, 1.2F, 100F, 2.1F, "geo/dragon/cosmic_star", "Polvo estelar", "Lluvia de estrellas");
        add("plasma_flare", "Plasma Flare", Element.PLASMA, Rarity.LEGENDARY, 1.4F, 200F, 2.2F, "geo/dragon/plasma_flare", "Calor de plasma", "Descarga de plasma");
        add("titan_gold", "Titan Gold", Element.METAL, Rarity.LEGENDARY, 1.7F, 250F, 1.8F, "geo/dragon/metal_gold", "Escamas de hierro", "Lanza metálica");
        add("void_echo", "Void Echo", Element.VOID, Rarity.LEGENDARY, 1.2F, 180F, 2.1F, "geo/dragon/void_echo", "Vacío absoluto", "Implosión del vacío");
        add("solar_flare", "Solar Flare", Element.SUN, Rarity.LEGENDARY, 1.5F, 220F, 2.3F, "geo/dragon/sun_flare", "Radiancia solar", "Supernova");
        add("umbra_noctis", "Umbra Noctis", Element.SHADOW, Rarity.MYTHIC, 1.4F, 120F, 1.8F, "geo/dragon/shadow_umbra", "Velo de sombras", "Zarpazo umbrío");
        add("void_stalker", "Void Stalker", Element.VOID, Rarity.MYTHIC, 1.1F, 100F, 2.2F, "geo/dragon/void_stalker", "Vacío absoluto", "Implosión del vacío");
        add("astral_void", "Astral Void", Element.COSMIC, Rarity.MYTHIC, 2.5F, 300F, 3.0F, "geo/dragon/cosmic_astral", "Polvo estelar", "Lluvia de estrellas");
        add("graviton", "Graviton", Element.GRAVITY, Rarity.MYTHIC, 1.8F, 300F, 2.5F, "geo/dragon/gravity_graviton", "Pozo gravitatorio", "Aplastamiento");
        add("psyche_mind", "Psyche (La Psicología)", Element.PSYCHE, Rarity.MYTHIC, 1.0F, 150F, 2.0F, "geo/dragon/psyche_mind", "Mente abierta", "Choque mental");
        add("soul_reaper", "Soul Reaper", Element.SOUL, Rarity.MYTHIC, 1.0F, 300F, 2.5F, "geo/dragon/soul_reaper", "Cosecha de almas", "Grito de almas");
        add("chronos_prime", "Chronos Prime (El Tiempo)", Element.TIME, Rarity.DIVINE, 3.0F, 1000F, 5.0F, "geo/dragon/time_chronos", "Parada del tiempo", "Colapso temporal");
        add("mythos_legend", "Mythos (La Leyenda)", Element.LEGEND, Rarity.ANCIENT, 4.0F, 2000F, 8.0F, "geo/dragon/legend_mythos", "Aura legendaria", "Borrador de mundos");
        add("helios_sun", "Helios (El Sol)", Element.SUN, Rarity.DIVINE, 2.5F, 500F, 4.0F, "geo/dragon/sun_helios", "Radiancia solar", "Supernova");
        add("selene_moon", "Selene (La Luna)", Element.MOON, Rarity.DIVINE, 2.2F, 450F, 3.5F, "geo/dragon/moon_selene", "Fase lunar", "Rayo de luna");
        add("sand_crawler", "Sand Crawler", Element.SAND, Rarity.COMMON, 0.9F, 30F, 1.1F, "geo/dragon/sand_crawler", "Piel de arena", "Tormenta de arena");
        add("puff_cloud", "Puff Cloud", Element.CLOUD, Rarity.COMMON, 0.7F, 20F, 1.0F, "geo/dragon/cloud_puff2", "Paso de nube", "Aguacero");
        add("forest_whisper", "Forest Whisper", Element.FOREST, Rarity.COMMON, 1.0F, 40F, 1.1F, "geo/dragon/forest_whisper", "Susurro del bosque", "Enredadera");
        add("tundra_mite", "Tundra Mite", Element.TUNDRA, Rarity.COMMON, 0.8F, 45F, 1.1F, "geo/dragon/tundra_mite", "Frío de tundra", "Ventisca");
        add("jungle_fly", "Jungle Fly", Element.JUNGLE, Rarity.COMMON, 0.7F, 30F, 1.2F, "geo/dragon/jungle_fly", "Sigilo de jungla", "Zarpa venenosa");
        add("desert_hop", "Desert Hop", Element.DESERT, Rarity.COMMON, 0.8F, 35F, 1.1F, "geo/dragon/desert_hop", "Sol del desierto", "Espejismo");
        add("stream_fin", "Stream Fin", Element.WATER, Rarity.COMMON, 0.9F, 40F, 1.1F, "geo/dragon/water_stream", "Aliento acuático", "Marea");
        add("ash_wing", "Ash Wing", Element.FIRE, Rarity.COMMON, 0.8F, 30F, 1.2F, "geo/dragon/fire_ash", "Calidez ígnea", "Bola de fuego");
        add("pebble_jump", "Pebble Jump", Element.EARTH, Rarity.COMMON, 1.1F, 50F, 1.0F, "geo/dragon/earth_jump", "Piel de roca", "Temblor");
        add("breeze_wing", "Breeze Wing", Element.WIND, Rarity.COMMON, 0.8F, 25F, 1.1F, "geo/dragon/wind_breeze", "Brisa veloz", "Ráfaga cortante");
        add("neon_glitch", "Neon Glitch", Element.NEON, Rarity.RARE, 1.0F, 60F, 1.5F, "geo/dragon/neon_glitch", "Brillo neón", "Destello neón");
        add("steam_gear", "Steam Gear", Element.STEAM_PUNK, Rarity.RARE, 1.3F, 90F, 1.4F, "geo/dragon/steampunk_gear", "Engranajes", "Disparo de vapor");
        add("paper_fold", "Paper Fold", Element.PAPER, Rarity.RARE, 0.8F, 40F, 1.3F, "geo/dragon/paper_fold", "Ligereza de papel", "Corte de papel");
        add("mirror_glass", "Mirror Glass", Element.MIRROR, Rarity.RARE, 1.1F, 80F, 1.6F, "geo/dragon/mirror_glass", "Reflejo", "Espejo roto");
        add("echo_soul", "Echo Soul", Element.ECHO, Rarity.RARE, 1.0F, 100F, 1.4F, "geo/dragon/echo_soul", "Eco sónico", "Grito del eco");
        add("cobalt_spike", "Cobalt Spike", Element.COBALT, Rarity.RARE, 1.3F, 110F, 1.5F, "geo/dragon/cobalt_spike", "Aura de cobalto", "Rayo de cobalto");
        add("emerald_scale", "Emerald Scale", Element.EMERALD, Rarity.RARE, 1.2F, 85F, 1.5F, "geo/dragon/emerald_scale", "Brillo esmeralda", "Rayo esmeralda");
        add("onyx_claw", "Onyx Claw", Element.ONYX, Rarity.RARE, 1.3F, 100F, 1.6F, "geo/dragon/onyx_claw", "Piel de ónix", "Zarpa de ónix");
        add("quartz_beam", "Quartz Beam", Element.QUARTZ, Rarity.RARE, 1.1F, 75F, 1.5F, "geo/dragon/quartz_beam", "Pulso de cuarzo", "Esquirlas de cuarzo");
        add("titanium_hull", "Titanium Hull", Element.TITANIUM, Rarity.EPIC, 1.6F, 200F, 1.8F, "geo/dragon/titanium_hull", "Blindaje de titanio", "Embestida de titanio");
        add("graphene_web", "Graphene Web", Element.GRAPHENE, Rarity.EPIC, 1.1F, 120F, 1.9F, "geo/dragon/graphene_web", "Fibra de grafeno", "Corte de grafeno");
        add("photon_ray", "Photon Ray", Element.PHOTON, Rarity.EPIC, 1.0F, 100F, 2.1F, "geo/dragon/photon_ray", "Velocidad de luz", "Haz de fotones");
        add("sulfur_breath", "Sulfur Breath", Element.SULFUR, Rarity.EPIC, 1.3F, 140F, 1.7F, "geo/dragon/sulfur_breath", "Aliento de azufre", "Nube de azufre");
        add("mercury_flow", "Mercury Flow", Element.MERCURY, Rarity.EPIC, 1.2F, 130F, 1.8F, "geo/dragon/mercury_flow", "Gota de mercurio", "Salpicadura de mercurio");
        add("zenith_star", "Zenith Star", Element.ZENITH, Rarity.EPIC, 1.5F, 180F, 1.9F, "geo/dragon/zenith_star", "Luz del cénit", "Rayo cenital");
        add("nadir_void", "Nadir Void", Element.NADIR, Rarity.EPIC, 1.4F, 170F, 1.9F, "geo/dragon/nadir_void", "Sombra del nadir", "Caída al nadir");
        add("prism_wing", "Prism Wing", Element.PRISM, Rarity.EPIC, 1.2F, 120F, 1.7F, "geo/dragon/prism_wing", "Luz prismática", "Rayo arcoíris");
        add("blood_lord", "Blood Lord", Element.BLOOD, Rarity.EPIC, 1.6F, 220F, 1.8F, "geo/dragon/blood_lord", "Sed de sangre", "Mordisco sangriento");
        add("soul_eater", "Soul Eater", Element.SOUL, Rarity.EPIC, 1.1F, 150F, 2.1F, "geo/dragon/soul_eater", "Cosecha de almas", "Grito de almas");
        add("chronos_herald", "Chronos Herald", Element.TIME, Rarity.LEGENDARY, 1.8F, 300F, 2.5F, "geo/dragon/time_herald", "Parada del tiempo", "Colapso temporal");
        add("fortune_bringer", "Fortune Bringer", Element.LUCK, Rarity.LEGENDARY, 1.2F, 250F, 1.8F, "geo/dragon/luck_bringer", "Fortuna", "Moneda del destino");
        add("mind_weaver", "Mind Weaver", Element.PSYCHE, Rarity.LEGENDARY, 1.1F, 200F, 2.5F, "geo/dragon/psyche_weaver", "Mente abierta", "Choque mental");
        add("legend_stalker", "Legend Stalker", Element.LEGEND, Rarity.LEGENDARY, 2.0F, 400F, 2.8F, "geo/dragon/legend_stalker", "Aura legendaria", "Borrador de mundos");
        add("sun_guardian", "Sun Guardian", Element.SUN, Rarity.LEGENDARY, 2.2F, 350F, 2.6F, "geo/dragon/sun_guardian", "Radiancia solar", "Supernova");
        add("moon_sentinel", "Moon Sentinel", Element.MOON, Rarity.LEGENDARY, 2.1F, 330F, 2.4F, "geo/dragon/moon_sentinel", "Fase lunar", "Rayo de luna");
        add("gravity_well", "Gravity Well", Element.GRAVITY, Rarity.LEGENDARY, 1.9F, 380F, 2.7F, "geo/dragon/gravity_well", "Pozo gravitatorio", "Aplastamiento");
        add("dimen_lord", "Dimen Lord", Element.DIMENSION, Rarity.LEGENDARY, 1.5F, 280F, 2.3F, "geo/dragon/dimen_lord", "Paso dimensional", "Desgarro del espacio");
        add("chaos_spawn", "Chaos Spawn", Element.CHAOS, Rarity.LEGENDARY, 1.7F, 320F, 2.6F, "geo/dragon/chaos_spawn", "Aura caótica", "Estallido caótico");
        add("order_knight", "Order Knight", Element.ORDER, Rarity.LEGENDARY, 1.7F, 340F, 2.2F, "geo/dragon/order_knight", "Orden férreo", "Sentencia");
        add("void_emperor", "Void Emperor", Element.VOID, Rarity.MYTHIC, 2.2F, 600F, 3.5F, "geo/dragon/void_emperor", "Vacío absoluto", "Implosión del vacío");
        add("cosmic_entity", "Cosmic Entity", Element.COSMIC, Rarity.MYTHIC, 2.8F, 800F, 4.0F, "geo/dragon/cosmic_entity", "Polvo estelar", "Lluvia de estrellas");
        add("time_weaver", "Time Weaver", Element.TIME, Rarity.ANCIENT, 2.0F, 500F, 3.2F, "geo/dragon/time_weaver", "Parada del tiempo", "Colapso temporal");
        add("fate_weaver", "Fate Weaver", Element.LUCK, Rarity.ANCIENT, 1.5F, 400F, 3.0F, "geo/dragon/fate_weaver", "Fortuna", "Moneda del destino");
        add("psyche_overlord", "Psyche Overlord", Element.PSYCHE, Rarity.MYTHIC, 1.2F, 350F, 3.8F, "geo/dragon/psyche_overlord", "Mente abierta", "Choque mental");
        add("legendary_beast", "Legendary Beast", Element.LEGEND, Rarity.ANCIENT, 3.5F, 1200F, 5.0F, "geo/dragon/legend_beast", "Aura legendaria", "Borrador de mundos");
        add("solar_deity", "Solar Deity", Element.SUN, Rarity.DIVINE, 3.0F, 1500F, 6.0F, "geo/dragon/sun_deity", "Radiancia solar", "Supernova");
        add("lunar_deity", "Lunar Deity", Element.MOON, Rarity.DIVINE, 2.8F, 1400F, 5.5F, "geo/dragon/moon_deity", "Fase lunar", "Rayo de luna");
        add("gravity_god", "Gravity God", Element.GRAVITY, Rarity.DIVINE, 3.5F, 2000F, 7.0F, "geo/dragon/gravity_god", "Pozo gravitatorio", "Aplastamiento");
        add("omega_dragon", "Omega Dragon", Element.VOID, Rarity.DIVINE, 5.0F, 5000F, 10.0F, "geo/dragon/omega_dragon", "Vacío absoluto", "Omni-explosión");
    }

    public static SpeciesData get(String id) {
        return id == null ? null : MAP.get(id);
    }

    public static boolean exists(String id) {
        return id != null && MAP.containsKey(id);
    }

    /** Sortea una especie para un huevo del tipo base dado (0 fuego, 1 hielo, 2 tormenta, 3 agua), segun su rareza. */
    public static String roll(int baseType, Random random) {
        int total = 0;
        for (SpeciesData data : MAP.values()) {
            total += weightFor(data, baseType);
        }
        if (total <= 0) {
            return "original_" + new String[]{"fire", "ice", "storm", "water", "fire"}[Math.max(0, Math.min(4, baseType))];
        }
        int pick = random.nextInt(total);
        for (SpeciesData data : MAP.values()) {
            pick -= weightFor(data, baseType);
            if (pick < 0) {
                return data.id;
            }
        }
        return "original_fire";
    }

    /** Probabilidad (en %) de que un huevo de su tipo base de esta especie; 0 si no sale de huevos normales. */
    public static double eggChancePercent(SpeciesData data) {
        int total = 0;
        for (SpeciesData other : MAP.values()) {
            total += weightFor(other, data.element.baseType);
        }
        return total <= 0 ? 0.0D : 100.0D * weightFor(data, data.element.baseType) / total;
    }

    /** Cuantas especies hay con ese tipo base. */
    public static int countForBase(int baseType) {
        int n = 0;
        for (SpeciesData other : MAP.values()) {
            if (other.element.baseType == baseType) {
                n++;
            }
        }
        return n;
    }

    private static int weightFor(SpeciesData data, int baseType) {
        if (data.element.baseType != baseType) {
            return 0;
        }
        int weight = data.rarity.weight;
        // el dragon "clasico" de cada tipo sale con mucha mas frecuencia
        return data.id.startsWith("original_") ? weight * 6 : weight;
    }
}
