package com.isladragoncitos.entity;

import com.isladragoncitos.item.DragonStaffItem;
import com.isladragoncitos.registry.ModItems;
import com.isladragoncitos.system.DraconicData;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.annotation.Nullable;
import com.isladragoncitos.client.ClientRiderInput;
import com.isladragoncitos.item.EdulnariItem;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.TicketType;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Dragon antiguo: nace de un huevo, crece segun lo que coma (hasta ser enorme), se monta con el
 * Montadragones, vuela, explora, defiende a su jinete con fuego, hielo o rayo y sube de nivel con
 * puntos draconianos.
 */
public class AncientDragonEntity extends TamableAnimal implements GeoEntity {
    public static final int TYPE_FIRE = 0;
    public static final int TYPE_ICE = 1;
    public static final int TYPE_STORM = 2;
    public static final int TYPE_WATER = 3;
    /** Serpiente celeste: sin alas ni patas, cuerpo ondulante, cornamenta de cristal y perla flotante. */
    public static final int TYPE_SKY = 4;

    public static final int MODE_FOLLOW = 0;
    public static final int MODE_STAY = 1;
    public static final int MODE_WANDER = 2;
    public static final int MODE_EXPLORE = 3;
    public static final int MODE_GOTO = 4;

    public static final int FOOD_MAX = 3000;
    public static final int MAX_STRENGTH = 200;
    public static final int MAX_SPEED = 20;
    public static final int MAX_HEALTH_LVL = 400;
    public static final int MAX_SCALES = 100;

    private static final EntityDataAccessor<String> DATA_SPECIES =
            SynchedEntityData.defineId(AncientDragonEntity.class, EntityDataSerializers.STRING);

    /** Cuenta atras (ticks) hasta el siguiente ataque especial de la especie. */
    public int specialCd;

    /** Id de la especie (vacio = dragon clasico de su tipo, sin pasiva ni especial). */
    public String getSpeciesId() {
        return this.entityData.get(DATA_SPECIES);
    }

    public void setSpeciesId(String id) {
        this.entityData.set(DATA_SPECIES, id == null ? "" : id);
        this.refreshStats();
        this.refreshDimensions();
    }

    /** El huevo generador crea un dragon de cualquier tipo y especie al azar (no solo el de fuego). */
    @Override
    public net.minecraft.world.entity.SpawnGroupData finalizeSpawn(net.minecraft.world.level.ServerLevelAccessor level,
            net.minecraft.world.DifficultyInstance difficulty, net.minecraft.world.entity.MobSpawnType reason,
            @Nullable net.minecraft.world.entity.SpawnGroupData data, @Nullable CompoundTag tag) {
        if (reason == net.minecraft.world.entity.MobSpawnType.SPAWN_EGG && this.getSpeciesId().isEmpty()) {
            // primero el tipo (fuego, hielo, tormenta, agua o celeste, todos con la misma probabilidad) y luego su especie
            int type = this.getRandom().nextInt(5);
            String species = com.isladragoncitos.entity.species.DragonSpecies.roll(type, new java.util.Random(this.getRandom().nextLong()));
            this.setDragonType(type);
            this.setSpeciesId(species);
            this.setHealth(this.getMaxHealth());
        }
        return super.finalizeSpawn(level, difficulty, reason, data, tag);
    }

    @javax.annotation.Nullable
    public com.isladragoncitos.entity.species.DragonSpecies.SpeciesData getSpecies() {
        return com.isladragoncitos.entity.species.DragonSpecies.get(this.getSpeciesId());
    }

    /** Factor visual de la especie: las grandes se ven mas grandes, sin pasarse. */
    public float getSpeciesSize() {
        var species = this.getSpecies();
        return species == null ? 1.0F : Mth.clamp((float) Math.pow(species.sizeMultiplier, 0.6D), 0.75F, 2.4F);
    }

    private void tickSpecies() {
        var species = this.getSpecies();
        if (species == null || !this.isTame()) {
            return;
        }
        if (this.tickCount % 40 == 0) {
            com.isladragoncitos.entity.species.SpeciesEffects.tickPassive(this);
        }
        if (this.specialCd > 0) {
            this.specialCd--;
        } else if (this.tickCount % 10 == 0) {
            LivingEntity target = this.getTarget();
            if (target != null && target.isAlive() && this.distanceToSqr(target) < 30.0D * 30.0D
                    && com.isladragoncitos.entity.species.SpeciesEffects.castSpecial(this, target)) {
                this.specialCd = com.isladragoncitos.entity.species.SpeciesEffects.cooldownTicks(species);
            }
        }
    }

    private static final EntityDataAccessor<Integer> DATA_TYPE =
            SynchedEntityData.defineId(AncientDragonEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_FOOD =
            SynchedEntityData.defineId(AncientDragonEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_FLYING =
            SynchedEntityData.defineId(AncientDragonEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_BREATHING =
            SynchedEntityData.defineId(AncientDragonEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_SPEED =
            SynchedEntityData.defineId(AncientDragonEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_MODE =
            SynchedEntityData.defineId(AncientDragonEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_SCALES =
            SynchedEntityData.defineId(AncientDragonEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_SADDLED =
            SynchedEntityData.defineId(AncientDragonEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_MARK =
            SynchedEntityData.defineId(AncientDragonEntity.class, EntityDataSerializers.BOOLEAN);

    // mejoras
    private int strengthLvl;
    private int healthLvl;
    private boolean sharedLife;
    private boolean statsInit;
    private int scaleHits;
    private boolean nightVisionGiven;

    // ordenes
    @Nullable
    private BlockPos home;
    @Nullable
    private Vec3 goal;
    private String goalName = "";
    private boolean goalIsNearestSearch;
    private boolean goalFlight;
    private double exploreHeading;
    private int exploreFlightState = -1;
    private int idleTicks;
    private int breathTick;
    private int lightningCooldown;
    private int searchWait;
    /** Como los lobos: true mientras va hacia su dueno, false mientras se queda cerca haciendo sus cosas. */
    private boolean following;
    private double speedMult = 1.0D;
    private int farTicks;
    private static final TicketType<ChunkPos> DRAGON_TICKET =
            TicketType.create("isladragoncitos_dragon", java.util.Comparator.comparingLong(ChunkPos::toLong), 60);
    @Nullable
    private Vec3 cachedDir;
    @Nullable
    private Vec3 lastStuckPos;
    private int climbTicks;
    @Nullable
    private Vec3 climbDir;

    // animacion (cliente y servidor)
    private float flyAnim;
    private float flyAnimO;
    private float breathAnim;
    private float breathAnimO;

    // solo en el cliente del jinete
    private boolean rideFlying;
    private int rideAirTicks;

    public AncientDragonEntity(EntityType<? extends AncientDragonEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        this.refreshStats();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.FLYING_SPEED, 0.6D)
                .add(Attributes.ATTACK_DAMAGE, 8.0D)
                .add(Attributes.FOLLOW_RANGE, 64.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this) {
            @Override
            public boolean canUse() {
                return !AncientDragonEntity.this.isWaterDragon() && super.canUse();
            }
        });
        this.targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
        this.targetSelector.addGoal(3, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, Monster.class, 10, true, false,
                target -> this.isTame() && this.getOwner() != null && this.distanceToSqr(this.getOwner()) < 24.0D * 24.0D));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_TYPE, TYPE_FIRE);
        this.entityData.define(DATA_FOOD, 0);
        this.entityData.define(DATA_FLYING, false);
        this.entityData.define(DATA_BREATHING, false);
        this.entityData.define(DATA_SPEED, 0);
        this.entityData.define(DATA_MODE, MODE_FOLLOW);
        this.entityData.define(DATA_SCALES, 0);
        this.entityData.define(DATA_MARK, false);
        this.entityData.define(DATA_SADDLED, false);
        this.entityData.define(DATA_SPECIES, "");
    }


    // ------------------------------------------------------------------ animaciones (GeckoLib)

    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);

    private static final String[] ANIM_PREFIX = {"animation.fire_dragon.", "animation.ice_dragon.",
            "animation.storm_dragon.", "animation.water_dragon.", "animation.sky_dragon."};

    private String animName(String name) {
        return ANIM_PREFIX[this.getDragonType()] + name;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "move", 6, this::movePredicate));
        controllers.add(new AnimationController<>(this, "action", 3, this::actionPredicate));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.geoCache;
    }

    /** idle / walk en tierra, fly / glide en el aire, swim / swim_idle bajo el agua (solo el dragon del agua). */
    private PlayState movePredicate(AnimationState<AncientDragonEntity> state) {
        String name;
        if (this.isWaterDragon() && this.isInWater()) {
            name = state.isMoving() ? "swim" : "swim_idle";
        } else if (this.isFlying()) {
            name = this.getDeltaMovement().y < -0.12D ? "glide" : "fly";
        } else {
            name = state.isMoving() ? "walk" : "idle";
        }
        return state.setAndContinue(RawAnimation.begin().thenLoop(this.animName(name)));
    }

    /** El aliento (cuello, cabeza y mandibula) se anima encima del movimiento mientras escupe. */
    private PlayState actionPredicate(AnimationState<AncientDragonEntity> state) {
        if (this.isBreathing()) {
            return state.setAndContinue(RawAnimation.begin().thenPlay(this.animName("breath")));
        }
        return PlayState.STOP;
    }

    // ------------------------------------------------------------------ datos

    public int getDragonType() {
        return Mth.clamp(this.entityData.get(DATA_TYPE), 0, 4);
    }

    public void setDragonType(int type) {
        this.entityData.set(DATA_TYPE, Mth.clamp(type, 0, 4));
    }

    public int getFood() {
        return this.entityData.get(DATA_FOOD);
    }

    public void setFood(int food) {
        this.entityData.set(DATA_FOOD, Mth.clamp(food, 0, FOOD_MAX));
    }

    public boolean isFlying() {
        return this.entityData.get(DATA_FLYING);
    }

    public void setFlying(boolean flying) {
        this.entityData.set(DATA_FLYING, flying);
    }

    public int getMode() {
        return this.entityData.get(DATA_MODE);
    }

    public void setMode(int mode) {
        this.entityData.set(DATA_MODE, mode);
    }

    public int getSpeedLvl() {
        return this.entityData.get(DATA_SPEED);
    }

    public int getScales() {
        return this.entityData.get(DATA_SCALES);
    }

    public int getStrengthLvl() {
        return this.strengthLvl;
    }

    public int getHealthLvl() {
        return this.healthLvl;
    }

    public boolean hasSharedLife() {
        return this.sharedLife;
    }

    public boolean isSaddled() {
        return this.entityData.get(DATA_SADDLED);
    }

    public void setSaddled(boolean saddled) {
        this.entityData.set(DATA_SADDLED, saddled);
    }

    public boolean isWaterDragon() {
        return this.getDragonType() == TYPE_WATER;
    }

    /** 2 si el dueno tiene la Marca del Jinete (duplica las ventajas), 1 si no. */
    public int markMult() {
        return this.entityData.get(DATA_MARK) ? 2 : 1;
    }

    public boolean isBreathing() {
        return this.entityData.get(DATA_BREATHING);
    }

    public float getFlyAnim(float partial) {
        return Mth.lerp(partial, this.flyAnimO, this.flyAnim);
    }

    public float getBreathAnim(float partial) {
        return Mth.lerp(partial, this.breathAnimO, this.breathAnim);
    }

    @Nullable
    public BlockPos getHome() {
        return this.home;
    }

    /** Tamano visual: de cria (0.55) a gigante (15). Depende solo de la comida recibida. */
    public float getVisualScale() {
        float ratio = (float) this.getFood() / (float) FOOD_MAX;
        return (0.55F + 14.45F * (float) Math.pow(ratio, 1.2D)) * this.getSpeciesSize();
    }

    private float collisionScale() {
        float vis = this.getVisualScale();
        return vis <= 6.0F ? vis : 6.0F + (vis - 6.0F) * 0.35F;
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return super.getDimensions(pose).scale(this.collisionScale());
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (DATA_FOOD.equals(key)) {
            this.refreshDimensions();
            this.setMaxUpStep(Math.max(1.0F, this.collisionScale() * 0.6F));
        }
    }

    /** Recalcula atributos a partir de los niveles. */
    public void refreshStats() {
        int mult = this.markMult();
        var species = this.getSpecies();
        double speciesHp = species == null ? 0.0D : species.healthBonus;
        double speciesDmg = species == null ? 1.0D : species.damageMultiplier;
        this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(20.0D + speciesHp + (double) this.healthLvl * mult);
        this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue((6.0D + 0.5D * this.strengthLvl * mult) * speciesDmg);
        this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.25D * (1.0D + 0.1D * this.getSpeedLvl() * mult));
        this.setMaxUpStep(Math.max(1.0F, this.collisionScale() * 0.6F));
    }

    public void setStrengthLvl(int v) {
        this.strengthLvl = Mth.clamp(v, 0, MAX_STRENGTH);
        this.refreshStats();
    }

    public void setHealthLvl(int v) {
        this.healthLvl = Mth.clamp(v, 0, MAX_HEALTH_LVL);
        this.refreshStats();
    }

    public void setSpeedLvl(int v) {
        this.entityData.set(DATA_SPEED, Mth.clamp(v, 0, MAX_SPEED));
        this.refreshStats();
    }

    public void setScales(int v) {
        this.entityData.set(DATA_SCALES, Mth.clamp(v, 0, MAX_SCALES));
    }

    /** Aplica una esencia (edulnari): hereda niveles y habilidades, pero ni el tamano ni las escamas. */
    public void applyEssence(CompoundTag essence) {
        this.strengthLvl = Mth.clamp(essence.getInt("Strength"), 0, MAX_STRENGTH);
        this.healthLvl = Mth.clamp(essence.getInt("Health"), 0, MAX_HEALTH_LVL);
        int speed = Mth.clamp(essence.getInt("Speed"), 0, MAX_SPEED);
        this.sharedLife = essence.getBoolean("Shared");
        this.statsInit = true;
        int scales = 0;
        if (this.isWaterDragon()) {
            this.strengthLvl = Math.max(this.strengthLvl, 20);
            this.healthLvl = Math.max(this.healthLvl, 60);
            speed = Math.max(speed, 2);
            scales = 10;
        }
        this.entityData.set(DATA_SPEED, speed);
        this.setScales(scales);
        this.refreshStats();
        this.setHealth(this.getMaxHealth());
    }

    public void setSharedLife(boolean v) {
        this.sharedLife = v;
    }

    // --------------------------------------------------------------------- NBT

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("DragonType", this.getDragonType());
        tag.putString("Species", this.getSpeciesId());
        tag.putInt("Food", this.getFood());
        tag.putInt("StrengthLvl", this.strengthLvl);
        tag.putInt("HealthLvl", this.healthLvl);
        tag.putInt("SpeedLvl", this.getSpeedLvl());
        tag.putInt("Scales", this.getScales());
        tag.putBoolean("SharedLife", this.sharedLife);
        tag.putBoolean("StatsInit", this.statsInit);
        tag.putBoolean("Saddled", this.isSaddled());
        tag.putInt("Mode", this.getMode());
        tag.putBoolean("Flying", this.isFlying());
        if (this.home != null) {
            tag.putLong("Home", this.home.asLong());
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setDragonType(tag.getInt("DragonType"));
        this.entityData.set(DATA_SPECIES, tag.getString("Species"));
        this.setFood(tag.getInt("Food"));
        this.strengthLvl = tag.getInt("StrengthLvl");
        this.healthLvl = tag.getInt("HealthLvl");
        this.entityData.set(DATA_SPEED, tag.getInt("SpeedLvl"));
        this.setScales(tag.getInt("Scales"));
        this.sharedLife = tag.getBoolean("SharedLife");
        this.statsInit = tag.getBoolean("StatsInit");
        this.setSaddled(tag.getBoolean("Saddled"));
        this.setMode(tag.getInt("Mode") == MODE_EXPLORE || tag.getInt("Mode") == MODE_GOTO ? MODE_FOLLOW : tag.getInt("Mode"));
        this.setFlying(tag.getBoolean("Flying"));
        this.home = tag.contains("Home") ? BlockPos.of(tag.getLong("Home")) : null;
        this.refreshStats();
        if (this.getHealth() > this.getMaxHealth()) {
            this.setHealth(this.getMaxHealth());
        }
    }

    // --------------------------------------------------------------- interaccion

    /** Valor de crecimiento de un alimento, 0 si no es comida para el dragon. */
    public static int foodValue(ItemStack stack) {
        if (stack.is(Items.ENCHANTED_GOLDEN_APPLE)) {
            return 400;
        }
        if (stack.is(Items.GOLDEN_APPLE)) {
            return 100;
        }
        FoodProperties props = stack.getItem().getFoodProperties();
        if (props != null && props.isMeat()) {
            return Math.max(6, props.getNutrition() * 3);
        }
        return 0;
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        int value = foodValue(stack);
        boolean client = this.level().isClientSide;

        if (!this.isTame()) {
            if (value > 0) {
                if (!client) {
                    if (!player.getAbilities().instabuild) {
                        stack.shrink(1);
                    }
                    this.setFood(this.getFood() + value);
                    if (this.random.nextInt(3) == 0) {
                        this.tame(player);
                        DraconicData.setActiveDragon(player, this);
                        this.level().broadcastEntityEvent(this, (byte) 7);
                    } else {
                        this.level().broadcastEntityEvent(this, (byte) 6);
                    }
                }
                return InteractionResult.sidedSuccess(client);
            }
            return InteractionResult.PASS;
        }
        if (!this.isOwnedBy(player)) {
            return InteractionResult.PASS;
        }
        if (stack.getItem() instanceof DragonStaffItem) {
            return DragonStaffItem.capture(this, player, stack);
        }
        if (stack.is(ModItems.DRAGON_RIDER.get())) {
            if (!this.isSaddled()) {
                if (!client) {
                    if (!player.getAbilities().instabuild) {
                        stack.shrink(1);
                    }
                    this.setSaddled(true);
                    this.playSound(SoundEvents.HORSE_SADDLE, 1.0F, 1.0F);
                    player.displayClientMessage(Component.literal("La montura queda puesta en tu dragón."), true);
                }
                return InteractionResult.sidedSuccess(client);
            }
            if (player.isShiftKeyDown()) {
                if (!client) {
                    this.ejectPassengers();
                    this.setSaddled(false);
                    this.spawnAtLocation(new ItemStack(ModItems.DRAGON_RIDER.get()));
                    player.displayClientMessage(Component.literal("Has quitado la montura."), true);
                }
                return InteractionResult.sidedSuccess(client);
            }
            return this.mountBy(player, client);
        }
        if (value > 0) {
            if (!client) {
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
                this.setFood(this.getFood() + value);
                this.heal(value / 2.0F);
                if (this.level() instanceof ServerLevel serverLevel) {
                    serverLevel.sendParticles(ParticleTypes.HAPPY_VILLAGER, this.getX(), this.getY() + this.getBbHeight() * 0.6D,
                            this.getZ(), 10, this.getBbWidth() * 0.3D, 0.3D, this.getBbWidth() * 0.3D, 0.0D);
                }
                if (this.getFood() >= FOOD_MAX && player instanceof ServerPlayer serverPlayer) {
                    DraconicData.grant(serverPlayer, "giant_dragon");
                }
            }
            return InteractionResult.sidedSuccess(client);
        }
        if (stack.isEmpty() && !player.isShiftKeyDown() && this.isSaddled()) {
            return this.mountBy(player, client);
        }
        if (stack.isEmpty() && player.isShiftKeyDown()) {
            if (!client) {
                this.setMode(this.getMode() == MODE_STAY ? MODE_FOLLOW : MODE_STAY);
                this.clearGoal();
                player.displayClientMessage(Component.literal(this.getMode() == MODE_STAY
                        ? "Tu dragón se queda aquí." : "Tu dragón te sigue."), true);
            }
            return InteractionResult.sidedSuccess(client);
        }
        return InteractionResult.PASS;
    }

    private InteractionResult mountBy(Player player, boolean client) {
        if (!client && !this.isVehicle()) {
            player.startRiding(this);
            DraconicData.setActiveDragon(player, this);
            if (player instanceof ServerPlayer serverPlayer) {
                DraconicData.grant(serverPlayer, "first_ride");
            }
        }
        return InteractionResult.sidedSuccess(client);
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return foodValue(stack) > 0;
    }

    @Override
    public boolean canMate(net.minecraft.world.entity.animal.Animal other) {
        return false;
    }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob other) {
        return null;
    }

    @Override
    public boolean wantsToAttack(LivingEntity target, LivingEntity owner) {
        if (target == owner || (target instanceof Player p && this.isOwnedBy(p))) {
            return false;
        }
        if (target instanceof TamableAnimal pet && pet.isTame() && pet.getOwner() == owner) {
            return false;
        }
        return !(target instanceof DragoncitoEntity);
    }

    // -------------------------------------------------------------------- monta

    @Nullable
    @Override
    public LivingEntity getControllingPassenger() {
        Entity first = this.getFirstPassenger();
        if (first instanceof Player player && this.isOwnedBy(player) && this.getMode() != MODE_EXPLORE
                && this.getMode() != MODE_GOTO) {
            return player;
        }
        return null;
    }

    /**
     * El jinete va sentado por encima de todo el modelo (lomo, pinchos y hombros miden hasta ~1.6 * escala bloques), asi
     * que la camara nunca queda dentro del dragon, sea cual sea su tamano.
     */
    @Override
    public double getPassengersRidingOffset() {
        return 1.7D * this.getVisualScale() + 0.5D;
    }

    @Override
    public void positionRider(Entity passenger, Entity.MoveFunction callback) {
        if (!this.hasPassenger(passenger)) {
            return;
        }
        double back = 0.2D * this.getVisualScale();
        double yaw = Math.toRadians(this.yBodyRot);
        callback.accept(passenger, this.getX() + Math.sin(yaw) * back,
                this.getY() + this.getPassengersRidingOffset() + passenger.getMyRidingOffset(),
                this.getZ() - Math.cos(yaw) * back);
    }

    @Override
    public net.minecraft.world.phys.AABB getBoundingBoxForCulling() {
        // el modelo (alas, cola, cuello) es mucho mas grande que la hitbox
        return this.getBoundingBox().inflate(this.getVisualScale() * 5.5D);
    }

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return this.getPassengers().isEmpty();
    }

    @Override
    protected void removePassenger(Entity passenger) {
        super.removePassenger(passenger);
        if (passenger instanceof LivingEntity living && !this.level().isClientSide) {
            living.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 300, 0));
        }
    }

    @Override
    public boolean canBreatheUnderwater() {
        return this.isWaterDragon();
    }

    @Override
    public boolean isInWall() {
        return false;
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean canBeLeashed(Player player) {
        return false;
    }

    // ------------------------------------------------------------------- danio

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypeTags.IS_FALL) || source.is(net.minecraft.world.damagesource.DamageTypes.IN_WALL)) {
            return false;
        }
        if (!this.level().isClientSide && amount > 0.0F && this.getScales() > 0
                && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            amount /= 2.0F;
            if (this.markMult() == 1 || ++this.scaleHits % 2 == 0) {
                this.setScales(this.getScales() - 1);
            }
            if (this.level() instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(ParticleTypes.CRIT, this.getX(), this.getY() + this.getBbHeight() * 0.6D, this.getZ(),
                        8, this.getBbWidth() * 0.3D, 0.3D, this.getBbWidth() * 0.3D, 0.1D);
            }
            if (this.getScales() == 0 && this.getOwner() instanceof ServerPlayer owner) {
                owner.displayClientMessage(Component.literal("Tu dragón se ha quedado sin escamas protectoras."), true);
            }
        }
        if (!this.level().isClientSide && this.sharedLife && this.getOwner() instanceof ServerPlayer owner
                && owner.level() == this.level() && owner.isAlive() && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            // el dano al dragon se resta directamente de la vida compartida (sin tiempo de invulnerabilidad)
            this.playHurtSound(source);
            float remaining = owner.getHealth() - amount;
            if (remaining > 0.0F) {
                owner.setHealth(remaining);
            } else {
                owner.setHealth(0.0F);
                owner.die(source);
            }
            return true;
        }
        return super.hurt(source, amount);
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!this.level().isClientSide) {
            if (this.strengthLvl > 0 || this.healthLvl > 0 || this.getSpeedLvl() > 0 || this.sharedLife) {
                ItemEntity drop = this.spawnAtLocation(EdulnariItem.create(this.strengthLvl, this.healthLvl,
                        this.getSpeedLvl(), this.sharedLife, this.getDragonType()));
                if (drop != null) {
                    drop.setUnlimitedLifetime();
                    drop.setInvulnerable(true);
                    drop.setGlowingTag(true);
                }
            }
            DraconicData.onDragonDied(this);
        }
    }

    // ---------------------------------------------------------------------- tick

    @Override
    public void tick() {
        super.tick();
        this.flyAnimO = this.flyAnim;
        float target = this.isFlying() ? 1.0F : 0.0F;
        this.flyAnim += Mth.clamp(target - this.flyAnim, -0.08F, 0.08F);
        this.breathAnimO = this.breathAnim;
        float breathTarget = this.isBreathing() ? 1.0F : 0.0F;
        this.breathAnim += Mth.clamp(breathTarget - this.breathAnim, -0.15F, 0.15F);

        if (!this.level().isClientSide) {
            if (this.isWaterDragon()) {
                this.tickWaterDragon();
            }
            this.setNoGravity(this.isFlying());
            if (this.getFirstPassenger() instanceof Player rider && this.getControllingPassenger() != null) {
                // con el jinete al mando, el dragon esta en el aire si no hay suelo debajo
                AABB below = this.getBoundingBox().inflate(-0.1D, 0.0D, -0.1D).move(0.0D, -0.4D, 0.0D);
                this.setFlying(this.level().noCollision(this, below));
            }
        }
    }

    /** El dragon del agua vuela bajo el agua y da respiracion y vision nocturna acuaticas a su jinete. */
    private void tickWaterDragon() {
        boolean inWater = this.isInWater();
        if (inWater && !this.isFlying() && this.getControllingPassenger() == null) {
            this.setFlying(true);
        }
        if (this.getFirstPassenger() instanceof Player rider) {
            if (inWater) {
                if (this.tickCount % 10 == 0) {
                    rider.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 400, 0, true, false, true));
                    rider.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, true, false, true));
                    this.nightVisionGiven = true;
                }
            } else if (this.nightVisionGiven) {
                rider.removeEffect(MobEffects.NIGHT_VISION);
                rider.removeEffect(MobEffects.WATER_BREATHING);
                this.nightVisionGiven = false;
            }
        }
    }

    /** Actualiza la marca del jinete del dueno y las estadisticas iniciales segun el tipo. */
    private void tickServerStats() {
        if (!this.statsInit) {
            this.statsInit = true;
            if (this.isWaterDragon()) {
                this.strengthLvl = 20;
                this.healthLvl = 60;
                this.entityData.set(DATA_SPEED, 2);
                this.setScales(10);
                this.refreshStats();
                this.setHealth(this.getMaxHealth());
            }
        }
        if (this.tickCount % 20 == 0) {
            boolean mark = this.getOwner() instanceof Player owner && DraconicData.hasMark(owner);
            if (mark != this.entityData.get(DATA_MARK)) {
                float ratio = this.getHealth() / this.getMaxHealth();
                this.entityData.set(DATA_MARK, mark);
                this.refreshStats();
                this.setHealth(Math.max(1.0F, this.getMaxHealth() * ratio));
            }
        }
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            this.clientEffects();
            return;
        }
        this.tickServerStats();
        this.tickSpecies();
        if (this.tickCount % 200 == 0 && this.getHealth() < this.getMaxHealth() && !this.sharedLife) {
            this.heal(1.0F + this.getMaxHealth() * 0.01F);
        }
    }

    private void clientEffects() {
        if (this.getFood() > 0 && this.random.nextInt(8) == 0) {
            ParticleOptions particle = this.getDragonType() == TYPE_FIRE ? ParticleTypes.SMALL_FLAME
                    : (this.getDragonType() == TYPE_ICE ? ParticleTypes.SNOWFLAKE
                    : (this.getDragonType() == TYPE_WATER ? ParticleTypes.BUBBLE_POP
                    : (this.getDragonType() == TYPE_SKY ? ParticleTypes.END_ROD : ParticleTypes.ELECTRIC_SPARK)));
            float scale = this.getVisualScale();
            this.level().addParticle(particle, this.getX() + (this.random.nextDouble() - 0.5D) * scale * 1.2D,
                    this.getY() + this.random.nextDouble() * scale * 1.2D, this.getZ() + (this.random.nextDouble() - 0.5D) * scale * 1.2D,
                    0.0D, 0.02D, 0.0D);
        }
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        LivingEntity owner = this.getOwner();
        Entity rider = this.getFirstPassenger();

        // el jinete recupera el control si mueve el dragon con el teclado
        if (rider instanceof Player player && (this.getMode() == MODE_EXPLORE || this.getMode() == MODE_GOTO)
                && (Math.abs(player.xxa) > 0.01F || Math.abs(player.zza) > 0.01F)) {
            this.setMode(MODE_FOLLOW);
            this.clearGoal();
            player.displayClientMessage(Component.literal("Has tomado el control del dragón."), true);
        }

        this.tickCombat();
        this.keepLoaded(owner);
        this.speedMult = 1.0D;

        if (this.getControllingPassenger() != null || !this.isTame()) {
            this.idleTicks = 0;
            return;
        }
        switch (this.getMode()) {
            case MODE_STAY -> this.brainStay();
            case MODE_WANDER -> this.brainWander();
            case MODE_EXPLORE -> this.brainExplore();
            case MODE_GOTO -> this.brainGoto();
            default -> this.brainFollow(owner);
        }
        this.executeGoal();
    }

    /**
     * Si el dragon esta lejos de su dueno (explorando, de viaje o volviendo), mantiene cargados los chunks que lo
     * rodean para que siga moviendose y obedezca la orden de volver.
     */
    private void keepLoaded(@Nullable LivingEntity owner) {
        if (this.tickCount % 20 != 0 || !this.isTame() || owner == null || !(this.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        boolean far = owner.level() == this.level() && this.distanceToSqr(owner) > 48.0D * 48.0D;
        if (far || this.getMode() == MODE_EXPLORE || this.getMode() == MODE_GOTO) {
            ChunkPos chunk = this.chunkPosition();
            serverLevel.getChunkSource().addRegionTicket(DRAGON_TICKET, chunk, 2, chunk);
        }
    }

    public void clearGoal() {
        this.goal = null;
        this.goalName = "";
        this.goalIsNearestSearch = false;
        this.exploreFlightState = -1;
    }

    // ------------------------------------------------------------ comportamientos

    private void brainStay() {
        this.goal = null;
        if (this.isFlying()) {
            this.land();
        }
    }

    private void land() {
        if (this.onGround()) {
            this.setFlying(false);
        } else {
            // apunta un poco por debajo del suelo que tiene justo debajo para que llegue a tocarlo
            this.goal = new Vec3(this.getX(), this.groundBelow() - 1.0D, this.getZ());
            this.goalFlight = true;
        }
    }

    /** Altura del primer bloque solido (o liquido) que hay justo debajo del dragon, aunque este bajo un techo. */
    private double groundBelow() {
        int x = this.getBlockX();
        int z = this.getBlockZ();
        int minY = this.level().getMinBuildHeight();
        int y = this.getBlockY();
        for (int i = 0; i < 160 && y > minY; i++, y--) {
            BlockPos below = new BlockPos(x, y - 1, z);
            BlockState state = this.level().getBlockState(below);
            if (!state.getCollisionShape(this.level(), below).isEmpty() || !state.getFluidState().isEmpty()) {
                return y;
            }
        }
        return this.getY();
    }

    private double groundY(int x, int z) {
        if (!this.level().hasChunkAt(new BlockPos(x, 0, z))) {
            return this.getY();
        }
        return this.level().getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
    }

    /**
     * Seguir como un lobo, pero A PIE: si te alejas, va hacia ti caminando; cuando esta cerca se detiene y hace sus
     * cosas (pasea, mira alrededor) sin pegarse a ti. Solo vuela para alcanzarte cuando estas muy lejos, y en cuanto
     * esta cerca BAJA AL SUELO y te sigue andando (nunca se queda flotando a la altura de tu cabeza).
     */
    private void brainFollow(@Nullable LivingEntity owner) {
        if (owner == null || owner.level() != this.level()) {
            this.goal = null;
            return;
        }
        float cs = this.collisionScale();
        // distancia cómoda: el dragon te acompana desde lejos, sin agobiarte ni pegarse a tu cabeza
        double stop = 14.0D + cs * 1.2D;
        double start = stop + 12.0D + cs * 0.8D;
        double dx = owner.getX() - this.getX();
        double dz = owner.getZ() - this.getZ();
        double hd = Math.sqrt(dx * dx + dz * dz);
        double dy = Math.abs(owner.getY() - this.getY());
        double dist = this.distanceTo(owner);

        // demasiado lejos o sin avanzar: se teletransporta junto a su dueno (como los lobos)
        if (dist > Math.max(90.0D, start + 40.0D)) {
            this.teleportNear(owner, stop + 3.0D);
            return;
        }
        if (hd > start && this.following) {
            this.farTicks++;
            if (this.farTicks > 400 && dist > 40.0D) {
                this.teleportNear(owner, stop + 3.0D);
                return;
            }
        } else {
            this.farTicks = 0;
        }

        boolean ownerAir = !owner.onGround() && !owner.isInWater()
                && owner.getY() - this.groundY(owner.getBlockX(), owner.getBlockZ()) > 3.0D;
        // a esta distancia caminar tardaria demasiado: vuela para alcanzarte y baja al llegar
        boolean farAway = hd > stop + 28.0D + cs * 2.0D;

        if (!this.following) {
            if (hd > start || (!ownerAir && dy > 8.0D + cs && hd > stop + 3.0D)) {
                this.following = true;
            }
        } else if (hd <= stop) {
            this.following = false;
            this.goal = null;
            this.idleTicks = 30 + this.random.nextInt(60);
        }

        if (this.following) {
            double ux = hd > 0.01D ? -dx / hd : 1.0D;
            double uz = hd > 0.01D ? -dz / hd : 0.0D;
            // se detiene a su distancia de seguimiento, no encima del dueno
            double tx = owner.getX() + ux * stop;
            double tz = owner.getZ() + uz * stop;
            if (farAway && !this.isFlying()) {
                this.setFlying(true);
            }
            if (this.isWaterDragon() && this.isInWater()) {
                // el dragon del agua nada a la altura de su dueno (no baja al fondo)
                this.goal = new Vec3(tx, owner.getY(), tz);
                this.goalFlight = true;
            } else if (this.isFlying()) {
                double ground = this.groundY((int) Math.floor(tx), (int) Math.floor(tz));
                if (hd < stop + 14.0D + cs) {
                    // ya esta cerca: baja al suelo (apunta un poco bajo tierra para tocarlo) y sigue a pie
                    if (this.onGround()) {
                        this.setFlying(false);
                        this.goal = new Vec3(tx, this.getY(), tz);
                        this.goalFlight = false;
                    } else {
                        this.goal = new Vec3(tx, ground - 1.0D, tz);
                        this.goalFlight = true;
                    }
                } else {
                    // viaje largo: crucero bien por encima del suelo, nunca a la altura de la cabeza del dueno
                    this.goal = new Vec3(tx, ground + 10.0D + cs, tz);
                    this.goalFlight = true;
                }
            } else {
                this.goal = new Vec3(tx, this.getY(), tz);
                this.goalFlight = false;
            }
            return;
        }

        // cerca del dueno: si estaba volando, aterriza primero (el dragon del agua se queda nadando)
        if (this.isFlying() && !(this.isWaterDragon() && this.isInWater())) {
            this.land();
            if (this.isFlying()) {
                return;
            }
        }
        // si TU te acercas al dragon, se queda quieto: nunca huye de ti
        if (hd < stop * 0.6D) {
            this.goal = null;
            this.idleTicks = 20;
            return;
        }
        // y se entretiene paseando a pie cerca de donde esta, siempre a una buena distancia de ti
        this.speedMult = 0.45D;
        if (this.goal != null) {
            double gx = this.goal.x - owner.getX();
            double gz = this.goal.z - owner.getZ();
            boolean reached = this.position().distanceToSqr(this.goal) < 4.0D + cs * cs * 0.3D;
            boolean tooClose = Math.sqrt(gx * gx + gz * gz) < stop * 0.7D;
            if (reached || tooClose) {
                this.goal = null;
                this.idleTicks = 60 + this.random.nextInt(140);
            }
        }
        if (this.goal == null) {
            if (this.idleTicks > 0) {
                this.idleTicks--;
                return;
            }
            for (int attempt = 0; attempt < 6; attempt++) {
                double angle = this.random.nextDouble() * Math.PI * 2.0D;
                double radius = 4.0D + this.random.nextDouble() * (6.0D + cs);
                double x = this.getX() + Math.cos(angle) * radius;
                double z = this.getZ() + Math.sin(angle) * radius;
                double od = Math.sqrt((x - owner.getX()) * (x - owner.getX()) + (z - owner.getZ()) * (z - owner.getZ()));
                if (od >= stop * 0.7D && od <= start * 0.9D) {
                    this.goal = new Vec3(x, this.getY(), z);
                    this.goalFlight = false;
                    return;
                }
            }
            this.idleTicks = 40 + this.random.nextInt(80);
        }
    }

    private void teleportNear(LivingEntity owner, double distance) {
        double angle = this.random.nextDouble() * Math.PI * 2.0D;
        double x = owner.getX() + Math.cos(angle) * distance;
        double z = owner.getZ() + Math.sin(angle) * distance;
        double y = owner.getY() + (owner.onGround() ? 1.0D : 3.0D);
        this.moveTo(x, y, z, this.getYRot(), 0.0F);
        this.setDeltaMovement(Vec3.ZERO);
        this.fallDistance = 0.0F;
        this.clearGoal();
        this.following = false;
        this.farTicks = 0;
        this.idleTicks = 40;
        this.setFlying(false);
    }

    private void brainWander() {
        this.speedMult = 0.55D;
        BlockPos center = this.home != null ? this.home : this.blockPosition();
        if (this.goal != null && this.position().distanceToSqr(this.goal) < 9.0D + this.collisionScale() * this.collisionScale()) {
            this.goal = null;
            this.idleTicks = 40 + this.random.nextInt(100);
        }
        if (this.goal == null) {
            if (this.idleTicks > 0) {
                this.idleTicks--;
                if (this.idleTicks == 0 && this.isFlying() && this.random.nextInt(2) == 0) {
                    this.land();
                }
                return;
            }
            double angle = this.random.nextDouble() * Math.PI * 2.0D;
            double dist = 4.0D + this.random.nextDouble() * 28.0D;
            double x = center.getX() + Math.cos(angle) * dist;
            double z = center.getZ() + Math.sin(angle) * dist;
            boolean fly = this.isFlying() || this.random.nextInt(4) == 0;
            this.setFlying(fly);
            double y = this.groundY((int) x, (int) z) + (fly ? 4.0D + this.random.nextInt(10) : 0.0D);
            this.goal = new Vec3(x, y, z);
            this.goalFlight = fly;
        }
    }

    private void brainExplore() {
        if (this.exploreFlightState < 0) {
            this.exploreFlightState = this.isFlying() ? 1 : 0;
            this.exploreHeading = Math.toRadians(this.getYRot() + 90.0F);
        }
        boolean fly = this.exploreFlightState == 1;
        this.setFlying(fly);
        LivingEntity boss = this.getOwner();
        if (boss != null && boss.level() == this.level() && this.distanceToSqr(boss) > 600.0D * 600.0D) {
            if (boss instanceof ServerPlayer player) {
                player.displayClientMessage(Component.literal("Tu dragón vuelve contigo: se ha alejado demasiado."), true);
            }
            this.orderFollow();
            return;
        }
        if (this.goal == null || this.position().distanceToSqr(this.goal) < 16.0D + this.collisionScale() * this.collisionScale()) {
            this.exploreHeading += (this.random.nextDouble() - 0.5D) * 0.9D;
            double x = this.getX() + Math.cos(this.exploreHeading) * 70.0D;
            double z = this.getZ() + Math.sin(this.exploreHeading) * 70.0D;
            double y = this.level().hasChunkAt(new BlockPos((int) x, 0, (int) z))
                    ? this.groundY((int) x, (int) z) + (fly ? 20.0D : 0.0D) : this.getY();
            if (fly) {
                y = Math.max(y, this.getY() - 6.0D);
            }
            this.goal = new Vec3(x, y, z);
            this.goalFlight = fly;
        }
    }

    private void brainGoto() {
        if (this.goal == null) {
            this.setMode(MODE_FOLLOW);
            return;
        }
        if (this.goalIsNearestSearch && this.level() instanceof ServerLevel serverLevel && this.tickCount % 10 == 0) {
            net.minecraft.world.level.levelgen.structure.StructureStart start = serverLevel.structureManager()
                    .getStructureWithPieceAt(this.blockPosition(), com.isladragoncitos.item.DragonCompassItem.ISLANDS);
            if (start.isValid()) {
                BlockPos center = start.getBoundingBox().getCenter();
                double y = this.groundY(center.getX() + 5, center.getZ()) + 1.0D;
                this.goal = new Vec3(center.getX() + 5.5D, y, center.getZ() + 0.5D);
                this.goalIsNearestSearch = false;
            }
        }
        double horizontal = Math.sqrt(Mth.square(this.goal.x - this.getX()) + Mth.square(this.goal.z - this.getZ()));
        if (this.goalIsNearestSearch && horizontal < 24.0D) {
            if (++this.searchWait > 100) {
                this.setMode(MODE_FOLLOW);
                this.clearGoal();
                this.land();
                if (this.getOwner() instanceof ServerPlayer owner) {
                    owner.displayClientMessage(Component.literal("No he podido localizar la isla exacta."), true);
                }
                return;
            }
        } else if (!this.goalIsNearestSearch) {
            this.searchWait = 0;
        }
        if (horizontal > 40.0D || this.getY() < this.goal.y - 10.0D || this.isFlying()) {
            this.setFlying(true);
        }
        this.goalFlight = true;
        if (this.position().distanceToSqr(this.goal) < 16.0D + this.collisionScale() * this.collisionScale()
                && !this.goalIsNearestSearch) {
            String name = this.goalName;
            this.setMode(MODE_FOLLOW);
            this.clearGoal();
            this.land();
            if (this.getOwner() instanceof ServerPlayer owner) {
                owner.displayClientMessage(Component.literal(name.isEmpty() ? "Hemos llegado." : "Hemos llegado a " + name + "."), true);
            }
        }
    }

    public void orderGoto(Vec3 target, String name, boolean searchNearest) {
        this.goal = target;
        this.goalName = name;
        this.goalIsNearestSearch = searchNearest;
        this.searchWait = 0;
        this.setMode(MODE_GOTO);
        this.setFlying(true);
    }

    public void orderExplore() {
        this.exploreFlightState = this.isFlying() ? 1 : 0;
        this.exploreHeading = Math.toRadians(this.getYRot() + 90.0F);
        this.goal = null;
        this.setMode(MODE_EXPLORE);
    }

    public void orderWander(BlockPos center) {
        this.home = center;
        this.goal = null;
        this.setMode(MODE_WANDER);
    }

    public void orderFollow() {
        this.clearGoal();
        this.following = true;
        this.farTicks = 0;
        this.setMode(MODE_FOLLOW);
    }

    public void orderStay() {
        this.clearGoal();
        this.setMode(MODE_STAY);
    }

    // ----------------------------------------------------------------- movimiento

    private double flySpeed() {
        double base = 0.6D + 0.08D * this.getVisualScale();
        return Math.min(2.6D, base * (1.0D + 0.1D * this.getSpeedLvl() * this.markMult()));
    }

    private double groundSpeed() {
        double base = 0.2D + 0.015D * this.getVisualScale();
        return base * (1.0D + 0.1D * this.getSpeedLvl() * this.markMult());
    }

    private void faceDirection(double dx, double dz) {
        if (dx * dx + dz * dz < 1.0E-4D) {
            return;
        }
        float target = (float) (Mth.atan2(dz, dx) * (180.0D / Math.PI)) - 90.0F;
        float yaw = Mth.wrapDegrees(Mth.approachDegrees(Mth.wrapDegrees(this.getYRot()), target, 8.0F));
        this.setYRot(yaw);
        this.yRotO = yaw;
        this.yBodyRot = yaw;
        this.yBodyRotO = yaw;
        this.yHeadRot = yaw;
        this.yHeadRotO = yaw;
    }

    /** Mueve al dragon hacia su objetivo (en vuelo o a pie), esquivando bloques por arriba, por abajo o por los lados. */
    private void executeGoal() {
        if (this.goal == null) {
            this.cachedDir = null;
            if (!this.isFlying()) {
                this.setDeltaMovement(this.getDeltaMovement().multiply(0.5D, 1.0D, 0.5D));
            }
            return;
        }
        Vec3 delta = this.goal.subtract(this.position());
        if (this.isFlying()) {
            if (delta.lengthSqr() < 1.0D) {
                if (this.onGround() && this.goalFlight && this.getMode() == MODE_FOLLOW) {
                    this.setFlying(false);
                }
                return;
            }
            // objetivo a ras de suelo (aterrizaje): desciende directo, sin que el esquivado de obstaculos lo desvie hacia arriba
            boolean landing = this.goal.y < this.getY() + 1.5D && this.goal.y <= this.groundBelow() + 2.5D;
            Vec3 dir;
            if (landing) {
                double h = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
                Vec3 steer = h > 0.5D ? this.avoidObstacles(new Vec3(delta.x / h, 0.0D, delta.z / h), h, true) : Vec3.ZERO;
                dir = new Vec3(steer.x, Mth.clamp(delta.y * 0.25D, -0.6D, 0.6D), steer.z);
                if (dir.lengthSqr() < 1.0E-4D) {
                    return;
                }
                dir = dir.normalize();
            } else {
                dir = this.avoidObstacles(delta.normalize(), delta.length(), true);
                // no volar rozando el suelo
                if (this.getY() < this.groundY(this.getBlockX(), this.getBlockZ()) + 4.0D + this.collisionScale()) {
                    dir = dir.add(0.0D, 0.5D, 0.0D).normalize();
                }
            }
            double speed = Math.min(this.flySpeed() * this.speedMult, Math.max(0.3D, delta.length()));
            Vec3 want = dir.scale(speed);
            this.setDeltaMovement(this.getDeltaMovement().scale(0.8D).add(want.scale(0.2D)));
            if (dir.x * dir.x + dir.z * dir.z > 0.04D) {
                this.faceDirection(dir.x, dir.z);
            }
            if (this.onGround() && delta.y > 1.0D) {
                this.setDeltaMovement(this.getDeltaMovement().add(0.0D, 0.3D, 0.0D));
            }
            if (this.onGround() && delta.y <= 0.5D && this.tickCount % 10 == 0 && this.goalFlight && this.getMode() == MODE_FOLLOW) {
                this.setFlying(false);
            }
        } else {
            double hx = delta.x;
            double hz = delta.z;
            double len = Math.sqrt(hx * hx + hz * hz);
            if (len < 1.0D) {
                return;
            }
            Vec3 dir = this.avoidObstacles(new Vec3(hx / len, 0.0D, hz / len), len, false);
            double speed = this.groundSpeed() * this.speedMult;
            Vec3 motion = this.getDeltaMovement();
            this.setDeltaMovement(dir.x * speed, motion.y, dir.z * speed);
            this.faceDirection(dir.x, dir.z);
            if (this.horizontalCollision && this.onGround()) {
                this.setDeltaMovement(this.getDeltaMovement().x, 0.55D, this.getDeltaMovement().z);
            }
        }
    }

    /** Devuelve una direccion libre de obstaculos, lo mas parecida posible a la deseada. */
    private Vec3 avoidObstacles(Vec3 dir, double distToGoal, boolean flying) {
        // si lleva un rato sin avanzar, sube o rodea unos segundos
        if (this.tickCount % 20 == 0) {
            if (this.lastStuckPos != null && this.position().distanceToSqr(this.lastStuckPos) < 0.6D && distToGoal > 6.0D) {
                this.climbTicks = 40;
                double a = this.random.nextDouble() * Math.PI * 2.0D;
                this.climbDir = new Vec3(Math.cos(a), 0.0D, Math.sin(a));
                this.exploreHeading += Math.PI * 0.5D;
            }
            this.lastStuckPos = this.position();
        }
        if (this.climbTicks > 0) {
            this.climbTicks--;
            Vec3 side = this.climbDir == null ? Vec3.ZERO : this.climbDir;
            return flying ? new Vec3(side.x * 0.4D, 1.0D, side.z * 0.4D).normalize() : side;
        }
        if (this.cachedDir == null || this.tickCount % 4 == 0) {
            this.cachedDir = this.computeSteer(dir, flying);
        }
        return this.cachedDir;
    }

    private Vec3 computeSteer(Vec3 dir, boolean flying) {
        double look = 8.0D + this.collisionScale() * 2.5D;
        double half = Math.max(1.0D, this.collisionScale() * 0.55D);
        if (this.isClear(dir, look, half, flying)) {
            return dir;
        }
        if (flying) {
            for (double pitch : new double[]{0.45D, -0.45D, 0.9D, -0.9D, 1.35D}) {
                Vec3 candidate = this.pitched(dir, pitch);
                if (this.isClear(candidate, look, half, true)) {
                    return candidate;
                }
            }
        }
        for (double yaw : new double[]{0.6D, -0.6D, 1.2D, -1.2D, 1.9D, -1.9D}) {
            Vec3 candidate = this.yawed(dir, yaw);
            if (this.isClear(candidate, look, half, flying)) {
                return candidate;
            }
        }
        if (flying) {
            return new Vec3(dir.x * 0.3D, 1.0D, dir.z * 0.3D).normalize();
        }
        double a = this.random.nextDouble() * Math.PI * 2.0D;
        return new Vec3(Math.cos(a), 0.0D, Math.sin(a));
    }

    private Vec3 pitched(Vec3 dir, double delta) {
        double h = Math.sqrt(dir.x * dir.x + dir.z * dir.z);
        if (h < 1.0E-4D) {
            return dir;
        }
        double angle = Math.atan2(dir.y, h) + delta;
        angle = Mth.clamp(angle, -1.2D, 1.45D);
        return new Vec3(dir.x / h * Math.cos(angle), Math.sin(angle), dir.z / h * Math.cos(angle));
    }

    private Vec3 yawed(Vec3 dir, double delta) {
        double c = Math.cos(delta);
        double s = Math.sin(delta);
        return new Vec3(dir.x * c - dir.z * s, dir.y, dir.x * s + dir.z * c).normalize();
    }

    /** Lanza varios rayos hacia delante para saber si el camino esta libre (solo en chunks ya cargados). */
    private boolean isClear(Vec3 dir, double dist, double half, boolean flying) {
        Vec3 origin = this.position().add(0.0D, flying ? this.getBbHeight() * 0.5D : Math.max(1.1D, this.maxUpStep() + 0.3D), 0.0D);
        double safe = dist;
        for (double d = 4.0D; d <= dist; d += 4.0D) {
            Vec3 p = origin.add(dir.scale(d));
            if (!this.level().hasChunkAt(BlockPos.containing(p))) {
                safe = d - 4.0D;
                break;
            }
        }
        if (safe < 1.0D) {
            return true;
        }
        Vec3 lateral = new Vec3(-dir.z, 0.0D, dir.x);
        if (lateral.lengthSqr() < 1.0E-4D) {
            lateral = new Vec3(1.0D, 0.0D, 0.0D);
        }
        lateral = lateral.normalize();
        double[][] offsets = flying
                ? new double[][]{{0, 0}, {half, 0}, {-half, 0}, {0, half * 0.7D}, {0, -half * 0.7D}}
                : new double[][]{{0, 0}, {half, 0}, {-half, 0}};
        for (double[] offset : offsets) {
            Vec3 from = origin.add(lateral.scale(offset[0])).add(0.0D, offset[1], 0.0D);
            Vec3 to = from.add(dir.scale(safe));
            HitResult hit = this.level().clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
            if (hit.getType() != HitResult.Type.MISS) {
                return false;
            }
        }
        return true;
    }

    @Override
    public void travel(Vec3 input) {
        Entity controller = this.getControllingPassenger();
        if (controller instanceof Player rider) {
            if (this.isControlledByLocalInstance()) {
                this.riddenTravel(rider);
            }
            return;
        }
        if (this.level().isClientSide) {
            this.calculateEntityAnimation(false);
            return;
        }
        if (this.isFlying()) {
            this.move(MoverType.SELF, this.getDeltaMovement());
            this.setDeltaMovement(this.getDeltaMovement().scale(0.92D));
            this.fallDistance = 0.0F;
            this.calculateEntityAnimation(true);
        } else {
            super.travel(Vec3.ZERO);
        }
    }

    /** Teclado del jinete: solo existe en el cliente. */
    private static boolean riderJumping(Player rider) {
        Boolean jumping = DistExecutor.unsafeCallWhenOn(Dist.CLIENT, () -> () -> ClientRiderInput.isJumping(rider));
        return jumping != null && jumping;
    }

    /**
     * Control manual (se ejecuta en el cliente del jinete): espacio despega y sube; avanzar mirando arriba tambien
     * despega; avanzar mirando abajo desciende y aterriza.
     */
    private void riddenTravel(Player rider) {
        this.setYRot(rider.getYRot());
        this.yRotO = this.getYRot();
        this.setXRot(rider.getXRot() * 0.5F);
        this.setRot(this.getYRot(), this.getXRot());
        this.yBodyRot = this.getYRot();
        this.yHeadRot = this.getYRot();

        float forward = rider.zza;
        float strafe = rider.xxa * 0.6F;
        boolean jump = riderJumping(rider);
        boolean waterFly = this.isWaterDragon() && this.isInWater();
        boolean lookUp = forward > 0.0F && rider.getXRot() < -22.0F;
        if (!this.rideFlying && this.onGround() && (jump || lookUp)) {
            this.rideFlying = true;
            this.rideAirTicks = 0;
            this.setDeltaMovement(this.getDeltaMovement().add(0.0D, 0.8D, 0.0D));
        } else if (waterFly && !this.rideFlying && (jump || (forward > 0.0F && rider.getXRot() < -10.0F))) {
            this.rideFlying = true;
            this.rideAirTicks = 0;
        }
        if (this.rideFlying || waterFly) {
            this.rideAirTicks++;
            boolean pushing = jump || (forward > 0.0F && rider.getXRot() < -5.0F);
            if (this.onGround() && this.rideAirTicks > 10 && !pushing) {
                this.rideFlying = false;
            }
            double speed = this.flySpeed() * (rider.isSprinting() ? 1.5D : 1.0D) * (waterFly ? 2.0D : 1.0D);
            Vec3 look = rider.getLookAngle();
            Vec3 right = new Vec3(-look.z, 0.0D, look.x).normalize();
            Vec3 want = look.scale(forward * speed).add(right.scale(strafe * speed * 0.7D));
            if (jump) {
                want = want.add(0.0D, speed * 0.7D, 0.0D);
            }
            this.setDeltaMovement(this.getDeltaMovement().scale(0.88D).add(want.scale(0.12D)));
            this.move(MoverType.SELF, this.getDeltaMovement());
            this.fallDistance = 0.0F;
            this.calculateEntityAnimation(true);
        } else {
            this.setSpeed((float) (this.groundSpeed() * (rider.isSprinting() ? 1.4D : 1.0D)));
            super.travel(new Vec3(strafe, 0.0D, forward));
        }
    }

    @Override
    public boolean isNoGravity() {
        return this.isFlying() || super.isNoGravity();
    }

    // ------------------------------------------------------------------- combate

    private void tickCombat() {
        LivingEntity target = this.getTarget();
        if (this.lightningCooldown > 0) {
            this.lightningCooldown--;
        }
        boolean breathing = false;
        if (target != null && target.isAlive() && this.isTame() && target != this.getOwner()) {
            double range = 22.0D + this.getVisualScale() * 3.0D;
            if (this.distanceToSqr(target) <= range * range && this.hasLineOfSight(target)) {
                breathing = true;
                if (this.getControllingPassenger() == null) {
                    this.faceDirection(target.getX() - this.getX(), target.getZ() - this.getZ());
                }
                this.breathAt(target, range);
            } else if (this.getControllingPassenger() == null && this.getMode() == MODE_FOLLOW && this.getOwner() != null) {
                // se acerca al enemigo si esta lejos del alcance
                this.goal = target.position();
                this.goalFlight = this.isFlying();
            }
        }
        if (breathing != this.isBreathing()) {
            this.entityData.set(DATA_BREATHING, breathing);
        }
    }

    private void breathAt(LivingEntity target, double range) {
        if (!(this.level() instanceof ServerLevel level)) {
            return;
        }
        this.breathTick++;
        int type = this.getDragonType();
        double damage = this.getAttributeValue(Attributes.ATTACK_DAMAGE);
        Vec3 start = this.getEyePosition().add(this.getLookAngle().scale(this.getVisualScale() * 0.9D));
        Vec3 end = target.getEyePosition();
        Vec3 dir = end.subtract(start);
        double length = Math.min(dir.length(), range);
        Vec3 unit = dir.normalize();

        if (type == TYPE_STORM) {
            if (this.lightningCooldown <= 0) {
                this.lightningCooldown = 14;
                LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
                if (bolt != null) {
                    bolt.moveTo(target.getX(), target.getY(), target.getZ());
                    bolt.setVisualOnly(true);
                    level.addFreshEntity(bolt);
                }
                for (LivingEntity victim : this.victimsAround(target.getBoundingBox().inflate(2.5D))) {
                    victim.hurt(this.damageSources().mobAttack(this), (float) (damage * 1.4D));
                }
            }
            if (this.breathTick % 2 == 0) {
                for (int i = 1; i <= (int) length; i += 2) {
                    Vec3 p = start.add(unit.scale(i));
                    level.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 2, 0.2D, 0.2D, 0.2D, 0.05D);
                }
            }
            return;
        }

        if (this.breathTick % 2 != 0) {
            return;
        }
        ParticleOptions particle = type == TYPE_FIRE ? ParticleTypes.FLAME : (type == TYPE_WATER ? ParticleTypes.SPLASH
                : (type == TYPE_SKY ? ParticleTypes.END_ROD : ParticleTypes.SNOWFLAKE));
        Set<LivingEntity> hit = new HashSet<>();
        for (int i = 1; i <= (int) length; i++) {
            Vec3 p = start.add(unit.scale(i));
            double spread = 0.15D + i * 0.04D;
            level.sendParticles(particle, p.x, p.y, p.z, 3, spread, spread, spread, 0.02D);
            hit.addAll(this.victimsAround(new AABB(p.x - spread - 0.8D, p.y - spread - 0.8D, p.z - spread - 0.8D,
                    p.x + spread + 0.8D, p.y + spread + 0.8D, p.z + spread + 0.8D)));
        }
        for (LivingEntity victim : hit) {
            victim.hurt(this.damageSources().mobAttack(this), (float) (damage * 0.35D));
            if (type == TYPE_FIRE) {
                victim.setSecondsOnFire(6);
            } else if (type == TYPE_WATER) {
                victim.clearFire();
                victim.knockback(0.5D, this.getX() - victim.getX(), this.getZ() - victim.getZ());
                victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1));
            } else {
                victim.setTicksFrozen(victim.getTicksRequiredToFreeze() + 60);
                victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 2));
            }
        }
        if (this.breathTick % 10 == 0) {
            level.playSound(null, this.blockPosition(), type == TYPE_FIRE ? SoundEvents.BLAZE_SHOOT : (type == TYPE_WATER ? SoundEvents.GENERIC_SPLASH : SoundEvents.SNOW_GOLEM_SHOOT),
                    SoundSource.HOSTILE, 2.0F, 0.6F);
        }
    }

    private List<LivingEntity> victimsAround(AABB area) {
        LivingEntity owner = this.getOwner();
        return this.level().getEntitiesOfClass(LivingEntity.class, area, e -> e != this && e != owner
                && !(e instanceof DragoncitoEntity) && !(e instanceof AncientDragonEntity)
                && !(e instanceof TamableAnimal pet && pet.isTame() && pet.getOwner() == owner)
                && !this.hasPassenger(e));
    }

    // ------------------------------------------------------------------- sonidos

    @Override
    protected net.minecraft.sounds.SoundEvent getAmbientSound() {
        return SoundEvents.ENDER_DRAGON_AMBIENT;
    }

    @Override
    protected net.minecraft.sounds.SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENDER_DRAGON_HURT;
    }

    @Override
    protected net.minecraft.sounds.SoundEvent getDeathSound() {
        return SoundEvents.ENDER_DRAGON_DEATH;
    }

    @Override
    protected float getSoundVolume() {
        return 0.5F + this.getVisualScale() * 0.25F;
    }

    @Override
    public int getAmbientSoundInterval() {
        return 400;
    }
}
