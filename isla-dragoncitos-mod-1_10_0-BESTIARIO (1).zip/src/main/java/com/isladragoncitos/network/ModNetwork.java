package com.isladragoncitos.network;

import com.isladragoncitos.IslaDragoncitosMod;
import java.util.Optional;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String PROTOCOL = "2";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(IslaDragoncitosMod.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private ModNetwork() {}

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, OpenNameScreenPacket.class,
                OpenNameScreenPacket::encode, OpenNameScreenPacket::decode, OpenNameScreenPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(id++, OpenStatueScreenPacket.class,
                OpenStatueScreenPacket::encode, OpenStatueScreenPacket::decode, OpenStatueScreenPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(id++, ClaimIslandPacket.class,
                ClaimIslandPacket::encode, ClaimIslandPacket::decode, ClaimIslandPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(id++, TeleportIslandPacket.class,
                TeleportIslandPacket::encode, TeleportIslandPacket::decode, TeleportIslandPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(id++, TrustPacket.class,
                TrustPacket::encode, TrustPacket::decode, TrustPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(id++, DragonMenuPacket.class,
                DragonMenuPacket::encode, DragonMenuPacket::decode, DragonMenuPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(id++, DragonRequestPacket.class,
                DragonRequestPacket::encode, DragonRequestPacket::decode, DragonRequestPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(id++, AbilityPacket.class,
                AbilityPacket::encode, AbilityPacket::decode, AbilityPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(id++, CodexPacket.class,
                CodexPacket::encode, CodexPacket::decode, CodexPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(id++, BestiaryPacket.class,
                BestiaryPacket::encode, BestiaryPacket::decode, BestiaryPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
    }

    public static void sendTo(ServerPlayer player, Object packet) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), packet);
    }
}
