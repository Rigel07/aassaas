package com.isladragoncitos.client;

import com.isladragoncitos.abilities.DraconicAbilities;
import com.isladragoncitos.abilities.DraconicAbilities.Ability;
import com.isladragoncitos.entity.species.DragonSpecies;
import com.isladragoncitos.entity.species.DragonSpecies.SpeciesData;
import com.isladragoncitos.entity.species.SpeciesEffects;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

/**
 * Bestiario Draconiano: libro con 10 secciones (inicio, tipos, dragones, rarezas, habilidades, subir de nivel,
 * donde buscar, objetos, criaturas y controles). Sin widgets: todo se dibuja y se hace clic a mano.
 */
public class BestiaryScreen extends Screen {
    private record Row(FormattedCharSequence text, int color, int indent) {}

    private static final int HEADING = 0xFFD36B;
    private static final int SUB = 0x7FD8FF;
    private static final int NORMAL = 0xE6E6F0;
    private static final int DIM = 0x9A9AB5;
    private static final int LINE = 10;

    private final boolean all;
    private final Set<String> species;
    private final Set<String> abilities;
    private final int markLevel;
    private final int halfPoints;
    private final List<SpeciesData> speciesList = new ArrayList<>();
    private final List<Ability> abilityList = DraconicAbilities.all();

    private int tab;
    private int selSpecies;
    private int selAbility;
    private int listScroll;
    private int textScroll;
    private List<Row> rows = new ArrayList<>();

    private int left;
    private int top;
    private int w;
    private int h;
    private int tabW = 82;

    public BestiaryScreen(List<String> species, List<String> abilities, boolean all, int markLevel, int halfPoints) {
        super(Component.translatable("item.isladragoncitos.bestiary"));
        this.all = all;
        this.species = new HashSet<>(species);
        this.abilities = new HashSet<>(abilities);
        this.markLevel = markLevel;
        this.halfPoints = halfPoints;
        this.speciesList.addAll(DragonSpecies.ALL_SPECIES.values());
        this.speciesList.sort(Comparator.comparingInt((SpeciesData d) -> d.rarity.ordinal()).thenComparing(d -> d.name));
    }

    private boolean bred(SpeciesData data) {
        return this.all || this.species.contains(data.id);
    }

    private boolean knows(Ability ability) {
        return this.all || this.abilities.contains(ability.id);
    }

    private boolean listTab() {
        return this.tab == BestiaryContent.DRAGONES || this.tab == BestiaryContent.HABILIDADES;
    }

    @Override
    protected void init() {
        this.w = Math.min(this.width - 12, 400);
        this.h = Math.min(this.height - 12, 240);
        this.left = (this.width - this.w) / 2;
        this.top = (this.height - this.h) / 2;
        this.rebuild();
    }

    private int contentX() {
        return this.left + this.tabW + 10;
    }

    private int contentRight() {
        return this.left + this.w - 8;
    }

    private int contentTop() {
        return this.top + 24;
    }

    private int contentBottom() {
        return this.top + this.h - 8;
    }

    private int listWidth() {
        return 118;
    }

    private int textX() {
        return this.listTab() ? this.contentX() + this.listWidth() + 8 : this.contentX();
    }

    private int textWidth() {
        return this.contentRight() - this.textX() - 4;
    }

    private void rebuild() {
        List<String> lines = switch (this.tab) {
            case BestiaryContent.INICIO -> BestiaryContent.inicio((int) this.speciesList.stream().filter(this::bred).count(),
                    this.speciesList.size(), (int) this.abilityList.stream().filter(this::knows).count(), this.abilityList.size());
            case BestiaryContent.TIPOS -> BestiaryContent.tipos();
            case BestiaryContent.RAREZAS -> BestiaryContent.rarezas();
            case BestiaryContent.NIVELES -> BestiaryContent.niveles();
            case BestiaryContent.DONDE -> BestiaryContent.donde();
            case BestiaryContent.OBJETOS -> BestiaryContent.objetos();
            case BestiaryContent.CRIATURAS -> BestiaryContent.criaturas();
            case BestiaryContent.CONTROLES -> BestiaryContent.controles();
            case BestiaryContent.DRAGONES -> this.speciesDetail();
            default -> this.abilityDetail();
        };
        this.rows = this.wrap(lines, this.textWidth());
        this.textScroll = 0;
    }

    private List<Row> wrap(List<String> lines, int width) {
        List<Row> out = new ArrayList<>();
        for (String line : lines) {
            if (line.isEmpty()) {
                out.add(new Row(FormattedCharSequence.EMPTY, NORMAL, 0));
                continue;
            }
            int color = NORMAL;
            int indent = 0;
            String text = line;
            if (line.startsWith("## ")) {
                text = line.substring(3);
                color = SUB;
            } else if (line.startsWith("# ")) {
                text = line.substring(2);
                color = HEADING;
            } else if (line.startsWith("- ")) {
                text = "\u2022 " + line.substring(2);
                indent = 4;
            }
            for (FormattedCharSequence part : this.font.split(Component.literal(text), Math.max(40, width - indent))) {
                out.add(new Row(part, color, indent));
            }
        }
        return out;
    }

    // ------------------------------------------------------------------ detalles

    private List<String> speciesDetail() {
        List<String> t = new ArrayList<>();
        SpeciesData data = this.speciesList.get(Math.max(0, Math.min(this.selSpecies, this.speciesList.size() - 1)));
        t.add("# " + data.name);
        t.add("§7" + data.element.nameEs + " · §r" + data.rarity.nameEs);
        t.add(this.bred(data) ? "§aYa has criado esta especie." : "§8Aún no la has criado.");
        t.add("");
        int base = Math.max(0, Math.min(4, data.element.baseType));
        t.add("## Cómo encontrarlo");
        double chance = DragonSpecies.eggChancePercent(data);
        if (chance > 0.0D) {
            t.add(String.format("Sale de un huevo de tipo %s con una probabilidad del %.1f %%.", BestiaryContent.BASES[base], chance));
            t.add(BestiaryContent.eggSource(base));
        } else {
            t.add("No sale de huevos normales. Solo se consigue con el comando de operador /dragon especie " + data.id + ".");
        }
        t.add("");
        t.add("## Estadísticas");
        t.add("- Modelo base: " + BestiaryContent.BASES[base] + " (tinte del elemento).");
        t.add("- Tamaño: x" + data.sizeMultiplier);
        t.add("- Vida extra: +" + (int) data.healthBonus);
        t.add("- Daño: x" + data.damageMultiplier);
        t.add("");
        t.add("## Pasiva: " + data.passiveAbility);
        t.add(SpeciesEffects.describePassive(data.element));
        t.add("");
        t.add("## Ataque especial: " + data.specialAttack);
        t.add(SpeciesEffects.describeSpecial(data.element));
        t.add("");
        t.add("## Cómo subirlo de nivel");
        t.add("Aliméntalo con carne y manzanas doradas, gasta puntos draconianos en la tecla G y enseña habilidades a su jinete con manuscritos. Mira la pestaña Subir nivel.");
        return t;
    }

    private static String kindName(DraconicAbilities.Kind kind) {
        return switch (kind) {
            case NOVA -> "Explosión";
            case PULSE -> "Pulso en área";
            case BEAM -> "Rayo";
            case BUFF -> "Mejora";
            case HEAL -> "Curación";
            case CLEANSE -> "Purificación";
            case TELEPORT -> "Teletransporte";
            case LEAP -> "Salto";
            case DASH -> "Carrera";
            case PULL -> "Atracción";
            case FREEZE -> "Congelación";
            case LIGHTNING -> "Rayos";
            case METEOR -> "Lluvia de impactos";
            case PILLAR -> "Columna";
            case DRAIN -> "Drenaje de vida";
        };
    }

    private List<String> abilityDetail() {
        List<String> t = new ArrayList<>();
        Ability a = this.abilityList.get(Math.max(0, Math.min(this.selAbility, this.abilityList.size() - 1)));
        t.add("# " + a.nameEs);
        t.add(this.knows(a) ? "§aAprendida." : "§8No la conoces todavía.");
        t.add("");
        t.add(a.descEs);
        t.add("");
        t.add("## Datos");
        t.add("- Tipo: " + kindName(a.kind));
        t.add("- Coste para aprenderla: " + a.costPoints + " puntos draconianos");
        t.add("- Recarga: " + a.cooldownSec + " s");
        switch (a.kind) {
            case NOVA, PULSE, BEAM, PULL, FREEZE, LIGHTNING, METEOR, DRAIN -> t.add("- Alcance: " + (int) a.radius() + " bloques");
            case PILLAR -> t.add("- Radio del impacto: " + (int) a.radius() + " bloques (cae donde miras)");
            case HEAL -> t.add("- Alcance sobre tus mascotas: " + (int) a.radius() + " bloques");
            case TELEPORT -> t.add("- Distancia: " + (int) a.radius() + " bloques");
            default -> {
            }
        }
        if (a.kind == DraconicAbilities.Kind.LIGHTNING || a.kind == DraconicAbilities.Kind.METEOR) {
            t.add("- Impactos: " + a.count());
        }
        if (a.damage() > 0 && a.kind != DraconicAbilities.Kind.HEAL && a.kind != DraconicAbilities.Kind.CLEANSE) {
            t.add("- Daño: " + (int) a.damage() + (a.burns() ? " (y prende fuego)" : ""));
        }
        if (a.kind == DraconicAbilities.Kind.HEAL) {
            t.add("- Cura: " + (int) a.damage() + " de vida");
        }
        t.add("");
        t.add("## Cómo conseguirla");
        t.add("Lee su Manuscrito Draconiano. Hace falta la Marca del Jinete" + (this.markLevel > 0 ? " (la tienes)" : " (aún no la tienes: eclosiona tu primer dragón)")
                + " y " + a.costPoints + " puntos (tienes " + (this.halfPoints / 2) + (this.halfPoints % 2 == 1 ? ",5" : "") + ").");
        t.add("Los manuscritos salen de cofres de castillos, cuevas, santuarios y del Árbol de la Vida, o de los adoradores.");
        t.add("");
        t.add("Nunca daña a ti, a tu dragón ni a tus mascotas. R la lanza, V cambia de habilidad.");
        return t;
    }

    // ------------------------------------------------------------------ dibujo

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        this.renderBackground(g);
        g.fill(this.left, this.top, this.left + this.w, this.top + this.h, 0xF01B1428);
        g.fill(this.left + 2, this.top + 2, this.left + this.w - 2, this.top + this.h - 2, 0xF02A2140);
        g.drawString(this.font, Component.translatable("item.isladragoncitos.bestiary"), this.left + 8, this.top + 8, HEADING, false);
        // pestanas
        for (int i = 0; i < BestiaryContent.TAB_NAMES.length; i++) {
            int y = this.contentTop() + i * 17;
            boolean selected = i == this.tab;
            boolean hover = mouseX >= this.left + 6 && mouseX < this.left + 6 + this.tabW && mouseY >= y && mouseY < y + 15;
            g.fill(this.left + 6, y, this.left + 6 + this.tabW, y + 15, selected ? 0xFF6B4FB0 : (hover ? 0xFF4A3A80 : 0xFF38305C));
            g.drawString(this.font, BestiaryContent.TAB_NAMES[i], this.left + 11, y + 4, selected ? 0xFFFFFF : 0xC8C8E0, false);
        }
        g.fill(this.left + this.tabW + 8, this.contentTop(), this.left + this.tabW + 9, this.contentBottom(), 0xFF6B5A9A);
        if (this.listTab()) {
            this.drawList(g, mouseX, mouseY);
        }
        this.drawText(g);
        super.render(g, mouseX, mouseY, partial);
    }

    private int listRows() {
        return Math.max(1, (this.contentBottom() - this.contentTop()) / 12);
    }

    private int listSize() {
        return this.tab == BestiaryContent.DRAGONES ? this.speciesList.size() : this.abilityList.size();
    }

    private void drawList(GuiGraphics g, int mouseX, int mouseY) {
        int x = this.contentX();
        int y0 = this.contentTop();
        int rows = this.listRows();
        int max = Math.max(0, this.listSize() - rows);
        this.listScroll = Math.max(0, Math.min(this.listScroll, max));
        g.enableScissor(x, y0, x + this.listWidth(), this.contentBottom());
        for (int i = 0; i < rows && this.listScroll + i < this.listSize(); i++) {
            int index = this.listScroll + i;
            int y = y0 + i * 12;
            boolean selected = index == (this.tab == BestiaryContent.DRAGONES ? this.selSpecies : this.selAbility);
            boolean hover = mouseX >= x && mouseX < x + this.listWidth() && mouseY >= y && mouseY < y + 12;
            if (selected || hover) {
                g.fill(x, y, x + this.listWidth(), y + 12, selected ? 0xFF5A4690 : 0xFF3E3266);
            }
            String name;
            int color;
            boolean done;
            if (this.tab == BestiaryContent.DRAGONES) {
                SpeciesData d = this.speciesList.get(index);
                name = d.name;
                color = d.rarity.color;
                done = this.bred(d);
            } else {
                Ability a = this.abilityList.get(index);
                name = a.nameEs;
                color = 0xFFE9B0;
                done = this.knows(a);
            }
            g.fill(x + 2, y + 4, x + 6, y + 8, done ? 0xFF55FF55 : 0xFF555566);
            g.drawString(this.font, this.font.plainSubstrByWidth(name, this.listWidth() - 14), x + 9, y + 2, color, false);
        }
        g.disableScissor();
        // barra de desplazamiento
        if (max > 0) {
            int trackH = this.contentBottom() - y0;
            int barH = Math.max(10, trackH * rows / this.listSize());
            int barY = y0 + (trackH - barH) * this.listScroll / max;
            g.fill(x + this.listWidth() + 1, y0, x + this.listWidth() + 3, this.contentBottom(), 0xFF2A2250);
            g.fill(x + this.listWidth() + 1, barY, x + this.listWidth() + 3, barY + barH, 0xFF9A86E0);
        }
    }

    private void drawText(GuiGraphics g) {
        int x = this.textX();
        int y0 = this.contentTop();
        int viewH = this.contentBottom() - y0;
        int total = this.rows.size() * LINE;
        int max = Math.max(0, total - viewH);
        this.textScroll = Math.max(0, Math.min(this.textScroll, max));
        g.enableScissor(x, y0, this.contentRight(), this.contentBottom());
        for (int i = 0; i < this.rows.size(); i++) {
            int y = y0 + i * LINE - this.textScroll;
            if (y < y0 - LINE || y > this.contentBottom()) {
                continue;
            }
            Row row = this.rows.get(i);
            g.drawString(this.font, row.text(), x + row.indent(), y, row.color(), false);
        }
        g.disableScissor();
        if (max > 0) {
            int barH = Math.max(10, viewH * viewH / total);
            int barY = y0 + (viewH - barH) * this.textScroll / max;
            g.fill(this.contentRight() - 1, y0, this.contentRight() + 1, this.contentBottom(), 0xFF2A2250);
            g.fill(this.contentRight() - 1, barY, this.contentRight() + 1, barY + barH, 0xFF9A86E0);
        }
    }

    // ------------------------------------------------------------------ entrada

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            for (int i = 0; i < BestiaryContent.TAB_NAMES.length; i++) {
                int y = this.contentTop() + i * 17;
                if (mouseX >= this.left + 6 && mouseX < this.left + 6 + this.tabW && mouseY >= y && mouseY < y + 15) {
                    this.tab = i;
                    this.listScroll = 0;
                    this.rebuild();
                    return true;
                }
            }
            if (this.listTab() && mouseX >= this.contentX() && mouseX < this.contentX() + this.listWidth()
                    && mouseY >= this.contentTop() && mouseY < this.contentBottom()) {
                int index = this.listScroll + (int) ((mouseY - this.contentTop()) / 12);
                if (index >= 0 && index < this.listSize()) {
                    if (this.tab == BestiaryContent.DRAGONES) {
                        this.selSpecies = index;
                    } else {
                        this.selAbility = index;
                    }
                    this.rebuild();
                }
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (this.listTab() && mouseX < this.contentX() + this.listWidth() + 4) {
            this.listScroll -= (int) Math.signum(delta) * 3;
        } else {
            this.textScroll -= (int) Math.signum(delta) * LINE * 3;
        }
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scanCode, int modifiers) {
        if (this.minecraft != null && this.minecraft.options.keyInventory.matches(key, scanCode)) {
            this.onClose();
            return true;
        }
        return super.keyPressed(key, scanCode, modifiers);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
