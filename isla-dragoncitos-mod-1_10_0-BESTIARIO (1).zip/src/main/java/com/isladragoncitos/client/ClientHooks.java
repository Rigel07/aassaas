package com.isladragoncitos.client;

import com.isladragoncitos.network.DragonMenuInfo;
import com.isladragoncitos.network.StatueInfo;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

/** Puntos de entrada del cliente (se llaman desde los paquetes via DistExecutor). */
public final class ClientHooks {
    private ClientHooks() {}

    public static void openNameScreen(BlockPos pos) {
        Minecraft.getInstance().setScreen(new NameIslandScreen(pos));
    }

    public static void openStatueScreen(StatueInfo info) {
        Minecraft.getInstance().setScreen(new StatueScreen(info));
    }

    public static void openBestiary(java.util.List<String> species, java.util.List<String> abilities, boolean all, int markLevel, int halfPoints) {
        Minecraft.getInstance().setScreen(new BestiaryScreen(species, abilities, all, markLevel, halfPoints));
    }

    public static void openCodex(java.util.List<String> discovered, boolean all) {
        Minecraft.getInstance().setScreen(new DragonCodexScreen(discovered, all));
    }

    /** Abre el menu del dragon, o solo actualiza sus datos si ya esta abierto. */
    public static void openDragonScreen(DragonMenuInfo info) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.screen instanceof DragonScreen screen) {
            screen.update(info);
        } else {
            minecraft.setScreen(new DragonScreen(info));
        }
    }
}
