package com.isladragoncitos.client;

import com.isladragoncitos.entity.species.DragonSpecies;
import com.isladragoncitos.entity.species.DragonSpecies.Rarity;
import java.util.ArrayList;
import java.util.List;

/**
 * Textos del Bestiario Draconiano. Formato de las lineas: "# " titulo, "## " subtitulo, "- " vineta, ""
 * separador y cualquier otra cosa es texto normal. Los codigos de color (§) tambien valen.
 */
final class BestiaryContent {
    static final String[] TAB_NAMES = {"Inicio", "Tipos", "Dragones", "Rarezas", "Habilidades", "Subir nivel",
            "Dónde buscar", "Objetos", "Criaturas", "Controles"};
    static final int INICIO = 0, TIPOS = 1, DRAGONES = 2, RAREZAS = 3, HABILIDADES = 4, NIVELES = 5, DONDE = 6, OBJETOS = 7,
            CRIATURAS = 8, CONTROLES = 9;

    static final String[] BASES = {"Fuego", "Hielo", "Tormenta", "Agua", "Celeste"};

    private BestiaryContent() {}

    /** Donde conseguir un huevo de cada tipo base. */
    static String eggSource(int base) {
        return switch (base) {
            case 0, 1, 2 -> "Huevo de Dragón Antiguo de " + BASES[base].toLowerCase() + ": muy raro, escondido en el suelo del mapa (en un hueco con musgo); "
                    + "también en los altares de las islas enormes (Ciudadela y Gran Templo), en el altar del Castillo, en el nido de la Cueva del Dragón y en las fortalezas y cuevas gigantes.";
            case 3 -> "Huevo de Dragón del Agua: está en el fondo de los océanos profundos (muy raro). A veces también en las fortalezas y cuevas gigantes.";
            default -> "Huevo de Dragón Celeste: aún no se genera solo en el mundo. Se consigue en la pestaña creativa del mod o con /dragon especie aurora_wyrm (hacen falta trucos).";
        };
    }

    static List<String> inicio(int found, int total, int abilitiesKnown, int abilitiesTotal) {
        List<String> t = new ArrayList<>();
        t.add("# Bestiario Draconiano");
        t.add("Te lo entregan los Jinetes del Alba nada más pisar el mundo. Aquí está todo lo que se sabe de los dragones de esta tierra: sus tipos, rarezas, habilidades, dónde encontrarlos y cómo hacerlos fuertes.");
        t.add("");
        t.add("§7Especies criadas: §f" + found + "/" + total + "   §7Habilidades: §f" + abilitiesKnown + "/" + abilitiesTotal);
        t.add("");
        t.add("## Cómo empezar");
        t.add("- 1. Consigue un huevo de dragón (mira Dónde buscar y Tipos).");
        t.add("- 2. Colócalo en el suelo: eclosiona en unos 5 minutos (más rápido junto a fuego o lava) y nace un dragón domado. Su especie sale al azar según su rareza.");
        t.add("- 3. Aliméntalo con carne y manzanas doradas: crece hasta un tamaño gigante.");
        t.add("- 4. Pulsa G para abrir su menú: gasta tus puntos draconianos en mejoras.");
        t.add("- 5. Craftea el Montadragones, colócaselo y vuela. Espacio para despegar.");
        t.add("- 6. Descubre islas para ganar puntos y aprende habilidades con manuscritos.");
        t.add("");
        t.add("Usa las pestañas de la izquierda. Rueda del ratón para desplazarte por listas y textos. Si pierdes este libro, el comando /dragon bestiario te da otro.");
        return t;
    }

    static List<String> tipos() {
        List<String> t = new ArrayList<>();
        t.add("# Los cinco tipos de dragón");
        t.add("El tipo decide el modelo 3D del dragón. Dentro de cada tipo hay muchas especies que se distinguen por elemento, color, tamaño, vida, daño, pasiva y ataque especial.");
        t.add("");
        t.add("## Fuego  §8(" + DragonSpecies.countForBase(0) + " especies)");
        t.add("Dragón de lava y brasas con ojos incandescentes. Te defiende con fuego. " + eggSource(0));
        t.add("");
        t.add("## Hielo  §8(" + DragonSpecies.countForBase(1) + " especies)");
        t.add("Dragón de cristales y escarcha. Te defiende con aliento helado. " + eggSource(1));
        t.add("");
        t.add("## Tormenta  §8(" + DragonSpecies.countForBase(2) + " especies)");
        t.add("Dragón de rayos y energía. Te defiende con descargas eléctricas. " + eggSource(2));
        t.add("");
        t.add("## Agua  §8(" + DragonSpecies.countForBase(3) + " especies)");
        t.add("El más raro y fuerte. Nace con estadísticas más altas, vuela bajo el agua a gran velocidad y da respiración acuática y visión nocturna al jinete mientras está en el agua. Respira bajo el agua y escupe chorros que empujan. " + eggSource(3));
        t.add("");
        t.add("## Celeste  §8(" + DragonSpecies.countForBase(4) + " especie)");
        t.add("La Serpiente Celeste: sin alas ni patas, cuerpo largo y ondulante, cornamenta de cristal, bigotes largos, perla celestial flotante con anillos de runas y estrellas que orbitan. " + eggSource(4));
        t.add("");
        t.add("## Dragoncitos");
        t.add("No son dragones antiguos: son pequeños, no crecen y vuelan con aleteos cortos (rosa, verde, azul y rojo). Mira Criaturas.");
        return t;
    }

    static List<String> rarezas() {
        List<String> t = new ArrayList<>();
        t.add("# Rarezas");
        t.add("Cada especie tiene una rareza. Al eclosionar un huevo, la especie se sortea entre las de su tipo según estos pesos (el dragón clásico de cada tipo sale con mucha más frecuencia).");
        t.add("");
        for (Rarity rarity : Rarity.values()) {
            int count = 0;
            for (DragonSpecies.SpeciesData data : DragonSpecies.ALL_SPECIES.values()) {
                if (data.rarity == rarity) {
                    count++;
                }
            }
            t.add("## " + rarity.nameEs + "  §8(" + count + " especies)");
            if (rarity.weight > 0) {
                t.add("Peso de sorteo: " + rarity.weight + ". " + describe(rarity));
            } else {
                t.add("No sale de huevos normales: solo se consigue con el comando de operador /dragon especie <id>. " + describe(rarity));
            }
            t.add("");
        }
        t.add("Mientras más rara, más tamaño, vida y daño, y su ataque especial se lanza antes (recarga de 10 s a 4 s).");
        return t;
    }

    private static String describe(Rarity rarity) {
        return switch (rarity) {
            case COMMON -> "Las más frecuentes; buenas para empezar.";
            case RARE -> "Ya se nota la diferencia de poder.";
            case EPIC -> "Fuertes y vistosas.";
            case LEGENDARY -> "Muy raras: pasiva potente.";
            case MYTHIC -> "Casi imposibles de ver.";
            case ANCIENT -> "Dragones de leyenda, anteriores a los Jinetes.";
            case DIVINE -> "Las criaturas más poderosas; su pasiva incluye resistencia para el jinete.";
        };
    }

    static List<String> niveles() {
        List<String> t = new ArrayList<>();
        t.add("# Cómo subir de nivel a tu dragón");
        t.add("## 1. Comida y tamaño");
        t.add("Dale carne o manzanas doradas. Cada bocado llena su barra de comida (máximo 3000) y el dragón crece de forma visible hasta un tamaño gigante. Con carne también se cura.");
        t.add("");
        t.add("## 2. Puntos draconianos");
        t.add("- +10 por cada isla flotante descubierta (solo la primera vez).");
        t.add("- +50 al recibir la bendición del Árbol de la Vida.");
        t.add("- Operadores y creativo: /dragon puntos <n>.");
        t.add("");
        t.add("## 3. Mejoras (tecla G → Mejoras)");
        t.add("- Fuerza: máx. 200 niveles, 1 punto por nivel.");
        t.add("- Velocidad: máx. 20, 5 puntos por nivel.");
        t.add("- Vida: máx. 400, 0,5 puntos por nivel.");
        t.add("- Escamas protectoras: máx. 100, 1 punto cada una. Cada escama reduce un golpe a la mitad y se gasta.");
        t.add("");
        t.add("## 4. Vida compartida (100 puntos)");
        t.add("Une tu vida a la de tu dragón: se suman y son la misma para los dos (corazón del color del dragón en pantalla). Si uno muere, el otro también (tú reapareces, el dragón no).");
        t.add("");
        t.add("## 5. Marca del Jinete");
        t.add("- Nivel 1: se despierta al eclosionar tu primer dragón. Duplica puntos, efectos de amuletos y escamas y la vida que aporta el dragón. Dura mientras viva ese dragón.");
        t.add("- Nivel 2: la da el Árbol de la Vida (hace falta vida compartida). La vida compartida se multiplica por 2.");
        t.add("");
        t.add("## 6. Habilidades draconianas");
        t.add("Lee Manuscritos Draconianos (cuestan de 20 a 150 puntos). Mira la pestaña Habilidades.");
        t.add("");
        t.add("## 7. Edulnari");
        t.add("Al morir, tu dragón deja una esencia con sus niveles y habilidades (sin tamaño ni escamas). Úsala con clic derecho sobre un huevo antes de que eclosione y el nuevo dragón nace con esas mejoras.");
        return t;
    }

    static List<String> donde() {
        List<String> t = new ArrayList<>();
        t.add("# Dónde buscar");
        t.add("Usa /locate structure isladragoncitos:<id> (necesita trucos) o la Brújula de Dragón (señala la isla más cercana).");
        t.add("");
        t.add("## Islas flotantes  §8(isla)");
        t.add("Casi siempre junto a un río, con cascada y una enredadera gigante para trepar. 6 estilos y de radio 11 a 64. Cada una tiene una Estatua del Dragón. Las enormes tienen Gran Templo o Ciudadela con altar y, a veces, un huevo. Dan puntos draconianos.");
        t.add("");
        t.add("## Ruinas de los Jinetes");
        t.add("- Atalaya del Jinete §8(rider_watch)§r: torre en ruinas.");
        t.add("- Cementerio de Dragones §8(rider_graveyard)§r: esqueleto colosal.");
        t.add("- Círculo del Alba §8(rider_circle)§r: ofrendas y cofre bajo el altar.");
        t.add("- Pilar de las Profundidades §8(rider_sea)§r: en el océano profundo.");
        t.add("Aquí están las páginas de la Crónica de los Jinetes del Alba.");
        t.add("");
        t.add("## Castillos y fortalezas");
        t.add("- Castillo del Dragón §8(dragon_castle)§r: murallas, 4 torres y torreón con altar y huevo.");
        t.add("- Fortaleza draconiana gigante §8(castle_dragon)§r.");
        t.add("- Castillo élfico §8(castle_elf)§r.");
        t.add("");
        t.add("## Cuevas");
        t.add("- Cueva del Dragón §8(dragon_cave)§r: sala enorme, tesoro y nido con huevo.");
        t.add("- Guarida del tesoro §8(cave_hoard)§r y Caverna de cristales §8(cave_crystal)§r.");
        t.add("");
        t.add("## Santuario y aldea");
        t.add("- Santuario §8(dragon_sanctuary)§r: altar, cofres y adoradores.");
        t.add("- Aldea de Adoradores §8(worshipper_village)§r.");
        t.add("");
        t.add("## Árboles colosales");
        t.add("- Árbol de la Vida §8(life_tree)§r: toca su corazón con la vida unida a un dragón: Marca Nivel 2, +50 puntos, una habilidad y botín infinito.");
        t.add("- Gran Árbol del Mundo §8(world_tree)§r: único por mundo, con la ciudad élfica de Alfheim.");
        t.add("");
        t.add("## Fondo del mar");
        t.add("Huevos del Dragón del Agua en océanos profundos.");
        return t;
    }

    static List<String> objetos() {
        List<String> t = new ArrayList<>();
        t.add("# Objetos");
        t.add("## Escamas (rosa, verde, azul, roja)");
        t.add("Clic derecho: rosa cura, verde hace florecer piedra y tierra, azul da aliento de mar, roja protege del fuego. Sobre tu dragoncito le cambian el color. Salen de los cofres y los dragoncitos domados las sueltan.");
        t.add("## Amuletos");
        t.add("Oro + escama. Dos efectos permanentes mientras los llevas en el inventario.");
        t.add("## Brújula de Dragón");
        t.add("Brújula + 4 escamas: señala la isla más cercana.");
        t.add("## Montadragones");
        t.add("Silla + 4 escamas. Clic derecho con la mano vacía para montar; agachado + clic derecho con el Montadragones para quitarlo.");
        t.add("## Báculo del Dragón");
        t.add("Guarda a tu dragón (clic derecho sobre él) y lo libera en un bloque.");
        t.add("## Edulnari");
        t.add("Esencia que deja tu dragón al morir. Úsala en un huevo.");
        t.add("## Materiales legendarios");
        t.add("Esencia de Dragón (las 4 escamas), Fragmento del Tiempo, Polvo Cósmico, Núcleo del Vacío, Copo Solar y Lágrima Lunar.");
        t.add("## Equipo único");
        t.add("Hoz de Cronos (ralentiza lo que golpea), Placa Omega, Corona de la Psique y Moneda de Fortuna (Suerte III 5 min).");
        t.add("## Códice Dracónico");
        t.add("Enciclopedia sencilla de especies (se rellena al criarlas).");
        t.add("## Manuscrito Draconiano");
        t.add("Enseña una habilidad a los jinetes con la Marca. Salen de cofres de castillos, cuevas, santuarios y del Árbol de la Vida, o de los adoradores.");
        return t;
    }

    static List<String> criaturas() {
        List<String> t = new ArrayList<>();
        t.add("# Criaturas");
        t.add("## Dragoncitos");
        t.add("Rosa, verde, azul y rojo. Dales carne para domesticarlos (50 % por intento). Clic derecho: seguirte / quedarse. Los de cada isla tienden al color de su estilo.");
        t.add("");
        t.add("## Dragones Antiguos");
        t.add("Mira Tipos, Dragones y Rarezas. Sienten adoración los dragoncitos por ellos.");
        t.add("");
        t.add("## Adoradores de los Dragones");
        t.add("Habitantes pacíficos de castillos, santuarios y aldeas. Dales una escama: te dan esencia de dragón y, a veces, un manuscrito.");
        t.add("");
        t.add("## Elfos de Alfheim");
        t.add("Viven en la ciudad élfica del Gran Árbol del Mundo. Aceptan manzanas doradas y te hacen un regalo. Cuentan la historia de Yggdrasil.");
        return t;
    }

    static List<String> controles() {
        List<String> t = new ArrayList<>();
        t.add("# Controles y comandos");
        t.add("## Teclas §8(reajustables en Controles)");
        t.add("- G: menú del dragón (mejoras, órdenes, viajes).");
        t.add("- R: lanzar la habilidad draconiana seleccionada.");
        t.add("- V: cambiar de habilidad.");
        t.add("- Espacio al montar: despegar y subir.");
        t.add("");
        t.add("## Comandos");
        t.add("- /dragon: menú. /dragon texto: menú de texto.");
        t.add("- /dragon habilidades: lista de las 50 habilidades.");
        t.add("- /dragon habilidad <id>: elegir la activa.");
        t.add("- /dragon bestiario: recuperar este libro.");
        t.add("§8Con trucos u operador:");
        t.add("- /dragon puntos <n>, /dragon aprender <id>, /dragon manuscrito <id>, /dragon especie <id>.");
        return t;
    }
}
